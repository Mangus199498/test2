import React, { Component,useEffect } from 'react';
import {AppRegistry, Platform, StatusBar  , View, StyleSheet, Text,PermissionsAndroid,TextInput} from 'react-native';
import Routes from './router/Routes';
import { Provider, inject } from 'mobx-react';
import services from './services';
import LoadingBar from './components/LoadingBar';
import firebase , { Notification , RemoteMessage } from 'react-native-firebase';
import SplashScreen from 'react-native-splash-screen'

class App extends Component {
   async componentDidMount() {
      if (Platform.OS == 'android') {
         SplashScreen.hide();
      }

      Text.defaultProps = Text.defaultProps || {};
      Text.defaultProps.allowFontScaling = false; //this is important -> no scale

      TextInput.defaultProps = TextInput.defaultProps || {};
      TextInput.defaultProps.allowFontScaling = false; //this is important -> no scale
   }
   render() {
      return (
         <View style={{width: '100%', height: '100%'}}>
             <View
               style={{
                  backgroundColor: '#fff',
                  height: StatusBar.currentHeight,
               }}>
               <StatusBar
                  translucent
                  backgroundColor="#fff"
                  barStyle="dark-content"
               />
            </View>
            <Provider {...services}>
               <Routes ref={nav => {this.navigator = nav;}}/>
            </Provider>
         </View>
      )
   }
}
const styles = StyleSheet.create({
   
})
export default App
AppRegistry.registerComponent('sample', () => App)