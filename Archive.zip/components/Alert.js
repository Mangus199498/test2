import { Alert} from 'react-native';

export function showAlert(title, message) {
    Alert.alert(
        '',
        message,
        [
            {
            text: 'OK',
            onPress: () => console.log('OK'),
            style: 'cancel',
            },
        ],
        {cancelable: false},
    );
}