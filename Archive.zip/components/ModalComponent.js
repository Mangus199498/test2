import React from 'react';
import { StyleSheet, View ,Modal, Text, TouchableHighlight} from 'react-native';
import PropTypes from 'prop-types'

export default class ModalComponent extends React.Component {
	state = {
		modalVisible : false
	}
  render() {
    return (
	    <View style={styles.popup_wrapper}>
	    	<Modal
				animationType="slide"
				transparent={false}
				visible={this.state.modalVisible}
				onRequestClose={() => {
					Alert.alert('Modal has been closed.');
				}}>
				<View style={{marginTop: 22}}>
					<View>
					<Text>Hello World!</Text>

					<TouchableHighlight
						onPress={() => {
						this.setModalVisible(!this.state.modalVisible);
						}}>
						<Text>Hide Modal</Text>
					</TouchableHighlight>
					</View>
				</View>
			</Modal>
	    </View>
    );
  }
  
  componentWillMount() {
	this.setState({modalVisible : false})
  }
  onClickedClose = () => {
      this.props.hideModal(false)
  }

}

ModalComponent.propType = {
    hideModal : PropTypes.func,
}

const styles = StyleSheet.create({
	popup_wrapper: {
		flex: 1,
		alignItems: 'center',
		justifyContent: 'center',
		paddingLeft: 80,
		paddingRight: 80,
	},

	popup_background: {
		position: 'absolute',
		top: 0,
		left: 0,
		bottom: 0,
		right: 0,
		backgroundColor: '#888',
		zIndex: -1,
		opacity: 0.4
	},

	popup_background: {
		borderRadius: 24,
		backgroundColor: 'white'
	}
});