import React from 'react'
import { StyleSheet} from 'react-native'
import { createAppContainer, createStackNavigator } from 'react-navigation';

import LoginScreen from '../screen/LoginPage/LoginScreen';

import SignUpScreen from '../screen/SignUpPage/SignUpScreen';
import TabsPage from '../screen/TabPage/TabsScreen';
import PostDetailScreen from '../screen/TabPage/SubScreen/Explore/Post/PostDetailScreen';
import GroupDetailScreen from '../screen/TabPage/SubScreen/Explore/Group/GroupDetailScreen';
import GroupInfoScreen from '../screen/TabPage/SubScreen/Explore/Group/GroupInfoScreen';
import PlaceDetailScreen from '../screen/TabPage/SubScreen/Home/PlaceDetailScreen';
import MyInfoScreen from '../screen/MyInfoPage/MyInfoScreen';
import EditProfileScreen from '../screen/TabPage/SubScreen/Setting/EditProfileScreen';
import FaqScreen from '../screen/TabPage/SubScreen/Setting/FaqScreen';
import PlaceReviewScreen from '../screen/TabPage/SubScreen/Home/PlaceReviewScreen';
import ReviewScreen from '../screen/TabPage/SubScreen/Home/ReviewScreen';
import NotificationScreen from '../screen/NotificationPage/NotificationScreen';
import InvitationScreen from '../screen/NotificationPage/InvitationScreen';
import UpgradePlanScreen from '../screen/TabPage/SubScreen/Setting/UpgradePlan';
import PaymentScreen from '../screen/TabPage/SubScreen/Setting/PaymentScreen';
import AddGroupChatScreen from '../screen/TabPage/SubScreen/Message/AddGroupChatScreen';
import ChatScreen from '../screen/TabPage/SubScreen/Message/ChatScreen';
import GroupChatInfoScreen from '../screen/TabPage/SubScreen/Message/GroupChatInfoScreen';
import AddPostScreen from '../screen/TabPage/SubScreen/Explore/Post/AddPostScreen';
import ChangePassword from '../screen/TabPage/SubScreen/Setting/ChangePassword';
import AddGroupScreen from '../screen/TabPage/SubScreen/Explore/Group/AddGroupScreen';
import SearchFriendScreen from '../screen/TabPage/SubScreen/Friends/SearchFriendScreen';
import FriendInfoScreen from '../screen/TabPage/SubScreen/Friends/FriendInfo/FriendInfoScreen';
import MyFriendSearch from '../screen/TabPage/SubScreen/Explore/MyFriendSearch';
import ForgotPasswordScreen from  '../screen/LoginPage/ForgotPasswordScreen';

const AppNavigator = createStackNavigator({
    LoginScreen: {screen: LoginScreen},
    SignUpScreen: {screen: SignUpScreen},
    TabsPage: {screen: TabsPage},
    PostDetailScreen: {screen: PostDetailScreen},
    GroupDetailScreen: {screen: GroupDetailScreen},
    GroupInfoScreen: {screen: GroupInfoScreen},
    PlaceDetailScreen: {screen: PlaceDetailScreen},
    MyInfoScreen: {screen: MyInfoScreen},
    EditProfileScreen : { screen : EditProfileScreen},
    FaqScreen: {screen: FaqScreen},
    PlaceReviewScreen: {screen: PlaceReviewScreen},
    ReviewScreen: {screen: ReviewScreen},
    NotificationScreen: {screen: NotificationScreen},
    InvitationScreen: {screen: InvitationScreen},
    UpgradePlanScreen: {screen: UpgradePlanScreen},
    PaymentScreen: {screen: PaymentScreen},
    AddGroupChatScreen: {screen: AddGroupChatScreen},
    ChatScreen: {screen: ChatScreen},
    GroupChatInfoScreen: {screen: GroupChatInfoScreen},
    AddPostScreen : {screen: AddPostScreen},
    ChangePassword : {screen : ChangePassword},
    AddGroupScreen : {screen : AddGroupScreen},
    SearchFriendScreen : {screen :SearchFriendScreen},
    FriendInfoScreen : {screen : FriendInfoScreen},
    MyFriendSearch : {screen :MyFriendSearch},
    ForgotPasswordScreen : {screen :ForgotPasswordScreen},
 }, {
      initialRouteName: 'LoginScreen',
      navigationOptions : {
        headerLeft: null
      }
 },);
 
 const AppContainer = createAppContainer(AppNavigator);
 
 export default AppContainer;