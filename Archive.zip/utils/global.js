export var private_plan_data = [];
export var public_plan_data = [];

//test value
export var flag = false; // this is updating 
export var notifciation_data = [];
//
export function setNotiData (value) {
    notifciation_data = value;
}

export function getNotiData() {
    return notifciation_data;
}


export function setPrivateData (data) {
    private_plan_data = data;
}

export function getPrivateData () {
    return private_plan_data
}


export function sortDataByTime (orgin_data) {
    orgin_data.sort((a,b) => (a.time < b.time) ? 1 : ((b.time < a.time) ? -1 : 0)) //date sorting
    return orgin_data
}
export function sortDataByDate (orgin_data) {
    orgin_data.sort((a,b) => (a.date > b.date) ? 1 : ((b.date > a.date) ? -1 : 0)) //date sorting
    return orgin_data
}