export function get_before_day (time) {
    console.log(time)
    if (((new Date().getTime() - time) / (3600 * 24 * 1000)) < 1) {
        return Math.floor((new Date().getTime() - time) / (3600 * 24 * 1000))
    } else {
        return Math.ceil((new Date().getTime() - time) / (3600 * 24 * 1000))
    }
}

export function getHoursAndMins(time) {
    var half = ''
    var date = new Date(time.seconds * 1000);
    var hours = date.getHours();
    if (hours > 12) {
        half = "PM"
    } else {
        half = "AM"
    }
    if (hours < 10) hours = '0' + hours

    var mins = date.getMinutes();
    if (mins < 10 ) mins = '0' + mins

    return hours + ':' + mins + ' ' + half
}

export function getAllTime (time) {
    var hours = getHoursAndMins(time)

    var year = new Date(time.seconds * 1000).getFullYear()
    var month = new Date(time.seconds * 1000).getMonth() + 1;
    if (month < 10) month = '0' + month
    var day = new Date(time.seconds * 1000).getDate()
    if (day < 10 ) day = '0' + day

    return hours + '/' + month + '-' + day +  '-' + year
} 

export function getReviewTime (time) {
    var d = new Date(time.seconds * 1000);
    var month = new Array();
    month[0] = "Jan";
    month[1] = "Feb";
    month[2] = "Mar";
    month[3] = "Apr";
    month[4] = "May";
    month[5] = "June";
    month[6] = "July";
    month[7] = "Aug";
    month[8] = "Sep";
    month[9] = "Oct";
    month[10] = "Nov";
    month[11] = "Dec";
    var cur_month = month[d.getMonth()];

    var year = new Date(time.seconds * 1000).getFullYear()
    var day = new Date(time.seconds * 1000).getDate()
    if (day < 10 ) day = '0' + day

    return cur_month + ' ' + day + ',' + year
}

export function getCommentTime (time) {
    var d = new Date(time);
    var month = new Array();
    month[0] = "Jan";
    month[1] = "Feb";
    month[2] = "Mar";
    month[3] = "Apr";
    month[4] = "May";
    month[5] = "June";
    month[6] = "July";
    month[7] = "Aug";
    month[8] = "Sep";
    month[9] = "Oct";
    month[10] = "Nov";
    month[11] = "Dec";
    var cur_month = month[d.getMonth()];

    var year = new Date(time).getFullYear()
    var day = new Date(time).getDate()
    if (day < 10 ) day = '0' + day

    var half = ''
    var date = new Date(time);
    var hours = date.getHours();
    if (hours > 12) {
        half = "p"
    } else {
        half = "a"
    }
    if (hours < 10) hours = '0' + hours

    var mins = date.getMinutes();
    if (mins < 10 ) mins = '0' + mins

    return day + ' ' + cur_month + ' ' + year + ' ' + half + ' ' + hours + ':' + mins
}