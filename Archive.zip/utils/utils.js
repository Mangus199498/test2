export const Google_API_KEY = "AIzaSyDiU9bDt5maBts7nrolXHlntqxAsPsKfyE";
export let groupId = '';
export let postId = '';
export let planId = '';

export function replacetext (text) {
    if (text.length > 13) {
        return (text).substring(0,13) + ' ...';
    } else {
        return text ;
    }
    
}

export function replaceGroupTitle (text) {
    if (text.length > 7) {
        return (text).substring(0,7) + ' ...';
    } else {
        return text ;
    }
    
}

export function replaceTitle (text) {
    if (text.length > 18) {
        return (text).substring(0,18) + ' ...';
    } else {
        return text ;
    }
    
}

export function replaceHeadertitle (text) {
    if (text.length > 28) {
        return (text).substring(0,28) + ' ...';
    } else {
        return text ;
    }
    
}

export function replaceDescription (text) {
    if (text.length > 85) {
        return (text).substring(0,85) + ' ...';
    } else {
        return text ;
    }
    
}

export function removePlusCharacter(phone_number,country_code) {
    var isValid = true
    for (var i =0 ;i < phone_number.length; i++) {
        if (phone_number[i] == '+') {
            isValid = false
        }
    }
    var temp_str = ''
    if (!isValid) { //if phone number has +
        for (var i = 0 ;i < phone_number.length; i++) {
            var isChecked = true
            for (var j = 0; j < country_code.length; j++) {
                if (phone_number[i] == country_code[j] && (i - 1) <= country_code.length ) {
                    isChecked = false
                }
                if (phone_number[i] == " ") {
                    isChecked = false
                }
            }
            if (isChecked) {
                temp_str += phone_number[i]
            }
        }   
    } else {
        for (var i = 0 ;i < phone_number.length; i++) { 
            if (phone_number[i] != " ")
                temp_str += phone_number[i]
        }
    }
    return temp_str;
 }

//encrypt
export function encryptString(input:string = ''){
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
    let str = input;
    let output = '';

    for (let block = 0, charCode, i = 0, map = chars;
    str.charAt(i | 0) || (map = '=', i % 1);
    output += map.charAt(63 & block >> 8 - i % 1 * 8)) {

      charCode = str.charCodeAt(i += 3/4);

      if (charCode > 0xFF) {
        throw new Error("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
      }

      block = block << 8 | charCode;
    }

    return output;
}
export function decryptString(input:string = ''){
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
    let str = input.replace(/=+$/, '');
    let output = '';

    if (str.length % 4 == 1) {
      throw new Error("'atob' failed: The string to be decoded is not correctly encoded.");
    }
    for (let bc = 0, bs = 0, buffer, i = 0;
      buffer = str.charAt(i++);

      ~buffer && (bs = bc % 4 ? bs * 64 + buffer : buffer,
        bc++ % 4) ? output += String.fromCharCode(255 & bs >> (-2 * bc & 6)) : 0
    ) {
      buffer = chars.indexOf(buffer);
    }

    return output;
}



export function saveGroupId (id) {
    groupId = id;
}
export function savePostId (id) {
    postId = id;
}
export function savePlanId (id) {
    planId = id;
}