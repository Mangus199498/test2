import firebase, { _fireStore } from './firebase';
// import { observable, action } from 'mobx';
// import { inject, observer } from "mobx-react";

const FAQ_PATH = 'faq';

export default class FaqService { 

  addFaqData(faq) {
    return _fireStore.collection(FAQ_PATH).add(faq).then(_ => {
    });
  }

  getFaqData() {
    return _fireStore.collection(FAQ_PATH).get(); 
  }
}