import firebase, { _fireStore } from './firebase';
import async from 'async';

const FRIENDS_PATH = 'friends';

export default class FriendService { 

    inviteFriend (uid) {
        return _fireStore.collection(FRIENDS_PATH).where("uid", "==", uid).get();
    }
    updateFriendById(id, data) {
        return _fireStore.collection(FRIENDS_PATH).doc(id).update(data)
    }
    updateFriend (data, obj){
        var friends_arr = data.friends_arr;
        var add_obj = {
            uid : obj.friend_uid,
            status : obj.status,
        }
        console.log(friends_arr)
        friends_arr.push(add_obj)
        var friend_data = {
            uid : obj.uid,
            friends_arr : friends_arr,
            id : data.id
        }
        return _fireStore.collection(FRIENDS_PATH).doc(data.id).update(friend_data)
    }
    addFriend(obj) {
        var friends_arr = [];
        var add_obj = {
            uid : obj.friend_uid,
            status : obj.status
        }
        friends_arr.push(add_obj)

        var friend_data = {
            uid : obj.uid,
            friends_arr : friends_arr,
            id : ''
        }
        friend_data.id = _fireStore.collection(FRIENDS_PATH).doc().id

        return _fireStore.collection(FRIENDS_PATH).doc(friend_data.id).set(friend_data)
    }


    searchFriend (searchKey, callb) {
        _fireStore.collection("users").orderBy('f_name').startAt(searchKey).endAt(searchKey+"\uf8ff").get().then(result =>{
            const data = result.docs.map(doc => doc.data());
            callb(data)
        })
    }
    getFriendData (uid) {
        return _fireStore.collection(FRIENDS_PATH).where("uid", "==", uid);
    }
    getFriendSearchData(uid) {
        return _fireStore.collection(FRIENDS_PATH).where("uid", "==", uid).get();
    }
}