import firebase, { _fireStore } from './firebase';
import async from 'async';

const NOTIFICATION_PATH = 'notifications';

export default class NotificationService { 

  addNotification(data) {
    data.id = _fireStore.collection(NOTIFICATION_PATH).doc().id;
    return _fireStore.collection(NOTIFICATION_PATH).doc(data.id).set(data).then(_ => {
    });
  }
  updateNotification(id, data) {
    return _fireStore.collection(NOTIFICATION_PATH).doc(id).update(data).then(_ => {

    });
  }

  getDataById(id) {
    return _fireStore.collection(NOTIFICATION_PATH).doc(id);
  }

  getAllData(uid) {
    return  _fireStore.collection(NOTIFICATION_PATH).where("recv_uid" , "==", uid);
  }

  //push notification data
  getAllPushNotificationData(uid) {
    return _fireStore.collection(NOTIFICATION_PATH).where("recv_uid", "==", uid).where("isNotification", "==" , 0).where("is_read","==",0);
  }
  getInitPushData(uid) {
    return _fireStore.collection(NOTIFICATION_PATH).where("recv_uid", "==", uid).where("isNotification", "==" , 0).where("is_read","==",0).get();
  }

  deletteNotificationById(id) {
    return _fireStore.collection(NOTIFICATION_PATH).doc(id).delete()
  }

}