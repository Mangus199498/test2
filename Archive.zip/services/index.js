
import firebase from "./firebase";
import AuthService from "./auth.service";
import UserService from "./user.service";
import StorageService from './storage.service';
import PostService from './post.service';
import FaqService from './faq.service';
import PlanService from './plan.service';
import GroupService from './group.service';
import NotificationService from './notification.service';
import FriendService from './friend.service';
import MessageService from './message.service';
import CardService from './card.service';


const authService = new AuthService;
const userService = new UserService;
const storageService = new StorageService;
const postService = new PostService;
const faqService = new FaqService;
const planService = new PlanService;
const groupService = new GroupService;
const notificationService = new NotificationService;
const friendService  = new FriendService;
const messageService = new MessageService; 
const cardService = new CardService;

export default services = {
  firebase,
  authService,
  userService,
  storageService,
  postService,
  faqService,
  planService,
  groupService,
  notificationService,
  friendService,
  messageService,
  cardService,
};