import firebase, { _fireStore } from './firebase';
import async from 'async';
import { saveGroupId } from '../utils/utils';

const GROUP_PATH = 'groups';

export default class GroupService { 

  addGroup(data) {
    data.id = _fireStore.collection(GROUP_PATH).doc().id;
    saveGroupId(data.id)
    return _fireStore.collection(GROUP_PATH).doc(data.id).set(data).then(_ => {
    });
  }
  updateGroup(id,data) {
    return _fireStore.collection(GROUP_PATH).doc(id).update(data).then(_ => {

    })
  }
  getMyGroupDataByUID(uid) {
    return _fireStore.collection(GROUP_PATH).where("uid", "==", uid);
  }
  getGroupDataUID(uid) {
    return _fireStore.collection(GROUP_PATH).where("friends_arr", "array-contains", uid);
  }

  getPublicGroupData() {
    return _fireStore.collection(GROUP_PATH).where("privacy","==", "0");
  }

  // getGroupData() {
  //   var count = 0;
  //   return new Promise ((resolve , rejects) => {
  //     _fireStore.collection(GROUP_PATH).onSnapshot(function(result) {
  //       const data = result.docs.map(doc => doc.data());
  //       console.log(data)
  //       if (data.length > 0) {
  //         data.forEach(element => {
  //           _fireStore.collection('users').doc(element.uid).onSnapshot(function(res){
  //             if (res.exists) {
  //               element.uid = res.data()
  //             }
  //             count ++;
  //             if (count == data.length) {
  //               resolve(data)
  //             }
  //           })
  //         });
  //       } else {
  //           resolve('')
  //       }
  //     })
  //   }) 
  // }
  getDataById(id) { //detail group
    return _fireStore.collection(GROUP_PATH).doc(id);
  }

  //fixed get data 
  getDataByf_Id(id) { //detail group
    return _fireStore.collection(GROUP_PATH).doc(id).get();
  }

  getGroupDataByUpdateId(id) {
    return _fireStore.collection(GROUP_PATH).doc(id).get();
  }
}