import firebase, { fireStore, _fireStore, _fireAuth, _fireStorage } from './firebase';

export default class StorageService {

  uploadAvatarImage(uid, picture) {
    const timestamp = new Date().getTime();
    const photoname = picture.path.split('\\').pop().split('/').pop();
    const photoStorageUri = `avatars/${uid}/${timestamp}_${photoname}`;
    const storageRef = firebase.storage().ref(photoStorageUri);
    
    const metadata = {
      contentType: picture.mime,
    };
  
    return new Promise((resolve, reject) => {
      try {
        const uploadTask = storageRef.putFile(picture.path, metadata);
        uploadTask.on('state_changed', function(snapshot) {
          // Observe state change events such as progress, pause, and resume
          // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded
          var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log('snapshot.bytesTransferred', snapshot.bytesTransferred);
          console.log('Upload is ' + progress + '% done');
          switch (snapshot.state) {
            case firebase.storage.TaskState.PAUSED: // or 'paused'
              console.log('Upload is paused');
              break;
            case firebase.storage.TaskState.RUNNING: // or 'running'
              console.log('Upload is running');
              break;
          }
        }, function(error) {
          // Handle unsuccessful uploads
          alert(JSON.stringify(err));
          reject(err);
        }, function(handler) {
          // Handle successful uploads on complete
          // For instance, get the download URL: https://firebasestorage.googleapis.com/...
          var downloadURL = handler.downloadURL;
          resolve({photoStorageUri: handler.ref.fullPath, url: downloadURL});
        });

      } catch (err) {
        alert('ERROR' + JSON.stringify(err));
        reject(err);
      }
    });
  }
  uploadImage(uid, picture) {
    const timestamp = new Date().getTime();
    const photoname = picture.path.split('\\').pop().split('/').pop();
    const photoStorageUri = `images/${uid}/${timestamp}_${photoname}.jpg`;
    const storageRef = firebase.storage().ref(photoStorageUri);
    
    const metadata = {
      contentType: picture.mime,
    };
  
    return new Promise((resolve, reject) => {
      try {
        const uploadTask = storageRef.putFile(picture.path, metadata);
        uploadTask.on('state_changed', function(snapshot) {
          var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log('snapshot.bytesTransferred', snapshot.bytesTransferred);
          console.log('Upload is ' + progress + '% done');
          switch (snapshot.state) {
            case firebase.storage.TaskState.PAUSED: // or 'paused'
              console.log('Upload is paused');
              break;
            case firebase.storage.TaskState.RUNNING: // or 'running'
              console.log('Upload is running');
              break;
          }
        }, function(error) {
          // Handle unsuccessful uploads
          alert(JSON.stringify(err));
          reject(err);
        }, function(handler) {
          // Handle successful uploads on complete
          // For instance, get the download URL: https://firebasestorage.googleapis.com/...\
          console.log(handler.downloadURL);
          var downloadURL = handler.downloadURL;
          resolve({photoStorageUri: handler.ref.fullPath, url: downloadURL});
        });

      } catch (err) {
        alert('ERROR' + JSON.stringify(err));
        reject(err);
      }
    });
  }
  uploadFile(uid, media, doInProgress) {
    const timestamp = new Date().getTime();
    const photoname = media.path.split('\\').pop().split('/').pop();
    const photoStorageUri = `medias/${uid}/${timestamp}_${photoname}`;
    const storageRef = firebase.storage().ref(photoStorageUri);

    const metadata = {
      contentType: media.mime,
    };
    
    const mediaType = media.mime.indexOf('video') !== -1 ? 'video' : 'photo';
    const mediaMime = media.mime;
  
    return new Promise((resolve, reject) => {
      try {
        const uploadTask = storageRef.putFile(media.path, metadata);
        uploadTask.on('state_changed', function(snapshot){
          // Observe state change events such as progress, pause, and resume
          // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded
          var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log('snapshot.bytesTransferred', snapshot.bytesTransferred);
          console.log('Upload is ' + progress + '% done');
          switch (snapshot.state) {
            case firebase.storage.TaskState.PAUSED: // or 'paused'
              console.log('Upload is paused');
              break;
            case firebase.storage.TaskState.RUNNING: // or 'running'
              console.log('Upload is running');
              break;
          }
          if(doInProgress != undefined) {
            doInProgress(uploadTask, progress);
          }
        }, function(error) {
          // Handle unsuccessful uploads
          console.log('errrrrrrrrrr', error);
          reject(error);
        }, function(handler) {
          var downloadURL = handler.downloadURL;
          resolve({storageUri: handler.ref.fullPath, downloadUrl: downloadURL, mediaType: mediaType, mediaMime: mediaMime});
        });

      } catch (err) {
        console.log('errrvvvvvvvvvvv', error);
        reject(err);
      }
    });
  }

  getThumbnail(storagePath) {
    const headers = {};
    headers['Accept'] = 'application/json';
    headers['Content-Type'] = 'application/json';
    
    const url = `${apiEndPoint}/getThumbnail`;
    const method = 'POST';
    const body = JSON.stringify({media_path: storagePath});
  }

  
  deleteFile(media) {
    firebase.storage().ref(media.storageUri).delete().then().catch();
    firebase.storage().ref(media.thumbFilePath).delete().then().catch();
  }
}
