import firebase, { _fireStore } from './firebase';
const CARD_PATH = 'cards';

export default class CardService { 

  addCard(card_obj) {
    card_obj.id = _fireStore.collection(CARD_PATH).doc().id;
    return _fireStore.collection(CARD_PATH).add(card_obj).then(_ => {
    });
  }

  getCardData(uid) {
    return _fireStore.collection(CARD_PATH).where('uid', '==',uid); 
  }
}