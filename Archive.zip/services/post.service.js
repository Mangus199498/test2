import { _fireAuth, _fireStore } from './firebase';
import async from 'async';
import { savePostId } from '../utils/utils';

POST_PAHT ="posts";
export default class PostService {

    addPostData(data) {
        const userData = Object.assign({}, data);
        userData.id = _fireStore.collection(POST_PAHT).doc().id;
        savePostId(userData.id)
        return _fireStore.collection(POST_PAHT).doc(userData.id).set(userData).then(_ => {

        })
    }
    getAllDataByPublic() {
      return _fireStore.collection(POST_PAHT).where('privacy', '==', 0);
    }

    getAllDataByPrivate (uid) {
      return _fireStore.collection(POST_PAHT).where('friend_arr', 'array-contains', uid);
    }

    getAllDataByUID (uid) {
        return _fireStore.collection(POST_PAHT).where("uid", "==" , uid); 
    }
    getDataById(id) {
      return _fireStore.collection(POST_PAHT).doc(id);
    }

    //get data fix
    getDataById_F(id) {
      return _fireStore.collection(POST_PAHT).doc(id).get()
    }

    updateData(id, data) {
      return _fireStore.collection(POST_PAHT).doc(id).update(data).then(_ => {
          
      })
    }

    getFavoriteData (uid) {
      return _fireStore.collection(POST_PAHT).where('favorite', 'array-contains', uid)
    }
}