import firebase, { _fireStore , _fireAuth, _fireStorage} from './firebase';
import async from 'async';
import { savePlanId } from '../utils/utils';
const PLAN_PATH = 'plans';

export default class PlanService { 

  addPlanData(data) {
    data.id = _fireStore.collection(PLAN_PATH).doc().id;
    savePlanId(data.id)
    return _fireStore.collection(PLAN_PATH).doc(data.id).set(data).then(_ => {

    })
  }
  getAllData () {
    return _fireStore.collection(PLAN_PATH);
  }

  getAllDataByPublic () {
    return _fireStore.collection(PLAN_PATH).where('privacy', '==', 0);
  }
  getAllDataByPrivate (uid) {
    return _fireStore.collection(PLAN_PATH).where("friend_arr", "array-contains", uid)
  }

  getDataById(id) {
    return _fireStore.collection(PLAN_PATH).doc(id);
  }
  //get data fix id
  getDataByf_id (id) {
    return _fireStore.collection(PLAN_PATH).doc(id).get();
  }

  getAllDataByUID(uid) {
    return _fireStore.collection(PLAN_PATH).where("uid", "==", uid);
  }
  updateData(id, data) {
    return _fireStore.collection(PLAN_PATH).doc(id).update(data).then(_ => {
            
    })
  }

}