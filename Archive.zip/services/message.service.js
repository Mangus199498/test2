import firebase, { _fireStore } from './firebase';
// import { observable, action } from 'mobx';
// import { inject, observer } from "mobx-react";

const MESSAGE_PATH = 'messages';
const GROUP_MESSAGE_PATH = 'group_messages';

export default class MessageService { 
    addGroupMessage (data) {
        data.id = _fireStore.collection(GROUP_MESSAGE_PATH).doc().id;
        return _fireStore.collection(GROUP_MESSAGE_PATH).doc(data.id).set(data)
    }
    getGroupMessageData(uid) {
        return _fireStore.collection(GROUP_MESSAGE_PATH).where("user_data", "array-contains", uid);
    }

    getDataByUID(uid) { //no snapshot
        return _fireStore.collection(GROUP_MESSAGE_PATH).where("user_data", "array-contains", uid).get();
    }

    getGroupMessageDataById(id) {
        return _fireStore.collection(GROUP_MESSAGE_PATH).doc(id)
    }
    removeGroupMessage (id) {
        return _fireStore.collection(GROUP_MESSAGE_PATH).doc(id).delete().then(_ => {
            
        })
    }

    updateGroupMessage (id, data) {
        return _fireStore.collection(GROUP_MESSAGE_PATH).doc(id).update(data).then(_ => {
            
        });
    }
    
    addMessage(data) {
        data.id = _fireStore.collection(MESSAGE_PATH).doc().id;
        return _fireStore.collection(MESSAGE_PATH).doc(data.id).set(data)
    }
    getMessageData(uid) {
        return _fireStore.collection(MESSAGE_PATH).where("user_data", "array-contains", uid);
    }

    getMessageInfoById (id) {
        return _fireStore.collection(MESSAGE_PATH).doc(id)
    }
    updateMessage (id, data) {
        return _fireStore.collection(MESSAGE_PATH).doc(id).update(data).then(_ => {
            
        });
    }
    removeMessage (id) {
        return _fireStore.collection(MESSAGE_PATH).doc(id).delete().then(_ => {
            
        })
    }
}