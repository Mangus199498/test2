import firebase from 'react-native-firebase';
const firebaseConfig = {
  apiKey: "AIzaSyAz-gmh0RdefLio_wSDcc5NrTGYODn0yFQ",
  authDomain: "ytravel-2552d.firebaseapp.com",
  databaseURL: "https://ytravel-2552d.firebaseio.com",
  projectId: "ytravel-2552d",
  storageBucket: "ytravel-2552d.appspot.com",
  messagingSenderId: "990212510702",
  appId: "1:990212510702:web:c5f753399003c1e092f4ff"
};
firebase.initializeApp(firebaseConfig);

export const fireStore  = firebase.firestore;
export const fireAuth   = firebase.auth;
export const fireStorage = firebase.storage;

export const _fireStore  = firebase.firestore();
export const _fireAuth   = firebase.auth();
export const _fireStorage = firebase.storage();

export default firebase;