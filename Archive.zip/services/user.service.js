import firebase, { _fireStore, _fireAuth } from './firebase';
// import { observable, action } from 'mobx';
// import { inject, observer } from "mobx-react";

const USERS_PATH = 'users';
export default class UserService { 
  
  currentUser = null;

  storeUser(user) {
      user.created_at = firebase.firestore.FieldValue.serverTimestamp();
      const userData = Object.assign({}, user);
      return _fireStore.collection(USERS_PATH).doc(user.uid).set(userData).then(_ => {
      });
  }

  addSocialUser(data) {
    data.uid = _fireStore.collection(USERS_PATH).doc().id;
    return _fireStore.collection(USERS_PATH).doc(data.uid).set(data).then(_ => {
      
    });
  }

  getTwitterUser(email) {
    return _fireStore.collection(USERS_PATH).where("email", "==", email).where("twitter", "==" , true).get();
  }

  getGoogleUser(email) { //google and facebook
    return _fireStore.collection(USERS_PATH).where("email", "==", email).where("google", "==" , true).get();
  }

  getFBUser(email) { //fb and facebook
    return _fireStore.collection(USERS_PATH).where("email", "==", email).where("fb", "==" , true).get();
  }


  getCurrentAuthInfo() {
    return new Promise((resolve, reject) =>{
      _fireAuth.onAuthStateChanged((user) => {
        if (user) {
          resolve(user)
        } else {
          resolve(null)
        }
      })
    })
    
    
  }

  getUserData(uid) {
    return _fireStore.collection(USERS_PATH).doc(uid).get();
  }

  updateUser(user) {
    return _fireStore.collection(USERS_PATH).doc(user.uid).update(user).then(_ => {

    });
  }

  changeEmail (email) {
    var user = _fireAuth.currentUser;
    return user.updateEmail(email);
  }

  changePassword (password) {
    var user = _fireAuth.currentUser;
    return user.updatePassword(password);
  }
  //forgot password
  getUserDataByEmail(email) {
    return _fireStore.collection(USERS_PATH).where("email", "==", email).where("normal", "==" , true).get();
  }

  sendEmail(email) {
    var number = Math.floor(Math.random() * (9999 - 1000) + 1000);
    var url = "https://us-central1-mybarproject-493e7.cloudfunctions.net/send_eamil?email=" + email + '&number=' + number

    return fetch(url , {
      method : 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    }).then(result => {
      var res = {
        status : 'success',
        message : 'OK',
        rnKey : number
      }
      return res;
    }).catch(error => {
      var res = {
        status : 'failed',
        message : 'Failed to send email. Try again later'
      }
      return res
    })
  }

}