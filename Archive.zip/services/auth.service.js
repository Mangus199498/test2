import { _fireAuth, _fireSotre } from './firebase';
export default class AuthService {

  signInWithEmailPassword(email, password) {
    return _fireAuth.signInWithEmailAndPassword(email, password);
  }

  signUpWithEmailPassword(email, password) {
    return new Promise((resolved, rejected) => {
      _fireAuth.createUserWithEmailAndPassword(email, password).then((data) => {
        resolved(data);
      }).catch(err => {
        rejected(err);
      });
    });
    
  }
  signOut() {
    return _fireAuth.signOut();
  }
}