
import React from "react";
//import  from './config';
import  Firebase  from './Firebase';
import * as firebase from "firebase";
import firestore from 'firebase/firestore';

export const loginUser = (obj) => {
   //alert(JSON.stringify(obj))
   return firebase.auth().signInWithEmailAndPassword(obj.email , obj.password);
}
export  const signupUser = (obj) => {
   return firebase.auth().createUserWithEmailAndPassword(obj.email, obj.password);
}
export const uploadImage = (photo) => {
   return new Promise((resolve, reject) => {
      let storageRef = firebase.storage().ref();
      const filename = new Date().getTime();
      const imageRef = storageRef.child(
         'images/profilephoto' + filename + '.jpg'
      );
      imageRef.putString(photo, 'data_url').then(snapshot => {
         console.log('download', snapshot.metadata.fullPath);
         imageRef.getDownloadURL().then(url => {
            resolve(url);
         })
      }).catch(error => {
         console.log('this is error', error.message);
         reject(error);
      })
  })
}
export const createUserData = (obj) => {
   var afs = firebase.firestore().collection('users')
   return afs.add(obj);
}
