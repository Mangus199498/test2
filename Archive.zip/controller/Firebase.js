import * as firebase from "firebase";
import firestore from 'firebase/firestore';
const firebaseConfig = {
    apiKey: "AIzaSyDrfkhTyf3-a-KupuO4M8kw1CipcKQplBs",
    authDomain: "ytravel-f5535.firebaseapp.com",
    databaseURL: "https://ytravel-f5535.firebaseio.com",
    projectId: "ytravel-f5535",
    storageBucket: "ytravel-f5535.appspot.com",
    messagingSenderId: "331775958938",
    appId: "1:331775958938:web:52983379df008fc6"
};
export default class Firebase {
    
    static auth ;
    static init () {
        if (!firebase.apps.length) {
            firebase.initializeApp(firebaseConfig);
        } else {
            firebase.app();
        }
        Firebase.auth = firebase.auth();
    }
}