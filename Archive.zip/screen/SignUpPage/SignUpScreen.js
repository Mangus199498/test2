import React, { Component } from 'react';
import {View ,Text,StyleSheet,TouchableOpacity, Image,TextInput ,ToastAndroid,Picker, ScrollView, Modal,Alert, Button, Platform} from 'react-native';
import PropTypes from 'prop-types'
import global_style, { metrics } from '../../constants/globalStyles';
import { inject, observer } from "mobx-react";
import LoadingBar from '../../components/LoadingBar';
import { Input , Avatar} from 'react-native-elements';
//import ImagePicker from 'react-native-image-picker';
import ImagePicker from 'react-native-image-crop-picker';
import RNPickerSelect from 'react-native-picker-select';
import PhoneInput from 'react-native-phone-input';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import AuthService from '../../services/auth.service';
import UserService from '../../services/user.service';
import checkImg from '../../assets/img/icon/ico_checked.png';
import unCheckImg from '../../assets/img/icon/ico_uncheck.png';
import { encryptString ,decryptString,removePlusCharacter} from '../../utils/utils';

let _this = null;

@inject("authService")
@inject("userService")
@inject("storageService")
//@inject("storageService")
@observer

class SignUpScreen extends Component {
   constructor (props) {
      super(props)
   }
   _authService : AuthService = this.props.authService ;
   _userService : UserService = this.props.userService;
   _storageService : StorageService = this.props.storageService;

   state = {
      f_name: '',
      l_name: '',
      email : '',
      gender: 0,
      phone_number : '',
      password : '',
      confirm_password: '',
      termService : false, 
      isLoading : false, // loading true
      btn_flag: false, //clicked register btn
      email_valid : false,
      errorState : false,
      errorMessage : '',
      profile_img : '',
      imgData : '',
      phone_valid : false,
      country_code : '+1'
   }

   static navigationOptions = ({ navigation }) => {
      const { params = {} } =  navigation.state;
      return {
         headerLeft: (
             <View style={global_style.navigation}>
                 <TouchableOpacity 
                     style={styles.backarrow}
                     onPress={() => navigation.goBack()} >
                         <Image source = {require('../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                         <Text style={[global_style.back_title, {fontSize : 22 * metrics}]}> SIGN UP</Text>
                 </TouchableOpacity>
             </View>
         ),
         headerStyle: global_style.headerHeight,
     };
   }

   registerBtn =() => { //register user
      var phone_num = removePlusCharacter(this.state.phone_number , this.state.country_code)
      this.setState({phone_number : phone_num})
      this.setState({btn_flag : true});
      if (!this.validate_func()) 
         return;
      if (this.state.imgData == '') {
         return;
      }
      var encryptStr = encryptString(this.state.password); // encrypt
      var obj = {
         f_name : this.state.f_name,
         l_name : this.state.l_name,
         email : this.state.email,
         gender : this.state.gender,
         phone_number : phone_num,
         country_code : this.state.country_code,
         token : encryptStr,
         img_url : '',
         uid : '',
         membership : 'free',
      }
      this.setState({isLoading : true})
      this._authService.signUpWithEmailPassword(this.state.email, this.state.password).then((result) => {
         obj.uid = result.user.uid;
         this._storageService.uploadAvatarImage(obj.uid, this.state.imgData).then((data) => {
            obj.img_url = data.url;
            this._userService.storeUser(obj).then((res) => {
               this.setState({isLoading : false})
               this.props.navigation.navigate('LoginScreen');
            }).catch((error) => {
               this.setState({isLoading : false})
               this.setState({errorState : true})
               this.setState({errorMessage : error.message})
            })
         }).catch((error) => {
            this.setState({isLoading : false})
            this.setState({errorState : true})
            this.setState({errorMessage : error.message})
         })
         
      }).catch((error) => {
         this.setState({isLoading : false})
         this.setState({errorState : true})
         this.setState({errorMessage : error.message})
      })
   }
   selectedGender =(value) => { //gender select
      this.setState({gender : value})
   }
   componentWillMount () { //init function 
      _this = this;
      this.props.navigation.setParams({isLoading : true});
   }

   checkedTermService = () => { // check box
      if (this.state.termService) {
         this.setState({termService : false});
      } else {
         this.setState({termService : true});
      }

   }

   selectedCamera =()=> {
      ImagePicker.openCamera({
         width: 300,
         height: 400,
         cropping: true,
      }).then(image => {
         this.setState({imgData : image})
         let source = {uri : image.path}
         this.setState({
            profile_img: source,
         });
      }).catch((error) => {
         console.log(error)
      });
   }
   selectedGallery = () => {
      ImagePicker.openPicker({
         width: 300,
         height: 400,
         cropping: true,
      }).then(image => {
         this.setState({imgData : image})
         let source = {uri : image.path}
         this.setState({
            profile_img: source,
         });
      }).catch((error) => {
         console.log(error)
      });
   } 
   selectPhotoTapped = () => {
      Alert.alert(  
         'Avatar',  
         'Select your photo',  
         [  
               {text: 'Cancel', onPress: () => console.log('Ask me later pressed')},  
               {text: 'Camera',onPress: () => this.selectedCamera()},  
               {text: 'Gallery', onPress: () => this.selectedGallery()},  
         ],  
         {cancelable: false}  
      )  
   }
   validate_func() {
      if (this.state.f_name == '' || this.state.l_name == '') {
         return false;
      }
      if (this.state.phone_number == '') {
         return false;
      }
      if (this.state.email_valid == false) {
         return false;
      }
      if (this.state.confirm_password != this.state.password) {
         return false;
      }
      if (this.state.termService == false) {
         return false;
      }
      return true;
   }
   validateText = (text) => {
      let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;
      if(reg.test(text) === false)
      {
         this.setState({email_valid : false})
         this.setState({email:text})
         return false;
      }
      else {
         this.setState({email_valid : true})
         this.setState({email:text})
      }
   }
   
   changeMobileNumber = (value) => {
      this.setState({phone_valid : this.phone.isValidNumber()})
      this.setState({country_code : '+' + this.phone.getCountryCode()})
      this.setState({phone_number : value})
   }

   render() {
      return (
         <View style = {{width: '100%', height : '100%'}}>
            <KeyboardAwareScrollView
               resetScrollToCoords={{ x: 0, y: 0 }}
               contentContainerStyle={{flex : 1}}
               scrollEnabled={false}
            >
            <ScrollView style={global_style.body}>
               <View style={{flexDirection : 'row'}}>
                  <View style ={{flex : 2}}></View>
                  <View style={global_style.photo}>
                     <TouchableOpacity onPress={()=> this.selectPhotoTapped()}>
                        <Avatar
                           rounded
                           overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                           size="xlarge"
                           source={this.state.profile_img}
                           resizeMode={'stretch'}
                           containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                           style = {{width : 130, height : 130,}}
                        />
                        <View style={{position : 'absolute',width:'100%' , height:'100%' ,justifyContent:'center'}}>
                           <Image source = {require('../../assets/img/icon/camera.png')} style={styles.carmera}/> 
                        </View>
                     </TouchableOpacity>
                  </View>
                  <View style ={{flex : 2}}></View>
               </View>
               {
                  this.state.imgData == "" && this.state.btn_flag? 
                  <View style={{width : '100%'}}>
                     <Text style={{textAlign : 'center', marginTop : 5, color : 'red'}}>Please select your photo</Text>
                  </View>
                  : null
               }
               <View style ={global_style.form_body}>
                  <View style ={global_style.name}>
                     <View style ={global_style.first_name}>
                        <Text style={styles.sub_title}>First name</Text>
                        <TextInput 
                           underlineColorAndroid = "transparent"
                           placeholder = ""
                           placeholderTextColor = "gray"
                           autoCapitalize = "none"
                           onChangeText={(text) => this.setState({f_name : text})}
                           style={global_style.name_input}/>
                        <Text style={(this.state.btn_flag && this.state.f_name == '') ? styles.error : styles.non_error}> First name is required.</Text>
                     </View>
                     <View></View>
                     <View style ={global_style.last_name}>
                        <Text style={styles.sub_title}>Last name</Text>
                        <TextInput 
                           underlineColorAndroid = "transparent"
                           placeholder = ""
                           placeholderTextColor = "gray"
                           autoCapitalize = "none"
                           onChangeText={(text) => this.setState({l_name : text})}
                           style={global_style.name_input}/>
                        <Text style={[(this.state.btn_flag &&this.state.l_name == '') ? styles.error : styles.non_error , {alignSelf : 'flex-start'}]}> Last name is required.</Text>
                     </View>
                  </View>

                  <View style={global_style.wrapper}>
                     <Text style={styles.sub_title}>Email</Text>
                     <TextInput 
                        underlineColorAndroid = "transparent"
                        placeholder = ""
                        placeholderTextColor = "gray"
                        autoCapitalize = "none"
                        onChangeText={(text) => this.validateText(text)}
                        style={global_style.text_input}
                     />
                     <Text style={this.state.btn_flag &&!this.state.email_valid && this.state.email != '' ? styles.error : styles.non_error}> Please enter a valid email. </Text>
                     <Text style={(this.state.btn_flag && this.state.email == '') ? styles.error : styles.non_error}> Email is required.</Text>
                  </View>
                  <View style={global_style.wrapper}>
                     <Text style={styles.sub_title}>Phone</Text>
                     <PhoneInput
                        ref={ref => {
                           this.phone = ref;
                        }}
                        //onChangePhoneNumber = {(value) => this.setState({validate : { phone : value , email : this.state.validate.email} })}
                        style={global_style.text_input}
                        onChangePhoneNumber = {(value) => this.changeMobileNumber(value)}
                     />
                     <Text style={(this.state.btn_flag && this.state.phone_number != "" && !this.state.phone_valid) ? styles.error : styles.non_error}> Please enter a valid phonenumber.</Text>
                     <Text style={(this.state.btn_flag && this.state.phone_number == '') ? styles.error : styles.non_error}> Phone number is required.</Text>
                  </View>
                  <View style={[global_style.wrapper, {borderBottomWidth : 1, borderBottomColor : '#d8d8d8'}]}>
                     <Text style={styles.sub_title}>Gender</Text>
                     <View style={{ marginTop : 10 , marginBottom : 10}}>
                        {
                           Platform.OS == 'android' && 
                           <Picker selectedValue = {this.state.gender} onValueChange = {this.selectedGender} style={styles.gender}>
                              <Picker.Item label = "Male" value = '0'style ={{width : '100%'}}/>
                              <Picker.Item label = "Female" value = '1' style ={{width : '100%'}}/>
                           </Picker> 
                        }
                        {
                           Platform.OS == 'ios' &&
                           <RNPickerSelect
                              placeholder ="Select Gender"
                              onValueChange={(value) => this.selectedGender(value)}
                              items={[
                                 { label: 'Male', value: 0 },
                                 { label: 'Female', value: 1 },
                              ]}
                           />
                        }
                     </View>
                  </View>
                  <View style={global_style.wrapper}>
                     <Text style={styles.sub_title}>Password</Text>
                     <TextInput 
                        underlineColorAndroid = "transparent"
                        placeholder = ""
                        placeholderTextColor = "gray"
                        autoCapitalize = "none"
                        onChangeText={(text) => this.setState({password : text})}
                        style={global_style.text_input}
                        secureTextEntry={true} 
                     />
                     <Text style={(this.state.btn_flag && this.state.password.length < 6) ? styles.error : styles.non_error}> Password must be at least 6 characters long.</Text>
                  </View>
                  <View style={global_style.wrapper}>
                     <Text style={styles.sub_title}>Confrim Password</Text>
                     <TextInput 
                        underlineColorAndroid = "transparent"
                        placeholder = ""
                        placeholderTextColor = "gray"
                        autoCapitalize = "none"
                        onChangeText={(text) => this.setState({confirm_password : text})}
                        style={global_style.text_input}
                        secureTextEntry={true} 
                     />
                     <Text style={(this.state.btn_flag && this.state.confirm_password.length < 6)  ? styles.error : styles.non_error}> Password must be at least 6 characters long.</Text>
                     <Text style={(this.state.btn_flag && (this.state.confirm_password != this.state.password) && (this.state.confirm_password.length > 6 && this.state.password.length > 6))  ? styles.error : styles.non_error}> Mismatch password. Please check it.</Text>
                  </View>
                  
                  <View style={global_style.check}>
                  {/* this is error message  */}
                  { 
                     this.state.errorState && this.state.btn_flag ? 
                     <View style={{width : '100%', marginBottom : 5}}>
                        <Text style={{textAlign : 'center', color : 'red'}}>{this.state.errorMessage}</Text>
                     </View>
                     : null
                  }
                  {/* this is error message  */}
                     <TouchableOpacity onPress={() => this.checkedTermService()}>
                        <View style={{width : '100%', margin : 'auto', flexDirection : "row"}}>
                           {
                              this.renderButton()
                           }
                           <Text style={{alignItems: 'center',marginLeft :0}}>I agree to the Terms of Service</Text>
                        </View>
                     </TouchableOpacity>
                     <Text style={(this.state.btn_flag && !this.state.termService)  ? styles.error : styles.non_error}> You have to agree Terms of Serivce</Text>
                  </View>

                  <View style={[global_style.register_btn, {marginTop : 20, marginBottom : 20}]}>
                     <TouchableOpacity onPress={() => this.registerBtn()} style={styles.cyan_btn}>
                        <Text style={styles.label}>Register</Text>
                     </TouchableOpacity>
                  </View>
               </View>
            </ScrollView>
            <View style={this.state.isLoading ? styles.loading : styles.finish}>
               <LoadingBar/>
            </View>
            </KeyboardAwareScrollView>
         </View>
      )
   }
   renderButton () {
      var imgSource = this.state.termService ? checkImg : unCheckImg;
      return <Image source = {imgSource} style={styles.check_icon}/>;
   }
}
const styles = StyleSheet.create({
   header : {
      width : '100%',
      height: 60* metrics,
      marginTop: 20* metrics,
      backgroundColor: 'black',
      justifyContent: 'center',
      flexDirection : 'row', 
   },
   carmera : {
      width: 45* metrics,
      height: 35* metrics,
      alignSelf : "center",
      justifyContent : 'center'
   },
   sub_title : {
      alignSelf : 'flex-start',
      color: 'gray'
   },
   check_icon: {
      height: 20* metrics,
      width: 20* metrics,
      resizeMode: 'stretch',
      margin :'auto',
      marginRight : 5* metrics
   },
   cyan_btn : {
      width: '60%',
      height: 45 * metrics,
      marginBottom : 10,
      borderRadius: 40* metrics,
      alignItems: 'center',
      alignSelf : 'center',
      backgroundColor: '#4f80ff',
      shadowColor: '#809adc',
      shadowOffset: { width: 2, height: 2 },
      shadowOpacity: 0.4,
      shadowRadius: 7,  
      elevation : 3.5
   },
   label : {
      height: '100%',
      alignItems: 'center',
      fontSize: 18* metrics,
      color: 'white',
      marginTop: 10* metrics,
   },
   gender : {
      borderWidth : 0,
      borderColor : 'white',
      //height :60 * metrics,
      //backgroundColor : 'red',
      //marginTop : 10* metrics, 
      width : '100%',
      borderBottomColor : '#d8d5d5',
      borderBottomWidth : 1,
      
   },
   loading : {
      position : 'absolute',
      width : '100%',
      height : '100%',
      backgroundColor : 'black',
      opacity : 0.4
   },
   finish : {
      width : 0,
      height : 0,
      position : 'absolute'
   },
   error : {
      color : 'red',
      fontSize : 13* metrics
   }, 
   non_error : {
      display : 'none'
   },
   backarrow : {
      flex: 1,
      flexDirection : 'row',
      width: '100%' ,
   },
   show_view : {
      display : 'flex'
   },
   disable_view : {
      display : 'none'
   },
   center : {
      color : 'red'
   }
})
export default SignUpScreen