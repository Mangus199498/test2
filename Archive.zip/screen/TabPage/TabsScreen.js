import React, { Component } from "react";
import { Text, View, StyleSheet ,TextInput,Image, TouchableOpacity,AsyncStorage, Platform} from "react-native";
import global_style , {metrics} from '../../constants/globalStyles';
import { inject, observer } from "mobx-react";

import homeImg from '../../assets/img/icon/ico_home.png';
import selected_homeImg from '../../assets/img/icon/ico_selected_home.png';
import exploreImg from '../../assets/img/icon/ico_explore.png';
import selected_exploreImg from '../../assets/img/icon/ico_selected_explore.png';
import inboxImg from '../../assets/img/icon/ico-inbox.png';
import selected_inboxImg from '../../assets/img/icon/ico_selected_inbox.png';
import friendImg from '../../assets/img/icon/ico_friend.png';
import selected_friendImg from '../../assets/img/icon/ico_selected_friend.png';
import settingImg from '../../assets/img/icon/ico_setting.png';
import selected_settingImg from '../../assets/img/icon/ico_selected_setting.png';
import search_icon from '../../assets/img/icon/ico_search.png';
import { Avatar} from 'react-native-elements';

import { sortDataByTime , getNotiData , setNotiData} from '../../utils/global';

import Screen from './Screen';

import UserService from '../../services/user.service';
import NotificationService from '../../services/notification.service';
import PushNotification from 'react-native-push-notification';
const styles = StyleSheet.create({
  search : {
    height: 40 * metrics,
    borderWidth : 1,
    borderColor : '#dedede',
    backgroundColor: 'whitesmoke',
    width: '80%',
    alignItems: 'center',
    borderRadius : 5,
    padding : 5,
  },
  profile : {
    width: 35 * metrics,
    height : 35 * metrics,
    resizeMode: "stretch",
    marginTop : 5 * metrics,
  },
  noti_icon : {
    width: 25 * metrics,
    height : 25 * metrics,
    marginTop : 12 * metrics,
    resizeMode: "stretch",
  },
  bottom : {
    height : 60 * metrics,
    width : '100%',
    elevation: Platform.OS == 'ios' ? 0.4 :  10.0,
    shadowOffset : {width : 0, height : Platform.OS == 'ios' ? 1:-10},
    shadowOpacity :Platform.OS == 'ios' ? 0.1 :  0.8,
    shadowRadius : 10,
    position : 'absolute',
    bottom : 0,
    flexDirection : 'row',
    backgroundColor : 'white',
  }, 
  tab_item : {
    flexDirection : 'column',
    marginTop : 10 * metrics
  },
  tab_body : {
    flex : 1,
    width : '20%',
    height : '100%',
    flexDirection : 'column',
    alignItems : 'center',
    borderBottomColor : 'white',
    borderBottomWidth : 3
  },
  active_tabbody : {
    flex : 1,
    width : '20%',
    height : '100%',
    flexDirection : 'column',
    alignItems : 'center',
    borderBottomColor : '#4f80ff',
    borderBottomWidth : 3
  },
  img : { 
      width : 25 * metrics, height : 25 * metrics, resizeMode : 'stretch',
      alignItems: 'center',
      justifyContent : 'center',
      alignSelf : 'center'
  },
  active_title : {
    color : '#4f80ff',
    fontSize : 12 * metrics
  },
  title : {
    color : '#848484',
    fontSize : 12 * metrics
  },
  wrapper_label_selected : {
    alignSelf: 'center',
    color : 'black',
    //height : '60%',
    fontWeight : '500',
    fontSize : 17 * metrics
  },
  wrapper_label: {
    alignSelf: 'center',
    //height : '60%',
    color : 'gray',
    fontSize : 17 * metrics,
  },
  wrapper_view : {
    flexDirection : 'column',
    flex : 10,
  },
  location : {
    width : '100%', height : '100%',
  },
  badge : {
    position : 'absolute', 
    backgroundColor : 'red', 
    width : 15 * metrics, 
    height : 15 * metrics,
    textAlign : 'center', 
    right:2,
    top : 8  * metrics,
    borderRadius : 10 ,
    color :'white',
    fontSize : 10
  },
});
let _this = null;

@inject("userService")
@inject("notificationService")
@observer

class Tabs extends Component {
  
  _userService : UserService = this.props.userService;
  _notificationService : NotificationService = this.props.notificationService

  constructor(props) {
    
    super(props);
    this.state = {
      title: "HOME",
      home_img : selected_homeImg,
      explore_img : exploreImg,
      message_img : inboxImg,
      friend_img : friendImg,
      setting_img : settingImg,
      selection_value : 1,
      isSelected : 1,
      noti_arr : [],
      isUpdating : false,
      isLogin : false,
      init_data : [],
      noti_flag : false
    };
    this.screenRef = React.createRef()
  }
  static navigationOptions = ({ navigation }) => { 
    const { params = {} } = navigation.state;
    
    if (params.tabTitle == 'HOME') {
      return {
        header: ( /* Home header */
          <View style={global_style.header}>
            <View style={global_style.navBar}>
              <Text style = {global_style.header_title}>{params.tabTitle}</Text>
              <View style={global_style.right_icon}>
                <TouchableOpacity onPress={navigation.getParam('notification')} style={global_style.badge_body}>
                  <Image source = {require('../../assets/img/icon/ico_noti.png')} style={styles.noti_icon}/> 
                  {
                    params.badge_number == 0 ? null : <Text style={styles.badge}>{params.badge_number}</Text>
                  }
                </TouchableOpacity>
                <TouchableOpacity onPress={navigation.getParam('profile')}>
                  {
                    params.avatar_img == '' ? ''
                    :
                    <Avatar
                      rounded
                      overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                      size="xlarge"
                      source={{uri : params.avatar_img}}
                      resizeMode={'stretch'}
                      containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                      style={styles.profile}
                      />
                  }
                </TouchableOpacity>
              </View>
            </View>
            <View style={global_style.search}>
              <TextInput style={styles.search}
                underlineColorAndroid = "transparent"
                placeholder = {params.tabTitle == 'FRIENDS' ? 'Find Your Friends' : 'Find Your Location'}
                placeholderTextColor = "gray"
                autoCapitalize = "none"
                onChangeText = {(text) => _this.onChangeText(text)}
              />
              <TouchableOpacity style={global_style.search_icon} onPress={() => _this.onSearchPlan()}>
                  <Image source = {require('../../assets/img/icon/ico_search.png')} style = {styles.location}/>   
              </TouchableOpacity>
            </View>
          </View>
        ),
      };
    } else if (params.tabTitle == 'EXPLORE') {
      return {
        header: ( /* Explore header */
          <View style={global_style.explore_header}>
            <View style={global_style.navBar}>
              <Text style = {global_style.header_title}>{params.tabTitle}</Text>
              <View style={global_style.right_icon}>
                <TouchableOpacity onPress={navigation.getParam('notification')} style={global_style.badge_body}>
                  <Image source = {require('../../assets/img/icon/ico_noti.png')} style={styles.noti_icon}/> 
                  {
                    params.badge_number == 0 ? null : <Text style={styles.badge}>{params.badge_number}</Text>
                  }
                </TouchableOpacity>
                <TouchableOpacity onPress={navigation.getParam('profile')}>
                {
                    params.avatar_img == '' ? ''
                    :
                    <Avatar
                      rounded
                      overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                      size="xlarge"
                      source={{uri : params.avatar_img}}
                      resizeMode={'stretch'}
                      containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                      style={styles.profile}
                      />
                  }
                </TouchableOpacity>
              </View>
            </View>
            <View style={global_style.search}>
              <TextInput style={styles.search}
                underlineColorAndroid = "transparent"
                placeholder = {params.tabTitle == 'FRIENDS' ? 'Find Your Friends' : 'Find Your Location'}
                placeholderTextColor = "gray"
                autoCapitalize = "none"
                onChangeText = {(text) => _this.onChangeText(text)}
              />
              <TouchableOpacity style={global_style.search_icon} onPress={() => _this.onSearchExplore()}>
                  <Image source = {require('../../assets/img/icon/ico_search.png')} style = {styles.location}/> 
              </TouchableOpacity>
            </View>
            <View style={global_style.tabbar}>
              <TouchableOpacity onPress={navigation.getParam('post')} style={params.isSelected == 1 ? global_style.active_tab : global_style.non_active_tab}>
                <View style={styles.wrapper_view}>
                    <View style={{flex : 2}}></View>
                    <View><Text style={params.isSelected == 1 ? styles.wrapper_label_selected : styles.wrapper_label }>POSTS</Text></View>
                    <View style={{flex : 1}}></View>
                </View>
              </TouchableOpacity>
              
              <TouchableOpacity onPress={navigation.getParam('group')} style={params.isSelected == 2 ? global_style.active_tab : global_style.non_active_tab}>
                <View style={styles.wrapper_view}>
                  <View style={{flex : 2}}></View>
                  <View>
                    <Text style={params.isSelected == 2 ? styles.wrapper_label_selected : styles.wrapper_label }>GROUPS</Text>
                  </View>
                  <View style={{flex : 1}}></View>
                </View>
                
              </TouchableOpacity>
            </View>
          </View>
        ),
      };
    } else if (params.tabTitle == 'MESSAGES') {
      return {
        header: ( /* Message Header */
          <View style={global_style.other_header}>
            <View style={global_style.navBar}>
              <Text style = {[global_style.header_title]}>{params.tabTitle}</Text>
              <View style={global_style.right_icon}>
                <View style = {global_style.message_right}>
                  <TouchableOpacity onPress={() => _this.newChat()}>
                    <Text style={{color:'#2978fb' , fontSize: 14 * metrics, marginTop : 10}}>NEW GROUP CHAT</Text>
                  </TouchableOpacity>
                </View>                  
              </View>
            </View>
          </View>
        ),
      };
    } else if (params.tabTitle == 'FRIENDS') {
      return {
        header: ( /* Friends Header */
          <View style={global_style.header}>
            <View style={global_style.navBar}>
              <Text style = {global_style.header_title}>{params.tabTitle}</Text>
              <View style={global_style.right_icon}>
                <TouchableOpacity onPress={navigation.getParam('notification')} style={global_style.badge_body}>
                  <Image source = {require('../../assets/img/icon/ico_noti.png')} style={styles.noti_icon}/> 
                  {
                    params.badge_number == 0 ? null : <Text style={styles.badge}>{params.badge_number}</Text>
                  }
                </TouchableOpacity>
                <TouchableOpacity onPress={navigation.getParam('profile')}>
                {
                    params.avatar_img == '' ? ''
                    :
                    <Avatar
                      rounded
                      overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                      size="xlarge"
                      source={{uri : params.avatar_img}}
                      resizeMode={'stretch'}
                      containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                      style={styles.profile}
                      />
                  }
                </TouchableOpacity>
              </View>
            </View>
            <View style={global_style.search}>
                <TextInput style={styles.search}
                  underlineColorAndroid = "transparent"
                  placeholder = {params.tabTitle == 'FRIENDS' ? 'Find Your Friends' : 'Find Your Location'}
                  placeholderTextColor = "gray"
                  autoCapitalize = "none"
                  onChangeText = {(text) => _this.onSearchFriend(text)}
                />
                <View style={global_style.search_icon}>
                  <TouchableOpacity onPress={navigation.getParam('searchFriend')} style={{width: '100%', height: '100%'}}>
                    <Image source = {require('../../assets/img/icon/ico_search.png')} style = {styles.location}/> 
                  </TouchableOpacity>
                </View>
              </View>
          </View>
        ),
      };
    } else if (params.tabTitle == 'SETTINGS') {
      return {
        header: ( /* Setting header */
          <View style={global_style.other_header}>
            <View style={global_style.navBar}>
              <Text style = {global_style.header_title}>{params.tabTitle}</Text>
            </View>
          </View>
        ),
      };
    }
  };
  //search text 
  search_text = ''
  onChangeText = (text) => {
    this.search_text = text
  }
  onSearchPlan = () => {
    this.screenRef.current.onChangeState(this.search_text, 'home')
  }
  onSearchExplore = ()=> {
    this.screenRef.current.onChangeState(this.search_text, 'explore')
  }
  onSearchFriend = (text) => {
    this.screenRef.current.onChangeState(text, 'friend')
  }
  //
  async componentWillMount () {
    

    _this = this;
    setNotiData([])
    this.setState({isSelected : 1});
    await this.getNotificationFlag()
    if (global.user_info != null && global.user_info.google == true) {
      this.init()
    }
    this._userService.getCurrentAuthInfo().then((result) => {
      if (result == null) {
        if (global.user_info.google == true) {
          this.init()
        } else {
          this.setState({isLogin : false})
          return;
        }
      }
      else {
        this.init()
      }
    })
  }

  init () {
    this.setState({isLogin : true})
    this.props.navigation.setParams({
      tabTitle: 'HOME',
      isSelected : 1,
      avatar_img : global.user_info.img_url,
    });

    this.calculateBadge()
    this.getAllNotificationData();
    
    this.props.navigation.setParams({ notification: this.onClickNotification });
    this.props.navigation.setParams({ profile: this.onClickedMyProfile });
    this.props.navigation.setParams({ post: this.onPostClicked });
    this.props.navigation.setParams({ group: this.onGroupClicked });
    this.props.navigation.setParams({ searchFriend : this.onSearchFriendClicked})
  }

  showPushNotification() {
    if (this.state.noti_arr.length == 0 || this.state.isLogin == false) {
      return;
    }
    for(var i =0; i< this.state.noti_arr.length ;i ++) {
      var title = this.state.noti_arr[i].content.toUpperCase();
      var user_name = this.state.noti_arr[i].send_uid.f_name + ' ' + this.state.noti_arr[i].send_uid.l_name
      var message = ''
      switch (this.state.noti_arr[i].type) {
        case 0: // invite group
          message = user_name + " invited you to group.";
          break;
        case 1: //invite post 
          message = user_name + " invited in new post.";
          break;
        case 2: //friend
          message = user_name + " invited you to be a friend.";
          break;
        case 3: //plan
          message =user_name + " invited you in new plan.";
          break;
        case 4: //join group
          message = user_name + " joined your group.";
          break;
      }
      if (Platform.OS == 'ios') {
        PushNotification.localNotificationSchedule({
          //... You can use all the options from localNotifications
          title: title,
          message: message,
          date: new Date(Date.now() + 1 * 1000) // in 60 secs
        });
      } else {
        PushNotification.localNotification({
          id: i,
          bigText: message,
          color: "black",
          ongoing: false,
          priority: "high",
          visibility: "private",
          importance: "high",
          title: title,
          message: message,
        });
      }
    }
    var counts = 0;
    
    this.state.noti_arr.forEach(element => {
      element.send_uid = element.send_uid.uid
      element.isNotification = 1
      this._notificationService.updateNotification(element.id, element).then((result) => {
        
      }).catch((error) =>{
        console.log(error)
      })
    });
  }
  calculateNotiData = (result) => {
    this.setState({noti_arr : []})
    const init_data = result.docs.map(doc => doc.data())
    var local_data = getNotiData();
    if (local_data.length == 0 ) { //init
      if (init_data.length > 0) { //not localstore
        var count = 0;
        init_data.forEach(element => {
          this._userService.getUserData(element.send_uid).then((result) => {
            if (result.exists) {
              element.send_uid = result.data()
            }
            count ++;
            if (count == init_data.length) {
              this.setState({noti_arr : sortDataByTime(init_data)})
              setNotiData(init_data)
              this.showPushNotification()
            }
          })
        });
      } else {
        //setNotiData([]);
      }       
    } else {
        var temp_arr = [];
        for (var i = 0 ; i < init_data.length ; i ++ ){
          var count = 0;
          for (var j = 0 ; j < local_data.length ; j ++) {
            if (init_data[i].id == local_data[j].id) {
              count ++;
              break;
            }
          }
          if (count == 0) {
            temp_arr.push(init_data[i])
          }
        }
        temp_arr = init_data;
        //console.log('temp = ' , temp_arr)
        if (temp_arr.length > 0) { 
          var count = 0;
          temp_arr.forEach(element => {
            this._userService.getUserData(element.send_uid).then((result) => {
              if (result.exists) {
                element.send_uid = result.data()
              }
              count ++;
              if (count == temp_arr.length) {
                this.setState({noti_arr : sortDataByTime(temp_arr)})
                this.showPushNotification()
              }
            })
          });        
        } else {
          this.setState({noti_arr : []})
          //setNotiData([]);
        }
    }
  }
  skipNotiData = (result) => {
    var init_data = result.docs.map(doc => doc.data())
    if (init_data.length > 0 ) { //init 
      init_data.forEach(element => {
        element.isNotification = 1
        this._notificationService.updateNotification(element.id, element).then((result) => {
          
        }).catch((error) =>{
          console.log(error)
        })
      });
    }
  }
  getNotificationFlag = async () => {
      try {
        const value = await AsyncStorage.getItem('notification_flag');
        if (value !== null) {
            if (value == 'true')
                this.setState({noti_flag : true})
            else
                this.setState({noti_flag : false})
        } else { //init notification
          this.setState({noti_flag : true})
          await AsyncStorage.setItem('notification_flage', 'true')
        }
      } catch (error) {

      }
  }

  componentWillUnmount() {
    this.unsubscribeNoti()
    this.unsubscribeData()
  }

  getAllNotificationData = () => {
    var _this = this
    this.unsubscribeNoti = this._notificationService.getAllPushNotificationData(global.user_info.uid).onSnapshot(function(result){
      _this._userService.getCurrentAuthInfo().then((log_info) => {
        if (log_info == null) {
          return;
        } else {
          _this.getNotificationFlag()
          if (_this.state.noti_flag) {
            _this.calculateNotiData(result)
          } else {
            _this.skipNotiData(result)
          }
          
        }
      })
    })
  }
  calculateBadge = () => {
    this.unsubscribeData = this._notificationService.getAllData(global.user_info.uid).onSnapshot(function(result){
      const data = result.docs.map(doc => doc.data());
      var noti_count = 0;
      if (global.user_info != null && global.user_info.google) {
        _this.setState({isLogin : true})
      }
      if (!_this.state.isLogin || global.user_info == null) {
        return;
      } else {
        for (var i =0 ; i< data.length ;i++) {
          if (data[i].is_read == 0 && (data[i].send_uid != data[i].recv_uid) && (data[i].recv_uid == global.user_info.uid)) {
            noti_count ++;
          }
        }
        _this.props.navigation.setParams({
          badge_number : noti_count
        })
      }
    })
  } 

  onPostClicked = () => {
    this.setState({isSelected : 1})
    this.props.navigation.setParams({isSelected : 1});
  }
  onGroupClicked = () => {
    this.setState({isSelected : 2})
    this.props.navigation.setParams({isSelected : 2});
  }
  onClickedTabbar = (val) => {
    if (val == 1) {
      this.setState({home_img : selected_homeImg})
      this.setState({explore_img : exploreImg})
      this.setState({message_img : inboxImg})
      this.setState({friend_img : friendImg})
      this.setState({setting_img : settingImg})
      this.setState({title : 'HOME'})
      this.props.navigation.setParams({tabTitle : 'HOME'});
    } else if (val == 2) {
      this.setState({home_img : homeImg})
      this.setState({explore_img : selected_exploreImg})
      this.setState({message_img : inboxImg})
      this.setState({friend_img : friendImg})
      this.setState({setting_img : settingImg})
      this.setState({title : 'EXPLORE'})
      this.props.navigation.setParams({tabTitle : 'EXPLORE'});
    } else if (val == 3) {
      this.setState({home_img : homeImg})
      this.setState({explore_img : exploreImg})
      this.setState({message_img : selected_inboxImg})
      this.setState({friend_img : friendImg})
      this.setState({setting_img : settingImg})
      this.setState({title : 'MESSAGES'})
      this.props.navigation.setParams({tabTitle : 'MESSAGES'});
    } else if (val == 4) {
      this.setState({home_img : homeImg})
      this.setState({explore_img : exploreImg})
      this.setState({message_img : inboxImg})
      this.setState({friend_img : selected_friendImg})
      this.setState({setting_img : settingImg})
      this.setState({title : 'FRIENDS'})
      this.props.navigation.setParams({tabTitle : 'FRIENDS'});
    } else if (val == 5) {
      this.setState({home_img : homeImg})
      this.setState({explore_img : exploreImg})
      this.setState({message_img : inboxImg})
      this.setState({friend_img : friendImg})
      this.setState({setting_img : selected_settingImg})
      this.setState({title : 'SETTINGS'})
      this.props.navigation.setParams({tabTitle : 'SETTINGS'});
    }
    this.setState({selection_value : val})
  }

  newChat = () =>{
    this.props.navigation.navigate('AddGroupChatScreen');
  }
  onClickNotification = ()  =>{
    this.props.navigation.navigate('NotificationScreen');
  }
  onClickedMyProfile  = () => {
    this.props.navigation.navigate('MyInfoScreen');
  }
  onSearchFriendClicked = () => {
    this.props.navigation.navigate('SearchFriendScreen');
  }
  render() {
      return (
        <View style={{width : '100%', height : '100%', backgroundColor : '#f1f6f9'}}>
          <Screen name = {this.state.title} isSelected = {this.state.isSelected} navigation={this.props.navigation} ref={this.screenRef}/>
          <View style={styles.bottom}>
            <TouchableOpacity onPress={() => this.onClickedTabbar(1)} style={this.state.selection_value == 1 ? styles.active_tabbody : styles.tab_body}>
              <View style = {styles.tab_item}>
                <Image source = {this.state.home_img} style ={styles.img}/> 
                <Text style={this.state.selection_value == 1 ? styles.active_title : styles.title}>HOME</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => this.onClickedTabbar(2)} style={this.state.selection_value == 2 ? styles.active_tabbody : styles.tab_body}>
              <View style = {styles.tab_item}>
                <Image source = {this.state.explore_img} style ={styles.img}/> 
                <Text style={this.state.selection_value == 2 ? styles.active_title : styles.title}>EXPLORE</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => this.onClickedTabbar(3)} style={this.state.selection_value == 3 ? styles.active_tabbody : styles.tab_body}>
              <View style = {styles.tab_item}>
                <Image source = {this.state.message_img} style ={styles.img}/> 
                <Text style={this.state.selection_value == 3 ? styles.active_title : styles.title}>MESSAGES</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => this.onClickedTabbar(4)} style={this.state.selection_value == 4 ? styles.active_tabbody : styles.tab_body}>
              <View style = {styles.tab_item}>
                <Image source = {this.state.friend_img} style ={styles.img}/> 
                <Text style={this.state.selection_value == 4 ? styles.active_title : styles.title}>FRINEDS</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => this.onClickedTabbar(5)} style={this.state.selection_value == 5 ? styles.active_tabbody : styles.tab_body}>
              <View style = {styles.tab_item}>
                <Image source = {this.state.setting_img} style ={styles.img}/> 
                <Text style={this.state.selection_value == 5 ? styles.active_title : styles.title}>SETTINGS</Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      )
  }
}

export default Tabs
