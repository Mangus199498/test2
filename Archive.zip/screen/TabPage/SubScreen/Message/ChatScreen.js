import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,TextInput,ScrollView,Dimensions} from 'react-native';
import global_style , { metrics } from  '../../../../constants/globalStyles';
import {  Avatar} from 'react-native-elements';
import { getAllTime } from '../../../../utils/moment';

import MessageService from '../../../../services/message.service';
import UserService from '../../../../services/user.service';
import { inject, observer } from 'mobx-react';

import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

@inject ('messageService')
@inject ('userService')
@observer

class ChatScreen extends Component {
    _userService: UserService = this.props.userService
    _messageService : MessageService = this.props.messageService

    constructor(props){
        super(props);
        this.scroll = null;
        this.state = {
            message_content : [],
            message_txt : '',
            chat_info : {},
            info_btn : -1,
            user_info : [],
            type : 0
        }
    }
    
   
    componentDidMount () {
        var chat_id = this.props.navigation.getParam('chat_info').chat_id
        var type = this.props.navigation.getParam('chat_info').idx;
        var userInfo = this.props.navigation.getParam('chat_info').user_info

        this.setState({user_info : this.props.navigation.getParam('chat_info').user_info})
        this.setState({type : type})
        this.props.navigation.setParams({ info_btn: type});
        
        this.props.navigation.setParams({ detail: this.onClickedGroupDetail })
        

            
        if (type == 0) {
            for(var i = 0; i < userInfo.length ; i++) {
                if (global.user_info.uid != userInfo[i].uid) {
                    this.props.navigation.setParams({navTitle : userInfo[i].f_name + " " + userInfo[i].l_name})
                    this.props.navigation.setParams({ avatar : userInfo[i].img_url })
                    break;
                }
            }
            this.getChatContent(chat_id)
        } else {
            
            this.getGroupContent(chat_id)
        }
    }

    componentWillUnmount() {
        this.unsubscribeChat()
        this.unsubscribeMessageById()
    }

    getGroupContent (id) {
        var _this = this;
        this.unsubscribeChat = this._messageService.getGroupMessageDataById(id).onSnapshot(function(result) {
            if (result.exists) {
                const data = result.data()
                _this.setState({chat_info : data})
                _this.props.navigation.setParams({navTitle : data.group_info.title})
                _this.setState({message_content : data.message_content})
            }
        })
    }
    getChatContent(id) {
        var _this = this;
        this.unsubscribeMessageById = this._messageService.getMessageInfoById(id).onSnapshot(function(result) {
            if (result.exists) {
                const data = result.data()
                _this.setState({chat_info : data})
                _this.setState({message_content : data.message_content})
            }
        })
    }
    sendMessage = () => {
        
        if (this.state.message_txt == '') 
            return;
        if (this.state.type == '0') {
            var message_obj = {
                uid : global.user_info.uid,
                date : new Date(),
                message : this.state.message_txt
            }
            
            this.state.chat_info.message_content.push(message_obj)
            
            this._messageService.updateMessage(this.state.chat_info.id , this.state.chat_info).then((result) => {

            })    
        } else {
            var message_obj = {
                uid : global.user_info.uid,
                date : new Date(),
                message : this.state.message_txt
            }
            this.state.chat_info.message_content.push(message_obj)
            this._messageService.updateGroupMessage(this.state.chat_info.id , this.state.chat_info).then((result) => {

            })
        }
        
        this.setState({message_txt : ''})
    }
    onClickedGroupDetail = () => {
        this.props.navigation.navigate('GroupChatInfoScreen');
    } 
    onClickedPost = (id) => {
        this.props.navigation.navigate('PostDetailScreen', {post_id : id});
    }

    static navigationOptions = ({ navigation }) => {
        const { params = {} } = navigation.state;
        return {
            headerLeft: (
                <View style={global_style.navigation}>
                    <TouchableOpacity 
                        style={styles.backarrow}
                        onPress={() => navigation.goBack()} >
                            <Image source = {require('../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                            
                            {
                                params.avatar == undefined ? null :
                                <Avatar
                                    size="xlarge"
                                    rounded
                                    source={{uri : params.avatar}}
                                    resizeMode={'stretch'}
                                    style={styles.avatar_icon}
                                />
                            }
                            <Text style={[global_style.back_title]}>{params.navTitle}</Text>
                    </TouchableOpacity>
                    </View>
            ),
            headerStyle: global_style.headerHeight,
        };
    };
    
    render() {
        return (
            <View style={[global_style.chat_body, {backgroundColor : '#f1f6f9'}]}>
                <KeyboardAwareScrollView
                    resetScrollToCoords={{ x: 0, y: 0 }}
                    contentContainerStyle={{flex : 1}}
                    scrollEnabled={false}
                >

                
                <ScrollView style ={{marginBottom : 55 * metrics}}>
                    {
                        this.state.message_content.map((item,index) => {
                            if (item.post_id) {
                                if (item.uid == global.user_info.uid) {
                                    return (
                                        <View style={global_style.owner} key={index}>
                                            <Text style={styles.me_time}>{getAllTime(item.date)}</Text>
                                            <View style={global_style.my_txt}>
                                                {
                                                    this.state.type == 1 ?<Text style={{fontSize : 16 * metrics, fontWeight : '700' , color : 'white'}}>Me</Text> : null
                                                }
                                                <TouchableOpacity onPress={()=> this.onClickedPost(item.post_id)}>
                                                    <Image source={{uri : item.img}} style={{width : '100%', height : 130  * metrics ,borderRadius : 7  * metrics , marginTop : 3  * metrics }}/>
                                                </TouchableOpacity>
                                                <Text style={{color : 'white', marginTop : 5 * metrics}}>{item.message}</Text>
                                            </View>
                                             <View style={styles.my_triangle}></View> 
                                        </View>
                                    )
                                } else {
                                    return (
                                        <View style={global_style.other} key={index}>
                                            <Text style={styles.other_time}>{getAllTime(item.date)}</Text>
                                            <View  style={global_style.other_txt}>
                                                {
                                                    this.state.type == 1 ? 
                                                        this.state.user_info.map((user,index) => {
                                                            if (item.uid == user.uid) {
                                                                return( <Text style={{marginLeft :-5  * metrics , fontSize : 16  * metrics , fontWeight : '700'}} key={index}> {user.f_name + ' ' + user.l_name}</Text>)
                                                            }
                                                        })
                                                    : null
                                                }
                                                <TouchableOpacity onPress={()=> this.onClickedPost(item.post_id)}>
                                                    <Image source={{uri : item.img}} style={{width : '100%', height : 130  * metrics ,borderRadius : 10  * metrics }}/>
                                                </TouchableOpacity>
                                                <Text style={{color : 'gray'}}>{item.message}</Text>
                                                
                                            </View>
                                           <View style={styles.other_rectangle}>
                                                <Image  source={require('../../../../assets/img/icon/bubble_icon.png')} style={{width : 17  * metrics , height : 15 * metrics}}/>
                                            </View>   
                                        </View>
                                        
                                    )
                                }
                            } else {
                                if (item.uid == global.user_info.uid) {
                                    return (
                                        <View style={global_style.owner} key={index}>
                                            <Text style={styles.me_time}>{getAllTime(item.date)}</Text>
                                            <View style={global_style.my_txt}>
                                                {
                                                    this.state.type == 1 ?<Text style={{fontSize : 16, fontWeight : '700' , color : 'white'}}>Me</Text> : null
                                                }
                                                <Text style={{color : 'white'}}>{item.message}</Text>
                                            </View>
                                            <View style={styles.my_triangle}></View>  
                                        </View>
                                    )
                                } else {
                                    return (
                                        <View style={global_style.other} key={index}>
                                            <Text style={styles.other_time}>{getAllTime(item.date)}</Text>
                                            <View  style={global_style.other_txt}>
                                                {
                                                    this.state.type == 1 ? 
                                                        this.state.user_info.map((user,index) => {
                                                            if (item.uid == user.uid) {
                                                                return( <Text style={{marginLeft :-5, fontSize : 16,fontWeight : '700'}} key={index}> {user.f_name + ' ' + user.l_name}</Text>)
                                                            }
                                                        })
                                                    : null
                                                }
                                                <Text style={{color : 'gray'}}>{item.message}</Text>
                                            </View>
                                            <View style={styles.other_rectangle}>
                                                <Image  source={require('../../../../assets/img/icon/bubble_icon.png')} style={{width : 17  * metrics ,height : 15  * metrics}}/>
                                            </View>    
                                        </View>
                                    )
                                }
                            }
                        })  
                    }
                </ScrollView>
                
                <View style={global_style.bottom_fixed}>
                    <TextInput 
                        underlineColorAndroid = "transparent"
                        placeholder = "Write Message"
                        placeholderTextColor = "gray"
                        autoCapitalize = "none"
                        value = {this.state.message_txt}
                        style={global_style.comment_style}
                        onChangeText={(text) => this.setState({message_txt : text})}/>
                    <TouchableOpacity style={{alignSelf : 'center' , flex : 15}} onPress={()=> this.sendMessage()}>
                        <Image source={require('../../../../assets/img/icon/icon_write.png')} style={{width: 37 * metrics, height: 37 * metrics,alignSelf : 'center', marginLeft : 5 * metrics}}></Image>
                    </TouchableOpacity>
                </View>
                </KeyboardAwareScrollView>
            </View>
        )
   }
}
const styles = StyleSheet.create({
    backarrow : {
        flex: 1,
        height: '100%',
        flexDirection : 'row',
        width: '100%'
    },
    me_time : {
        marginRight : 25,
        flexDirection : 'column',
        textAlign : 'right',
        color :'#bdbdbd',
        fontSize : 12
    },
    other_time :{ 
        marginLeft : 25,
        flexDirection : 'column',
        textAlign : 'left',
        color :'#bdbdbd',
        fontSize : 12
    },
    lock_icon : {
        width: 25,
        height: 25,
        marginRight : 10,
        marginTop: 30,
    },
    avatar_icon: {
        width : 37,
        height: 37,
        marginRight : -5,
        marginLeft : 10,
        marginTop : 18
    },
    my_triangle : {
        height : 0, 
        width :  0, 
        position : 'absolute' , 
        bottom : 20,
        right : 7 * metrics,
        borderRightWidth : 15,
        borderRightColor : 'transparent',
        borderBottomWidth : 15,
        borderBottomColor : '#4f80ff',
        zIndex : 999,
        
    },
    other_rectangle : {
        position : 'absolute' , 
        top : 35,
        left : 5,
        elevation : 5,
        zIndex : 999,
    }
})
export default ChatScreen