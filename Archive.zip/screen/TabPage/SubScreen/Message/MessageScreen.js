import React, { Component } from 'react';
import { View , Text, Image,StyleSheet, TouchableOpacity,Dimensions ,ScrollView,Alert} from 'react-native';
import global_stype , {metrics} from  '../../../../constants/globalStyles';
import MessageService from '../../../../services/message.service';
import UserService from '../../../../services/user.service';

import { inject, observer } from 'mobx-react';
import { Avatar, Icon} from 'react-native-elements';

import { replaceTitle,replacetext ,replaceGroupTitle} from '../../../../utils/utils';
import { getHoursAndMins } from '../../../../utils/moment';
import Swipeout from 'react-native-swipeout';

import MaterialIcon from 'react-native-vector-icons/MaterialCommunityIcons'

@inject ('messageService')
@inject ('userService')
@observer

class MessageScreen extends Component {

    _messageService : MessageService = this.props.messageService
    _userService : UserService = this.props.userService

    state = {
        message_arr : [],
        group_message_arr : [],
        my_id : "",
        isSwipe : false,
    }
    componentDidMount() {
        this.setState({my_id : global.user_info.uid})
        this.getMessageDataByMyId()
    }
    sortMessageData = (data)=> {
        var temp = []
        for (var i = 0; i < data.length ;i++) {
            var isExist = false
            var userInfo = data[i]
            for (var j = 0 ; j < userInfo.user_data.length ;j++) {
                if (userInfo.user_data[j].uid == this.state.my_id && userInfo.status_data[j]) {
                    isExist = true
                    break;
                }
            }
            if (isExist) { //if my_id is exsit
                temp.push(userInfo)
            }
        }
        this.setState({message_arr : temp})
    }

    componentWillUnmount() {
        this.unsubscribeMessage()
        this.unsubscribGroupMessage()
    }

    async getMessageDataByMyId() {
        
        var _this = this;
        this.unsubscribeMessage = await this._messageService.getMessageData(global.user_info.uid).onSnapshot(function(result) {
            var count = 0;
            const data = result.docs.map(doc => doc.data()); //data is message array
            if (data.length > 0) {
                data.forEach(item => {
                    item.user_data.forEach((user_item, idx) => {
                        _this._userService.getUserData(user_item).then((result) => {
                            if (result.exists) {
                                item.user_data[idx] = result.data()
                            }                      
                            count ++ ;
                            if (count == data.length * 2) {
                                _this.setState({message_arr : data})
                            }
                        }).catch(error => {
                            console.log(error)
                        })
                    })
                });
            } else {
                _this.setState({message_arr : []})
                console.log('error')
            }
        })

        this.unsubscribGroupMessage = await this._messageService.getGroupMessageData(global.user_info.uid).onSnapshot(function(result) {
            var count = 0;
            
            const data = result.docs.map(doc => doc.data()); //data is message array
            if (data.length > 0) {
                data.forEach(item => {
                    item.user_data.forEach((user_item, idx) => {
                        _this._userService.getUserData(user_item).then((result) => {
                            if (result.exists) {
                                item.user_data[idx] = result.data()
                            }              
                            count ++ ;
                            if (count == data.length) {
                                setTimeout(() => {
                                    _this.setState({group_message_arr : data})  
                                }, 1000);
                            }
                        }).catch(error => {
                            console.log(error)
                        })
                    })
                });
            } else {
                _this.setState({group_message_arr : []})
                console.log('error')
            }
        })

    }
    onClickedChat = (value,idx) => {
        var obj = {
            idx : idx,
            chat_id : value.id,
            user_info : value.user_data
        }
        console.log(obj)
        this.props.navigation.navigate('ChatScreen', {chat_info : obj})
    }
    //remove chat
    deleteMessage = (idx) => {
        Alert.alert(  
            '',  
            'Do you really remove it? It will be not show after now',  
            [  
                {text: 'OK', onPress: () => this.removeChat(this.state.message_arr[idx].id)},  
                {text: 'CANCEL', onPress: ()=> console.log('Cancel')}
            ],  
            {cancelable: false}  
        ) 
    }
    deleteGroupMessage = (idx) => {
        Alert.alert(  
            '',  
            'Do you really remove it? It will be not show after now',  
            [  
                {text: 'OK', onPress: () => this.removeGroupMessage(this.state.group_message_arr[idx])},  
                {text: 'CANCEL', onPress: ()=> console.log('Cancel')}
            ],  
            {cancelable: false}  
        )
    }
    removeGroupMessage (data) {
        var user_arr = data.user_data
        var result_arr = []
        for (var i =0 ; i < user_arr.length ;i++) {
            if (user_arr[i].uid != this.state.my_id) {
                result_arr.push(user_arr[i].uid)
            }
        }
        data.user_data = result_arr
        this._messageService.updateGroupMessage(data.id , data).then(result => {
            this.componentDidMount()
        })
    }
    removeChat = (id) => {
        this._messageService.removeMessage(id).then(result => {
            this.componentDidMount()
        })
    }
    //
    render() {
        const rightButtons = [
            <TouchableOpacity style={{flexDirection : 'row', height: '100%', backgroundColor : 'red'}} onPress={(e) => this.deleteMessage(e)}>
                <View style={{flex : 2}}>
                    <View style={{flex : 10, flexDirection : 'column'}}>
                        <View style={{flex : 3}}></View>
                        <Image source = {require('../../../../assets/img/icon/trash.png')} style={styles.trash}></Image> 
                        <View style={{flex : 3}}></View>
                    </View>
                </View>
                <View style={{flex : 8}}></View>
            </TouchableOpacity>,
        ];
        return (
            <ScrollView style={styles.container} ref="myDiv" bounces = {false}>
                {

                    this.state.message_arr.map((item, index) => {
                        return (
                            <Swipeout 
                                right={[
                                    {   
                                        component : 
                                        <TouchableOpacity style={{flexDirection : 'column' , backgroundColor : 'red' , height : '100%'}} onPress={() => this.deleteMessage(index)}>
                                            <View style={{flex : 3}}></View>
                                            <Image source ={require('../../../../assets/img/icon/trash.png')} style={styles.trash}></Image>
                                            <View style={{flex : 3}}></View>
                                        </TouchableOpacity>
                                    }
                                ]}>
                                <TouchableOpacity style={global_stype.message_body} onPress={ () => this.onClickedChat(item, 0)}>
                                    <View style={styles.view}>
                                        <Avatar
                                            rounded
                                            overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                                            size="xlarge"
                                            source={{uri : item.user_data[1].uid == this.state.my_id ? item.user_data[0].img_url : item.user_data[1].img_url}}
                                            resizeMode={'stretch'}
                                            containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                                            style = {styles.profile}
                                        />
                                        <View style= {styles.text}>
                                            <Text style={styles.title}>{item.user_data[0].uid == this.state.my_id ? item.user_data[1].f_name + " " +item.user_data[1].l_name :  item.user_data[0].f_name + " " +item.user_data[0].l_name}</Text> 
                                            <Text style={styles.message}>{item.message_content.length > 0 ? replaceTitle(item.message_content[item.message_content.length -1].message) : ""}</Text>
                                        </View>
                                        <View style={styles.time}>
                                            {
                                                item.message_content.length == 0 ? null :
                                                <Image source = {require('../../../../assets/img/icon/clock.png')} style={styles.time_icon}></Image> 
                                            }
                                            <Text style={styles.message}>{item.message_content.length > 0 ? getHoursAndMins(item.message_content[item.message_content.length -1].date) : ""}</Text>
                                        </View>
                                    </View>
                                </TouchableOpacity>
                            </Swipeout>
                        )
                    })
                }
                {
                    this.state.group_message_arr.map((item,index) => {
                        return (
                            <Swipeout 
                                right={[
                                    {   
                                        component : 
                                        <TouchableOpacity style={{flexDirection : 'column' , backgroundColor : 'red' , height : '100%'}} onPress={() => this.deleteGroupMessage(index)}>
                                            <View style={{flex : 3}}></View>
                                            <Image source ={require('../../../../assets/img/icon/trash.png')} style={styles.trash}></Image>
                                            <View style={{flex : 3}}></View>
                                        </TouchableOpacity>
                                    }
                                ]}>
                                <TouchableOpacity style={global_stype.message_body} onPress={ () => this.onClickedChat(item, 1)}>
                                    <View style={styles.view}>
                                        <View style={styles.user_arr}>
                                            {
                                                item.user_data.map((user_item, index) => {
                                                    return (
                                                        <Avatar
                                                            size="xlarge"
                                                            rounded
                                                            source={{uri : user_item.img_url}}
                                                            resizeMode={'stretch'}
                                                            style={styles.group_icon}
                                                            key={index}
                                                        />
                                                    )
                                                })
                                                
                                            }
                                        </View>
                                        <View style= {styles.group_text}>
                                            <Text style={styles.title}>{replaceGroupTitle(item.group_info.title)}</Text> 
                                            <Text style={styles.message}>Friend Group</Text>
                                        </View>
                                        <View style={styles.time}>
                                            {
                                                item.message_content.length == 0 ? null :
                                                <Image source = {require('../../../../assets/img/icon/clock.png')} style={styles.time_icon}></Image> 
                                            }
                                            <Text style={styles.message}>{item.message_content.length > 0 ? getHoursAndMins(item.message_content[item.message_content.length -1].date) : ""}</Text>
                                        </View>
                                    </View>
                                </TouchableOpacity>
                            </Swipeout>
                        )
                    })
                            
                }
            </ScrollView>
        )
    }
}
const styles = StyleSheet.create({
    container : {
        width: '100%',
        height : '100%',
        backgroundColor : 'white'
    },
    view: {
        flex: 1,
        flexDirection : 'row',
        height: '100%',
        alignItems : 'center'
    },  
    title : {
        margin : 5,
        marginTop : 0,
        fontSize: 18  * metrics,
        alignSelf : 'flex-start'
    },
    profile: {
        width : 50 * metrics,
        height: 50 * metrics,
        resizeMode : "stretch",
        marginLeft: 15 * metrics,
        marginRight: 15 * metrics,
    },
    right_img: {
        alignItems: 'center',
        marginRight : 10 * metrics,
        width: 100 * metrics,
        height: 22 * metrics,
        resizeMode: 'stretch',
    },
    text: {
        alignItems: 'flex-start',
        marginLeft: 0,
        flexDirection: 'column',
    },
    message : {
        fontSize : 12 * metrics,
        color : 'gray',
        marginLeft : 5
    },
    time : {
        position: 'absolute',
        right: 10 * metrics,
        top: 12 * metrics,
        flexDirection:'row',
    },
    trash : {
        width: 17 * metrics,
        height: 20 * metrics,
        resizeMode: 'stretch',
        alignItems: 'center',
        justifyContent : 'center',
        alignSelf : 'center'
    },
    time_icon : {
        width: 18 * metrics,
        height : 18 * metrics,
        marginRight : 3 * metrics,
        resizeMode: 'stretch',
    },
    user_arr: {
        alignItems: 'center',
        marginLeft: 15 * metrics,
        flexDirection : 'row',
    },
    group_icon: {
        width : 50 * metrics,
        height: 50 * metrics,
        marginRight : -15 * metrics
    },
    group_text : {
        alignItems: 'center',
        marginLeft: 20 * metrics,
        flexDirection: 'column',
    }
})
export default MessageScreen