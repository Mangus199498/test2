import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,TextInput, ScrollView} from 'react-native';
import global_style from '../../../../constants/globalStyles';

let _this = null;
class GroupChatInfoScreen extends Component {
   static navigationOptions = ({ navigation }) => {
      return {
          headerLeft: (
            <View style={global_style.navigation}>
                  <TouchableOpacity 
                      style={styles.backarrow}
                      onPress={() => navigation.goBack()} >
                          <Image source = {require('../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                          <Text style={global_style.back_title}>David Carter</Text>
                  </TouchableOpacity>
              </View>
          ),
          headerStyle: global_style.headerHeight
      };
   };
   state = {
      starCount : 4,
      height : 0,
   }
   componentWillMount () {
       _this =- this;
   }
   InviteFriends = () => {
        
   }
   render() {
        return (
            <View style ={{width : '100%', height: '100%'}}>
                <ScrollView horizontal = {false}>
                    <View style={styles.info_body}>
                        <Text style={{width : '90%', alignSelf : 'center', paddingTop : 5}}>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</Text>
                        <ScrollView horizontal ={true}>
                            <View style={styles.img_body}>
                                <View style ={styles.image}>
                                    <Image source = {require('../../../../assets/img/icon/img1.png')} style={styles.place_img}/>
                                </View> 
                                <View style ={styles.image}>
                                    <Image source = {require('../../../../assets/img/icon/img2.png')} style={styles.place_img}/>
                                </View> 
                                <View style ={styles.image}>
                                    <Image source = {require('../../../../assets/img/icon/img3.png')} style={styles.place_img}/>
                                </View> 
                                <View style ={styles.image}>
                                    <Image source = {require('../../../../assets/img/icon/img4.png')} style={styles.place_img}/>
                                </View> 
                            </View>
                        </ScrollView>
                        
                    </View>
                    <View>
                        <View style={global_style.friends_tile} onClick={ () => this.onClickedFriends(1)}>
                            <View style={styles.view}>
                                <Image source = {require('../../../../assets/img/icon/profile3.png')} style={styles.profile}></Image> 
                                <Text style={styles.title}>Mark D</Text> 
                                <Image source = {require('../../../../assets/img/icon/right_arrow.png')} style={global_style.right_arrow}/> 
                            </View>
                        </View>
                        <View style={global_style.friends_tile} onClick={ () => this.onClickedFriends(1)}>
                            <View style={styles.view}>
                                <Image source = {require('../../../../assets/img/icon/profile2.png')} style={styles.profile}></Image> 
                                <Text style={styles.title}>Sara D</Text> 
                                <Image source = {require('../../../../assets/img/icon/right_arrow.png')} style={global_style.right_arrow}/> 
                            </View>
                        </View>
                    </View>
                </ScrollView>
                <View style={[global_style.bottom , {flex : 10}]}>
                    <View style ={{flex :2}}></View>
                    <TouchableOpacity onPress={() => this.InviteFriends()} style={styles.cyan_btn}>
                        <Text style={styles.label}>Invite Fiends</Text>
                    </TouchableOpacity>
                    <View style ={{flex :2}}></View>
                </View>
            </View>
            
      )
   }
}
const styles = StyleSheet.create({
    backarrow : {
        flex: 1,
        height: '100%',
        flexDirection : 'row',
        width: '100%'
    },
    info_body : {
        flexDirection : 'column',
        width : '100%',
        paddingBottom : 10,
        shadowColor:'#e2e2e2',
        shadowOffset : {width: 0, height: 8}, 
        shadowRadius: 20, 
        shadowOpacity : 0.7
    },
    img_body : {
        height : 130,
        width: '100%',
        paddingTop : 10,
        flexDirection :'row',
        alignItems: 'center',
        marginLeft : 15,
        marginRight : 15
    },
    image :{ 
        borderRadius: 10,
        height: 110,
        marginTop: 10,
        marginRight: 5,
        marginBottom: 10,
        marginLeft: 5,
        width: 130,
    },
    place_img : {
        borderRadius: 10,
        width: '100%',
        height: 110,
        marginRight : 0, 
        resizeMode: "stretch",
        marginRight : 5
    },
    cyan_btn : {
        width: '55%',
        height: 45,
        borderRadius: 40,
        alignItems: 'center',
        alignSelf : 'center',
        backgroundColor: '#4f80ff',
        shadowColor: '#809adc',
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.4,
        shadowRadius: 7,  
        flex : 6,
        elevation : 3.5
    },
    label : {
        height: '100%',
        alignItems: 'center',
        fontSize: 18,
        color: 'white',
        marginTop: 10,
    },
    view: {
        flex: 1,
        flexDirection : 'row',
        height: '100%',
        width : '100%'
    },  
    title : {
        alignSelf : 'center',
        marginLeft: 20
    },
    profile: {
        width : 45,
        height: 45,
        resizeMode : "stretch",
        alignItems: 'center',
        alignSelf : 'center',
        marginLeft : 15
    },
    right_img: {
        alignItems: 'center',
        marginRight : 10,
        width: 100,
        height: 22,
        resizeMode: 'stretch',
    }
})
export default GroupChatInfoScreen