import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,TextInput,Picker,ScrollView,Alert, Dimensions, Platform} from 'react-native';
import global_style , { metrics } from '../../../../constants/globalStyles';
import { Input , Avatar} from 'react-native-elements';
import Textarea from 'react-native-textarea';
import UserService from '../../../../services/user.service';
import MessageService from '../../../../services/message.service';
import { inject ,observer } from 'mobx-react';
import RNPickerSelect from 'react-native-picker-select';
import LoadingBar from '../../../../components/LoadingBar';

import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

@inject ('userService')
@inject ('messageService')
@observer

class AddGroupChatScreen extends Component {

    _userService : UserService = this.props.userService
    _messageService : MessageService = this.props.messageService

    static navigationOptions = ({ navigation }) => {
        return {
            headerLeft: (
                    <View style={global_style.navigation}>
                        <TouchableOpacity 
                            style={styles.backarrow}
                            onPress={() => navigation.goBack()} >
                                <Image source = {require('../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                                <Text style={global_style.back_title}>NEW GROUP CHAT</Text>
                        </TouchableOpacity>
                    </View>
            ),
            headerStyle: global_style.headerHeight,
        };
    };
    state = {
        friends_arr : [],
        privacy : '0',
        title : '',
        description : '',
        btn_flag : false,
        isLoading : false
    }
    componentWillMount () {

    }
    createGroup = () => {
        this.setState({btn_flag : true})
        if (this.state.title == '') 
            return;
        if (this.state.friends_arr.length == 0) 
        {
            Alert.alert(  
                '',  
                'Select your friends.',  
                [  
                    {text: 'OK', onPress: () => console.log('Ask me later pressed')},  
                ],  
                {cancelable: false}  
            ) 
            return;
        }
        var temp_user = []
        for (var i = 0 ;i < this.state.friends_arr.length ; i++) {
            temp_user.push(this.state.friends_arr[i].uid)
        }
        var group_obj = {
            title : this.state.title,
            description : this.state.description,
            privacy : this.state.privacy,
            friends_arr : temp_user
        }
        var user_arr = [];
        user_arr.push(global.user_info.uid)
        for (var i =0 ;i < this.state.friends_arr.length ; i++) {
            user_arr.push(this.state.friends_arr[i].uid)
        }
        var chat_data = {
            group_info : group_obj,
            user_data : user_arr,
            message_content : [],
            id : '',
            type : 1,
        }
        this.setState({isLoading : true})
        this._messageService.addGroupMessage(chat_data).then((result) => {
            this.props.navigation.goBack()
            this.setState({isLoading : false})
        }).catch((error) => {
            this.setState({isLoading : false})
        })
    } 
    selectedPrivacy =(value) => { //gender select
        this.setState({privacy : value})
    }
    addFriend = () => {
        this.props.navigation.navigate('MyFriendSearch',{onGoBack: this.setFriendFunc})
    }
    setFriendFunc=(user_info)=> {
        var temp = this.state.friends_arr;
        var flag = false;
        for (var i = 0; i < temp.length ;i++) {
            if (temp[i].uid == user_info.uid) {
                flag = true;
                break;
            }
        }
        if (!flag) {
            temp.push(user_info);
            this.setState({friends_arr : temp})
        }
    }

    render() {
        return (
            <View style={{width: '100%', backgroundColor:'#f4f9fc', flex : 100, flexDirection : 'column'}}>
                <KeyboardAwareScrollView
                    resetScrollToCoords={{ x: 0, y: 0 }}
                    contentContainerStyle={{flex : 1}}
                    scrollEnabled={false}
                >

                
                <ScrollView style={{height : '100%'}}>
                    <View style={{marginTop : 15 * metrics}}></View>
                    <View style={styles.body}>
                        <View style={styles.edit_body}>
                            <View style={styles.f_item}>
                                <Text style={styles.title}>Title</Text>
                                <TextInput
                                    underlineColorAndroid = "transparent"
                                    placeholder = ""
                                    placeholderTextColor = "gray"
                                    autoCapitalize = "none"
                                    value = {this.state.title}
                                    onChangeText = { (text) => this.setState({title : text})}
                                    style={global_style.text_input}/>
                            </View>
                            <Text style={(this.state.btn_flag && this.state.title == '') ? styles.error : styles.non_error}> Title is required.</Text>

                            <View style={[styles.item, {borderBottomWidth : 1, borderBottomColor : '#d8d8d8'}]}>
                                <Text style={styles.title}>Privacy(premium Members)</Text>
                                <View style={{ marginTop : 10 , marginBottom : 10}}>
                                    {
                                        Platform.OS == 'android' && 
                                        <Picker selectedValue = {this.state.privacy} onValueChange = {this.selectedPrivacy} style={styles.privacy}>
                                            <Picker.Item label = "Public" value = '0'style ={{width : '100%'}}/>
                                            <Picker.Item label = "Private" value = '1' style ={{width : '100%'}}/>
                                        </Picker>
                                    }
                                    {
                                        Platform.OS == 'ios' && 
                                        <RNPickerSelect
                                            placeholder ="Select Gender"
                                            onValueChange={(value) => this.selectedPrivacy(value)}
                                            items={[
                                                { label: 'Public', value: '0' },
                                                { label: 'Private', value: '1' },
                                            ]}
                                        />    
                                    }
                                </View>
                            </View>
                        
                            <View style={styles.item}>
                                <Text style={styles.title}>Description</Text>
                                <Textarea
                                    containerStyle={styles.textareaContainer}
                                    style={global_style.textarea}
                                    defaultValue={this.state.text}
                                    placeholder={''}
                                    value= {this.state.description}
                                    placeholderTextColor={'#c7c7c7'}
                                    underlineColorAndroid={'transparent'}
                                    onChangeText={(text) => this.setState({description : text})}
                                />
                            </View>

                            <View style={styles.item}>
                                <Text style={styles.title}>Add Friends</Text>
                                <View style={styles.user}>
                                    <TouchableOpacity style={styles.new_friend} onPress = {()=> this.addFriend()}>
                                        <Image source = {require('../../../../assets/img/icon/plus_btn.png')} style={styles.plus_btn}/>
                                    </TouchableOpacity>
                                    {
                                        this.state.friends_arr.map((item, index) => {
                                            return (
                                                <Avatar
                                                    size="medium"
                                                    rounded
                                                    source={{uri : item.img_url}}
                                                    resizeMode={'stretch'}
                                                    style={styles.profile}
                                                    key={index}
                                                />
                                            )
                                        })
                                    }
                                </View> 
                            </View>
                        </View>
                    </View>
                    
                </ScrollView>
                <View style={{flex: 15}}>
                    <View style={global_style.bottom}>
                        <View style={{flex : 2.5}}></View>
                        <TouchableOpacity onPress={() => this.createGroup()} style={global_style.cyan_btn}>
                            <Text style={global_style.label}>Create Group</Text>
                        </TouchableOpacity>
                        <View style={{flex : 2.5}}></View>
                    </View>
                </View>

                <View style={this.state.isLoading ? styles.loading : styles.finish}>
                <LoadingBar/>
                </View>

                </KeyboardAwareScrollView>
            </View>
        )
    }
}
const styles = StyleSheet.create({
    body : {
        alignItems: 'center',
        alignSelf : 'center',
        marginTop: 15 * metrics,
        marginBottom : 90 * metrics,
        width : '95%',
        elevation : 4.5,
        backgroundColor : 'white',
        shadowOffset : {width : 0, height : 4},
        shadowOpacity : 0.2,
    },
    edit_body: {
        paddingLeft : 20 * metrics,
        paddingRight : 20 * metrics,
        width: '100%',
        overflow : 'hidden',
        borderRadius: 15 ,
        
        backgroundColor : 'white'
    },
    f_item: {
        margin: 15  * metrics,
        flexDirection : 'column',
        marginTop: 40 * metrics
    },
    item : {
        margin: 15 * metrics,
        flexDirection : 'column'
    },
    input : {
        borderRadius : 8,
        backgroundColor : 'whitesmoke',
        padding: 5 * metrics
    },
    backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%'
    },
    user : {
        paddingTop : 10 * metrics,
        flexDirection : 'row'
    },
    new_friend : {
        backgroundColor : '#b9b9b9',
        width : 45 * metrics,
        height: 45 * metrics,
        borderRadius : 45,
        borderWidth : 1,
        justifyContent: 'center',
        borderColor : '#b9b9b9',
        marginTop: 3 * metrics,
        margin:5 * metrics
    },
    plus_btn: {
        width : 25 * metrics,
        height: 25 * metrics,
        alignSelf : 'center',
    },
    profile: {
        width : 45 * metrics,
        height: 45 * metrics,
        marginTop: 3 * metrics,
        margin:5 * metrics
    },
    bottom: {
        width: '100%',
        height : 70 * metrics,
        position : 'absolute',
        bottom : 0,
        shadowOpacity : 0.2,
        elevation : 3.5,
        backgroundColor : 'white',
        elevation : 20
    },
    cyan_btn : {
        width: '55%',
        height: 45 * metrics,
        borderRadius: 40,
        alignItems: 'center',
        alignSelf :'center',
        backgroundColor: '#4f80ff',
        shadowColor: '#809adc',
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.4,
        shadowRadius: 7,  
        elevation : 3.5,
        marginTop : 7 * metrics
    },
    label : {
        height: '100%',
        alignItems: 'center',
        fontSize: 18 * metrics,
        color: 'white',
        marginTop: 10 * metrics,
    },
    title : {
        color: 'gray'
    },
    error : {
      color : 'red',
      fontSize : 13 * metrics,
      marginLeft : 10 * metrics
    }, 
    non_error : {
        display : 'none'
    },
    loading : {
        position : 'absolute',
        width : '100%',
        height : '100%',
        backgroundColor : 'black',
        opacity : 0.4
     },
     finish : {
        width : 0,
        height : 0,
        opacity : 0,
        position : 'absolute'
     },
})
export default AddGroupChatScreen