import React , {Component} from "react";
import { Text, View, StyleSheet, Image ,TextInput} from "react-native";
import GroupScreen from './GroupScreen';
import PostScreen from './PostScreen';

export class ExploreScreen extends Component{
  constructor(props) {
    super(props)
  }
  postRef = null;
  groupRef = null;

  onChangeState = (val) => {
    if (this.props.isSelected == 1) { //post
      this.postRef.wrappedInstance.onChangeState(val)
    } else { //group
      this.groupRef.wrappedInstance.onChangeState(val)
    }
  } 
  render_body () {
    if (this.props.isSelected == 1) 
      return <PostScreen navigation = {this.props.navigation} ref={(ref) => this.postRef = ref}/> //ref={this.postRef}
    else if (this.props.isSelected == 2) 
      return <GroupScreen navigation = {this.props.navigation} ref={(ref) => this.groupRef = ref}/>
  }

  render(){
      return(
        <View style={styles.container}>
          {
            this.render_body()
          }
        </View>
      )
  }
}
const styles = StyleSheet.create({
  container : {
      width: '100%',
      height: '100%',
  }
})
export default ExploreScreen;