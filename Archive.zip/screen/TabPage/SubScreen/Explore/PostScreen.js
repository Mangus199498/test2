import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet, TouchableOpacity,Button,TextProps,ScrollView, TouchableHighlight} from 'react-native';
import Star from 'react-native-star-view';
import global_style, {metrics} from '../../../../constants/globalStyles';
import PostService from '../../../../services/post.service';
import { replaceTitle } from '../../../../utils/utils';
import {sortDataByTime } from '../../../../utils/global.js'

import {  Avatar} from 'react-native-elements';
import { inject, observer } from 'mobx-react';
import PlanService from '../../../../services/plan.service';
import UserService from '../../../../services/user.service';

import LoadingBar from '../../../../components/LoadingBar';
@inject ('postService','planService','userService')
@observer

class Post extends Component {

    _planService : PlanService = this.props.planService
    _postService : PostService = this.props.postService
    _userService : UserService = this.props.userService

    constructor(props) {
        super(props);
        this.state = {
            starCount : 4.5,
            public_post_arr : [],
            private_post_arr : [],
            isLoading : false
        }
    }

    private_post_arr = [];
    public_post_arr = [];
    getDetail = (item) => {
        this.props.navigation.navigate('PostDetailScreen', {post_id : item.id});
    }
    componentWillUnmount () {
        this.postSubscribe()
        this.public_subscribe()
    }
    async getData() { //init plan data 
        this.setState({isLoading : true})
        var _this = this;

        this.postSubscribe = await this._postService.getAllDataByPrivate(global.user_info.uid).onSnapshot(function(result){
            const data = result.docs.map(doc => doc.data());
            var count = 0;
            if (data.length > 0) {
                data.forEach(element => {
                    _this._userService.getUserData(element.uid).then((res) => {
                        if (res.exists) {
                            element.uid = res.data()
                        }
                        count ++;
                        if (count == data.length) {
                            var Res = sortDataByTime(data)
                            _this.private_post_arr = Res
                            _this.setState({private_post_arr : Res});       
                            _this.setState({isLoading : false}) 
                        }
                    })
                });
            } else {
                _this.setState({private_post_arr : []});     
                _this.private_post_arr = []  
                _this.setState({isLoading : false})
            }
        })

        this.public_subscribe =  await this._postService.getAllDataByPublic().onSnapshot(function(result) {
            const data = result.docs.map(doc => doc.data());
            var count = 0;
            if (data.length > 0) {
                data.forEach(element => {
                    _this._userService.getUserData(element.uid).then((res) => {
                        if (res.exists) {
                            element.uid = res.data()
                        }
                        count ++;
                        if (count == data.length) {
                            var Res = sortDataByTime(data)
                            _this.public_post_arr = Res
                            _this.setState({public_post_arr : Res});       
                            _this.setState({isLoading : false}) 
                        }
                    })
                });
            } else {
                _this.setState({public_post_arr : []});      
                _this.public_post_arr = [] 
                _this.setState({isLoading : false})
            }
        })
    }

    onChangeState = (val) => { //update by search
        if (val == '') {
            this.setState({private_post_arr : this.private_post_arr})
            this.setState({public_post_arr : this.public_post_arr})
        } else {
            var temp_arr1 = [];
            for (var i = 0 ; i < this.private_post_arr.length ; i++) {
                if(this.private_post_arr[i].address.name.toLowerCase().indexOf(val.toLowerCase())!=-1 || this.private_post_arr[i].description.toLowerCase().indexOf(val.toLowerCase())!=-1) {
                    temp_arr1.push(this.private_post_arr[i]);
                }
            }

            var temp_arr2 = [];
            for (var i = 0 ;i <  this.public_post_arr.length ; i++) {
                if(this.public_post_arr[i].address.name.toLowerCase().indexOf(val.toLowerCase())!=-1 || this.public_post_arr[i].description.toLowerCase().indexOf(val.toLowerCase())!=-1) {
                    temp_arr2.push(this.public_post_arr[i]);
                }
            }

            this.setState({private_post_arr : temp_arr1})
            this.setState({public_post_arr : temp_arr2})
        }
    }

    componentDidMount() {
        this.getData();
    }
    renderPlanList() {
        
    }
    render() {
        return (
            <View style={{height : '100%'}}>
                
                <ScrollView style={styles.post_container}>
                { 
                    this.state.private_post_arr.map((post_item, index) => {
                        return (
                            <View style={styles.item} key={index}>
                                {
                                    post_item.data_arr.length > 0 ? 
                                    <Image source={{uri : post_item.data_arr[0]}} style={styles.img}/>
                                     :
                                     <View style={styles.blank_img}></View>
                                }
                                <View style={styles.right_body}>
                                    <Text style={styles.small_title}>
                                    {
                                        typeof(post_item.address) == "undefined" ? 'NONE' : replaceTitle(post_item.address.name)
                                    }
                                    </Text>
                                    <Text style={styles.big_title}>{replaceTitle(post_item.title)}</Text>
                                    <View style={styles.star_rating}>
                                        <Star score={post_item.star_rating} style={global_style.starStyle}/>
                                    </View>
                                    <View style={styles.profile_body}>
                                        {
                                            post_item.uid.img_url != '' ? 
                                                <Avatar
                                                    rounded
                                                    source={{uri : post_item.uid.img_url}}
                                                    resizeMode={'stretch'}
                                                    style={styles.profile}
                                                    />
                                                : <View style={styles.profile}></View>    
                                        }
                                        <View style={styles.profile_name}>
                                            <Text style={styles.bytag}>By</Text>
                                            <Text style={styles.name}>{post_item.uid.f_name} {post_item.uid.l_name}</Text>
                                        </View>
                                    </View>
                                    <TouchableOpacity style={styles.details} onPress={() => this.getDetail(post_item)}>
                                        <Text style={styles.detail_label}>See Details <Image source = {require('../../../../assets/img/icon/right_arrow.png')} style={styles.right_arrow}/></Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        );
                    })
                }
                { 
                    this.state.public_post_arr.map((post_item, index) => {
                        return (
                            <View style={styles.item} key={index}>
                                {
                                    post_item.data_arr.length > 0 ? 
                                    <Image source={{uri : post_item.data_arr[0]}} style={styles.img}/>
                                     :
                                     <View style={styles.blank_img}></View>
                                }
                                <View style={styles.right_body}>
                                    <Text style={styles.small_title}>
                                    {
                                        typeof(post_item.address) == "undefined" ? 'NONE' : replaceTitle(post_item.address.name)
                                    }
                                    </Text>
                                    <Text style={styles.big_title}>{replaceTitle(post_item.title)}</Text>
                                    <View style={styles.star_rating}>
                                        <Star score={post_item.star_rating} style={global_style.starStyle}/>
                                    </View>
                                    <View style={styles.profile_body}>
                                        {
                                            post_item.uid.img_url != '' ? 
                                                <Avatar
                                                    rounded
                                                    source={{uri : post_item.uid.img_url}}
                                                    resizeMode={'stretch'}
                                                    style={styles.profile}
                                                    />
                                                : <View style={styles.profile}></View>    
                                        }
                                        <View style={styles.profile_name}>
                                            <Text style={styles.bytag}>By</Text>
                                            <Text style={styles.name}>{post_item.uid.f_name} {post_item.uid.l_name}</Text>
                                        </View>
                                    </View>
                                    <TouchableOpacity style={styles.details} onPress={() => this.getDetail(post_item)}>
                                        <Text style={styles.detail_label}>See Details <Image source = {require('../../../../assets/img/icon/right_arrow.png')} style={styles.right_arrow}/></Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        );
                    })
                }
                
            </ScrollView> 
            <View style={this.state.isLoading ? global_style.loading : global_style.none}>
                <LoadingBar />
            </View>
            
        </View>
                         
        )
    }
}
const styles = StyleSheet.create({
    post_container : {
        width: '100%',
        backgroundColor : '#f1f6f9',
        marginTop : 10 * metrics
    },  
    item : {
        flex: 1,
        flexDirection : 'row',
        margin : 10 * metrics,
    },
    blank_img : {
        width : '60%',
        height : 170  * metrics,
        resizeMode: "stretch",
        borderRadius : 10,
        borderColor :'#8a8888',
        borderWidth : 1,
        backgroundColor : 'whitesmoke',
        padding : 10  * metrics
    },
    img : {
        width : '60%',
        height : 170  * metrics,
        borderRadius : 10 ,
        elevation : 1.5,
        padding : 10  * metrics,
        
    },
    right_body: {
        width : '50%',
        height: 140  * metrics,
        backgroundColor : 'white',
        marginLeft : -37  * metrics,
        marginTop: 15  * metrics,
        borderRadius : 5,
        resizeMode : "stretch",
        shadowColor : '#8a8888',
        shadowOpacity: 0.7,
        shadowOffset : {width : 0, height : 2},
        padding : 10  * metrics,
        elevation : 3.5
    },
    small_title : {
        fontSize : 11  * metrics,
        marginLeft : 3 * metrics
    },
    big_title: {
        fontSize : 15  * metrics,
        marginLeft : 3 * metrics,
        marginTop : 2 * metrics,
        color: '#4f80ff'
    },
    star_rating : {
        width: '55%',
        marginTop: 3  * metrics,
        flexDirection : 'row'
    },
    profile_body : {
        flex: 1,
        flexDirection :'row',
        marginBottom : 2  * metrics,
        
    },
    profile: {
        width : 33  * metrics,
        height: 33  * metrics,
        resizeMode : "stretch",
        marginTop: 3  * metrics
    },
    profile_name : {
        flex: 1,
        flexDirection : "column",
        marginLeft: 10  * metrics,
        marginTop: 3  * metrics
    },
    bytag : {
        color : 'gray',
        fontSize : 12  * metrics
    }, 
    name : {
        fontSize : 14  * metrics,
        fontWeight: '400'
    },
    details : {
        padding: 0 * metrics,
        height: 24 * metrics,
        borderTopColor : '#ececec',
        borderTopWidth : 1
    },
    detail_label : {
        marginTop: 10 * metrics,
        fontSize: 12 * metrics,
        textAlign : 'center'
    },
    right_arrow : {
        height: 7 * metrics,
        width: 7 * metrics
    },
    starStyle : {
        width: 100 * metrics,
        height: 20 * metrics
    },
})
export default Post