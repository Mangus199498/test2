import React, { Component } from 'react';
import { View , Text, Image,StyleSheet,TouchableOpacity,TextInput, ScrollView,Alert, Platform } from 'react-native';
import Star from 'react-native-star-view';

import global_style , {metrics} from  '../../../../../constants/globalStyles';
import { getCommentTime } from '../../../../../utils/moment';
import { replaceTitle } from '../../../../../utils/utils';
import { sortDataByDate } from '../../../../../utils/global';
import Swiper from 'react-native-swiper';
import { Avatar} from 'react-native-elements';

import { inject, observer } from 'mobx-react';

import UserService from '../../../../../services/user.service';
import PostService from '../../../../../services/post.service';
import PlanService from '../../../../../services/plan.service';
import MessageService from '../../../../../services/message.service';

import LoadingBar from '../../../../../components/LoadingBar';
import Toast from 'react-native-simple-toast';

import fav_icon from '../../../../../assets/img/icon/ico_star.png'
import fav_active_icon from '../../../../../assets/img/icon/yellow-star.png'

import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
let _this = null

@inject ('userService')
@inject ('postService')
@inject ('planService')
@inject ('messageService')
@observer


class PostDetailScreen extends Component {
    
    _userService : UserService = this.props.userService;
    _postService : PostService = this.props.postService;
    _planService : PlanService = this.props.planService;
    _messageService : MessageService = this.props.messageService;
    isCalculating = false;
    constructor (props) {
        super(props)
        this.state = {
            detail_item : '',
            comment_txt : '',
            user_arr : [],
            isLoading : false,
            isSelected : 0,
            isWriting : false
        }
        
    }
    intervalfunc = null
    user_data= []; // total user
    componentWillMount () {
        _this = this
        this.setState({detail_item : ''});
        var post_id = this.props.navigation.getParam('post_id');
        this.setState({isSelected : 0})
        this.props.navigation.setParams({ favorite: this.onClickedFavorite });
        this.props.navigation.setParams({ goBack : this.backScene});
        this.reloadPostData(post_id);
        this.intervalfunc =  setInterval(() => {
            this.nextReloadData(post_id);
        }, 5000);
    }
    async nextReloadData(post_id) {
        
        this._postService.getDataById_F(post_id).then((result) => {
            if (result.exists) { 
                
                var data = result.data();
                if (data.comment == null || data.comment.length > 0) {
                    var count = 0;
                    data.comment.forEach(element => {
                        this._userService.getUserData(element.uid).then((result) => {
                            if (result.exists) {
                                element.uid =  result.data();
                            } 
                            count ++;
                            if (count == data.comment.length) {
                                this.checkOverrideValue(data.comment)
                            }
                        })
                    });
                } else {
                    this.checkOverrideValue(data.comment)
                }
            }
        }).catch((error) => {
            console.log(error)
        })
    }
    checkOverrideValue (data) {
        var temp_arr = []
        for (var i = 0 ; i < data.length;i ++) {
            var count = 0;
            for (var j = 0; j < this.state.user_arr.length ; j++) {
                if (data[i].date == this.state.user_arr[j].date) {
                    count++;
                    break;
                } 
            }
            if (count == 0) { //new
                temp_arr.push(data[i])
            }
        }
        for (var i = 0; i < temp_arr.length ;i ++) {
            this.state.user_arr.push(temp_arr[i])
        }
        this.setState({user_arr : this.state.user_arr});
    }
    async reloadPostData(post_id) {
        this.setState({isLoading : true})
        var _this = this;
        this._postService.getDataById_F(post_id).then((result) => {
            if (result.exists) { 
                var count = 0;
                var data = result.data();
                if (data.comment == null || data.comment.length > 0) {
                    data.comment.forEach(element => {
                        this._userService.getUserData(element.uid).then((result) => {
                            if (result.exists) {
                                element.uid =  result.data();
                            } 
                            count ++;
                            if (count == data.comment.length) {

                                this.setState({detail_item :data})
                                this.setState({user_arr : sortDataByDate(data.comment)})
                                this.props.navigation.setParams({navTitle: data.title});
                                this.checkFavorite()
                            }
                        })
                    });
                } else {
                    this.setState({detail_item : data})
                    this.props.navigation.setParams({navTitle: data.title});
                    this.checkFavorite()
                }
            }
        }).catch((error) => {
            console.log(error)
        })
    }

    checkFavorite() {
        if (this.state.detail_item.favorite.length > 0) {
            var count = 0;
            for (var i = 0 ; i < this.state.detail_item.favorite.length ;i++) {
                if (global.user_info.uid == this.state.detail_item.favorite[i]) {
                    this.props.navigation.setParams({ isSelectedFav: 1 });
                    count = 1;
                    break;
                }
            }

            if (count == 0) {
                this.props.navigation.setParams({ isSelectedFav: 0 });
            }
        } else {
            this.props.navigation.setParams({ isSelectedFav: 0 });
        }
        
    }

    writeBtn() {
        if (this.state.comment_txt == '')
            return;
        if (this.state.isWriting)
            return;
        this.setState({isWriting : true})
        var new_obj = {
            uid : global.user_info.uid,
            text : this.state.comment_txt,
            date : new Date().getTime()
        }
        var data = this.state.detail_item;
        
        if (data.comment.length >0 ) {
            var temp_arr = [];
            for(var i =0 ; i < data.comment.length ;i ++) {
                var item = data.comment[i];
                if (item.uid.uid == undefined) {
                    var obj = {
                        date : item.date,
                        text : item.text,
                        uid : item.uid
                    }
                } else {
                    var obj = {
                        date : item.date,
                        text : item.text,
                        uid : item.uid.uid,
                    }
                }
                
                temp_arr.push(obj)
            }
            data.comment = temp_arr;
        }
        data.comment.push(new_obj);
        
        this._postService.updateData(data.id, data).then((result) => {
            
            var user_info = {
                uid : global.user_info,
                text : this.state.comment_txt,
                date : new_obj.date
            }
            this.state.user_arr.push(user_info)
            this.setState({user_arr : this.state.user_arr})
            this.setState({isWriting : false})
            this.setState({comment_txt : ''})
        }).catch((error) => {
            this.setState({isWriting : false})
            this.setState({comment_txt : ''})
            console.log(error)
        })
        console.log(data)
    }
    onClickedFavorite = () => {
        var rslt_flag = false
        if (this.isCalculating == true) return;
        if (this.props.navigation.getParam('isSelectedFav') == 0) {
            this.props.navigation.setParams({ isSelectedFav: 1 });
            rslt_flag = true;
        } else {
            rslt_flag = false;
            this.props.navigation.setParams({ isSelectedFav: 0 });
        }
        if (this.state.detail_item.comment.length >0 ) {
            var temp_arr = [];
            for(var i =0 ; i < this.state.detail_item.comment.length ;i ++) {
                var item = this.state.detail_item.comment[i];
                if (item.uid.uid == undefined) {
                    var obj = {
                        date : item.date,
                        text : item.text,
                        uid : item.uid
                    }
                } else {
                    var obj = {
                        date : item.date,
                        text : item.text,
                        uid : item.uid.uid
                    }
                }
                
                temp_arr.push(obj)
            }
            
            this.state.detail_item.comment = temp_arr;
        }
        this.isCalculating = true;
        if (rslt_flag) { //add favorite
            this.state.detail_item.favorite.push(global.user_info.uid);
            this._postService.updateData(this.state.detail_item.id, this.state.detail_item).then((result) => {
               this.isCalculating = false
            }).catch((error) => {
                this.isCalculating = false
            }) 
        } else { //remove favorite
            var fav_arr = []
            if (this.state.detail_item.favorite.length > 0) {
                for (var i = 0 ; i < this.state.detail_item.favorite.length ;i++) {
                    if (global.user_info.uid != this.state.detail_item.favorite[i]) {
                        fav_arr.push(this.state.detail_item.favorite[i])
                        break;
                    }
                }
            }
            this.state.detail_item.favorite = fav_arr
            this._postService.updateData(this.state.detail_item.id, this.state.detail_item).then((result) => {
                this.isCalculating = false;
            }).catch((error) => {
                this.isCalculating = false
            })
        }
    }
    backScene = () => {
        clearInterval(this.intervalfunc);
        this.props.navigation.navigate('TabsPage');
    }
    onClickedShare = () => {
        if (global.user_info.membership == 'free') {
            Alert.alert(
                'Upgrade',
                'Your membership have to upgrade now.',
                [
                  {
                    text: 'Cancel',
                    onPress: () => console.log('cancel'),
                    style: 'cancel',
                  },
                  {text: 'Upgrade', onPress: () => this.props.navigation.navigate('UpgradePlanScreen')},
                ],
                {cancelable: false},
            );
            return;
        } else {
            var _this = this
            this._messageService.getDataByUID(global.user_info.uid).then((result) => {
                const data = result.docs.map(doc => doc.data());
                data.forEach((item, index) => {
                    var message_obj = {
                        uid : global.user_info.uid,
                        message : _this.state.detail_item.description,
                        date : new Date(),
                        img : _this.state.detail_item.data_arr[0],
                        post_id : _this.state.detail_item.id
                    }
                    item.message_content.push(message_obj)
                    _this._messageService.updateGroupMessage(item.id, item).then((result) => {
                        Toast.show('This post is shared!', Toast.LONG);
                        console.log(result)
                    }).catch((error) => {
                        console.log(error)
                    })
                })
            })
        }
    }
    static navigationOptions = ({ navigation }) => {
        const { params = {} } = navigation.state;
        return {
            headerLeft: (
                <View style={global_style.navigation}>
                    <TouchableOpacity 
                        style={styles.backarrow}
                        onPress ={navigation.getParam('goBack')}>
                            <Image source = {require('../../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                            <Text style={global_style.back_title}>{params.navTitle}</Text>
                    </TouchableOpacity> 
                </View>
            ),
            headerRight : (
                <TouchableOpacity onPress ={navigation.getParam('favorite')}>
                    {
                        params.isSelectedFav == 0 ? 
                        <Image source ={fav_icon} style={styles.fav_icon}></Image>
                        :
                        <Image source ={fav_active_icon} style={styles.fav_icon}></Image>
                    }
                    
                </TouchableOpacity>
            ),
            headerStyle: global_style.headerHeight,
        };
    };
   render() {
      return (
        <View style={{width: '100%', height : '100%'}}>
            <KeyboardAwareScrollView
                    resetScrollToCoords={{ x: 0, y: 0 }}
                    contentContainerStyle={{flex : 1}}
                    scrollEnabled={false}
            >
            <View style={!this.state.isLoading ? {width : '100%', height : '100%'} : null}>
                {
                    this.state.detail_item == '' ? null : 
                    <ScrollView style={{height : '100%'}} bounces = {false}>
                        <Swiper style={styles.wrapper} showsButtons={false}>
                            {
                                this.state.detail_item.data_arr.map((element,index) => {
                                    return (
                                        <View style={{flex : 1}} key={index}>
                                            <Image source = {{uri : element}} style={styles.bg_img}/>
                                        </View>          
                                    );
                                })
                            }
                        </Swiper>
                        <View style = {styles.sub_body}>
                            <View style={styles.title}>
                                <Text style={{fontSize : 20, fontWeight : '400', marginLeft : 5}}>{replaceTitle(this.state.detail_item.title)}</Text>
                                <View style={styles.star_rating}>
                                    <Star score={this.state.detail_item.star_rating} style={global_style.starStyle}/>
                                </View>
                            </View>
                            <View style={styles.title}>
                                <Text style={styles.gray_title}>{this.state.detail_item.address.city_name.city_name} , {this.state.detail_item.address.city_name.country_name}</Text>
                            </View>
                            
                            <View style={styles.line}></View>
                            <View style={styles.icon_body}>
                                <Image source = {require('../../../../../assets/img/icon/ico_like.png')} style={styles.icon_like}></Image>
                                <Text> {this.state.detail_item.favorite.length}</Text>
                                <Text>         </Text>
                                <Image source = {require('../../../../../assets/img/icon/ico-inbox.png')} style={styles.icon_inbox}></Image>
                                <Text> {this.state.detail_item.comment == null ? null :this.state.detail_item.comment.length}</Text>
                                <TouchableOpacity style={{position : 'absolute',right : 5}} onPress={ ()=>this.onClickedShare()}>
                                    <Image source = {require('../../../../../assets/img/icon/ico_share.png')} style={styles.icon_share} ></Image>
                                </TouchableOpacity>
                            </View>
                            <View style={styles.line}></View>
                            <View style={styles.user_body}>
                                {
                                    this.state.user_arr == null ? null :
                                    this.state.user_arr.map((item, index) => {
                                        return (
                                        <View style={styles.user} key={index}>
                                            <Avatar
                                                rounded
                                                overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                                                size="xlarge"
                                                source={{uri : item.uid.img_url}}
                                                resizeMode={'stretch'}
                                                containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                                                style = {styles.profile}
                                                />
                                            <View style={styles.name}>
                                                <Text style={{fontSize: 17, fontWeight: '400'}}>{item.uid.f_name} {item.uid.l_name}</Text>
                                                <Text style={{fontSize: 12, width : 200, backgroundColor: 'white',flexShrink: 1}}>{item.text}</Text>
                                            </View>
                                            <Text style={styles.time}>{getCommentTime(item.date)}</Text>
                                        </View>
                                        )
                                    })
                                }
                            </View>
                        </View>
                    </ScrollView>
                }
                {
                    this.state.detail_item.uid == global.user_info.uid && this.state.isLoading ? null :
                    <View style={styles.bottom_body}>
                        <TextInput
                            underlineColorAndroid = "transparent"
                            placeholder = "Write Comment"
                            placeholderTextColor = "gray"
                            autoCapitalize = "none"
                            value= {this.state.comment_txt}
                            style={global_style.comment_style}
                            onChangeText={(text) => this.setState({comment_txt : text})}/>
                        
                        <TouchableOpacity onPress={() => this.writeBtn()} style={{flex : 15 , alignSelf : 'center'}}>
                            <Image source={require('../../../../../assets/img/icon/ico_next.png')} style={{width: 37 * metrics, height: 37 * metrics, resizeMode : 'stretch',marginLeft : 10 * metrics , marginRight : 5 ,alignSelf : 'center'}}></Image>
                        </TouchableOpacity>
                    </View>
                }
            </View>
            <View style={this.state.isLoading ? styles.loading : styles.none}>
                <LoadingBar />
            </View>
            </KeyboardAwareScrollView>
        </View>
            
         
      )
   }
}
const styles = StyleSheet.create({
    wrapper : {
        width: '100%',
        height: 300 * metrics,
    },
    bg_img: {
        width: '100%',
        height: 300 * metrics,
    }, 
    backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%'
    },
    sub_body : {
        width:'100%',
        height : '100%',
        backgroundColor : 'white',
        borderTopLeftRadius : 25,
        borderTopRightRadius : 25,
        marginTop: -20 * metrics,
        paddingBottom : 50 * metrics,
    },
    title : {
        height : 'auto' , 
        width : '100%',
        flexDirection : 'row',
        padding: 8 * metrics,
        marginTop : 10 * metrics,
        paddingLeft : 15 * metrics,
        paddingRight : 15 * metrics,
        paddingBottom: 0
    },   
    star_rating : {
        width : '25%',
        position : "absolute",
        alignItems : 'center',
        alignSelf : 'center',
        right : 20 * metrics,
            
    },
    check_num : {
        position : "absolute",
        alignItems : 'center',
        right : 15 * metrics,
        fontSize: 12 * metrics
    },
    gray_title: {
        color: '#8e8e8e',
        fontSize: 12 * metrics,
        marginLeft : 5 * metrics
    },
    line : {
        borderBottomWidth : 1, borderBottomColor : '#ececec', paddingTop : 7 * metrics , marginBottom : 8 * metrics
    },
    bottom_body: {
        width : '100%',
        position : 'absolute',
        bottom: 0,
        flex : 10,
        flexDirection : 'row',
        height : 55 * metrics,
        elevation : Platform.OS == 'ios' ?  1.0 : 10,
        shadowOffset : {width : 0, height : 10},
        shadowOpacity : Platform.OS == 'ios' ? 0.2 : 1,
        flexDirection : 'row',
        backgroundColor : 'white',
    },
    lock_icon : {
        width: 25 * metrics,
        height: 25 * metrics,
        resizeMode: "stretch",
        marginRight : 10 * metrics,
        marginTop: 30 * metrics, 
    },
    icon_like : {
        width: 20 * metrics,
        height: 20 * metrics,
        alignItems: 'flex-start',
        resizeMode : "stretch"
    },
    icon_inbox : {
        alignItems : 'flex-start',
        width: 20 * metrics,
        height: 20 * metrics,
        resizeMode : "stretch"
    },
    icon_body : {
        marginTop: 8 * metrics,
        marginBottom : 8 * metrics,
        paddingLeft: 20 * metrics,
        paddingRight : 15 * metrics,
        width: '100%',
        flexDirection: 'row',
    },
    icon_share : {
        width : 20 * metrics,
        height : 20 * metrics,
        resizeMode : "stretch",
        alignItems: 'center',
        alignSelf : 'center',
        marginRight : 10 * metrics,
        
        alignSelf : 'center'
    },
    user_body: {
        width: '100%',
        height : '100%'
    },
    user : {
        minHeight: 60 * metrics,
        width: '100%',
        marginTop : 10,
        flexDirection: 'row',
        borderBottomWidth: 1,
        paddingLeft : 7 * metrics,
        borderBottomColor : '#ececec'
    },
    profile : {
        width : 40 * metrics,
        height: 40 * metrics,
        resizeMode : 'stretch',
        alignSelf : 'flex-start',
        marginRight : 10 * metrics,
        marginLeft : 10 * metrics
    },
    name: {
        flexDirection : 'column',
        alignItems: 'flex-start',
        alignSelf : 'flex-start',
        marginLeft : 0,
        marginBottom : 15 * metrics,
    },
    time : {
        fontSize : 11 * metrics,
        color: '#b1b1b1',
        position : 'absolute',
        right : 20 * metrics,
        top : 0,
        alignSelf : 'center',
    },
    fav_icon : {
        width : 25 * metrics, height : 25 * metrics, marginRight : 10 * metrics, alignSelf : 'center', marginTop : 12 * metrics
    }
})
export default PostDetailScreen