import React, { Component } from 'react';
import { AppRegistry, View ,Text,TextInput, Image,StyleSheet,TouchableOpacity} from 'react-native';
import globalStyles , { metrics }from '../../../../../constants/globalStyles';
import PropTypes from 'prop-types'
import LoadingBar from '../../../../../components/LoadingBar';

import AddPost from './AddPostComponent';
import AddPlan from './AddPlanComponent';

class AddPostScreen extends Component {
   constructor (props) {
      super(props)
      this.state = {
         isSelected : 1,
         height : 0,
         isLoading : false,
         group_id : ''
      }
   }
   static navigationOptions = ({ navigation }) => {
      return {
          headerLeft: (
              <View style={globalStyles.navigation}>
                  <TouchableOpacity 
                      style={styles.backarrow}
                      onPress={() => navigation.goBack()} >
                           <Image source = {require('../../../../../assets/img/icon/left_arrow.png')} style={globalStyles.arrow_icon}/> 
                           <Text style={globalStyles.back_title}>ADD NEW</Text>
                  </TouchableOpacity>
              </View>
          ),
          headerStyle: globalStyles.headerHeight
      };
   };
   goback() {

   }
   componentWillMount () {
      if (this.props.navigation.getParam('group_id') == undefined) {
         this.setState({group_id : ''})
      } else {
         this.setState({group_id : this.props.navigation.getParam('group_id')})
      }
      this.setState({isSelected : 1})
   }
   onClickedTab = (value) => {
      this.setState({isSelected : value})
   }
   tabpage () {
       return <View style={globalStyles.add_tabbar}>
                  <TouchableOpacity style={this.state.isSelected == 1 ? globalStyles.active : globalStyles.non_active} onPress={ () =>this.onClickedTab(1)}>
                     <View style={styles.wrapper_view}>
                           <Text style={this.state.isSelected == 1 ? styles.wrapper_label_selected : styles.wrapper_label }>POST</Text>
                     </View>
                  </TouchableOpacity>
                  <TouchableOpacity style={this.state.isSelected == 2 ? globalStyles.active : globalStyles.non_active} onPress={() =>this.onClickedTab(2)}>
                     <View style={styles.wrapper_view}>
                        <Text style={this.state.isSelected == 2 ? styles.wrapper_label_selected : styles.wrapper_label }>TRIP PLAN</Text>
                     </View>
                  </TouchableOpacity>
               </View>;
   }
   isLoadingFunction = (value) => {
      this.setState({isLoading : value});
   }
   bodypage () {
      if (this.state.isSelected == 1 && this.state.group_id == '') {
         return <AddPost isLoadingFunction={this.isLoadingFunction} navigation = {this.props.navigation} group_id = {this.state.group_id}/>;
      } else if (this.state.isSelected == 2 && this.state.group_id == '') {
         return <AddPlan isLoadingFunction={this.isLoadingFunction} navigation = {this.props.navigation} group_id = {this.state.group_id}/>;
      } else if (this.state.isSelected == 1 && this.state.group_id != '') {
         return <AddPost isLoadingFunction={this.isLoadingFunction} navigation = {this.props.navigation} group_id = {this.state.group_id}/>;
      } else if (this.state.isSelected == 2 && this.state.group_id != '') {
         return <AddPlan isLoadingFunction={this.isLoadingFunction} navigation = {this.props.navigation} group_id = {this.state.group_id}/>;
      }
   }
   render() {
      return (
         <View style={{width: '100%', height : '100%'}}>
            <View style={[styles.tabbar,{backgroundColor : '#f7fcff', flex : 100 , flexDirection : 'column'}]}>
                { this.tabpage()}
                { this.bodypage()}
            </View>
            <View style={this.state.isLoading ? styles.loading : styles.finish}>
               <LoadingBar/>
            </View>
        </View>
      )
   }
}
const styles = StyleSheet.create({
   backarrow : {
      flex: 1,
      flexDirection : 'row',
      width: '100%',
   },
   tabbar : {
      width : '100%'
   },
   item : {
      width : '95%',
      margin : 'auto',
      marginTop : 15 * metrics,
      flexDirection : 'column',
      shadowOffset : { width : 0, height : 2},
      shadowColor : '#d8d8d8',
      shadowRadius : 20,
      shadowOpacity : 0.7,
      borderRadius : 10
   },
   wrapper_view : {
      marginTop : 5 * metrics,
      alignItems : 'center',
      width : '100%'
   },
   wrapper_label: {
      paddingTop : 10 * metrics,
      paddingBottom : 10,
      color : 'gray',
      alignSelf : 'center',
      fontWeight : '600'
   },
   wrapper_label_selected : {
      paddingTop : 10 * metrics,
      paddingBottom : 10,
      alignSelf : 'center',
      color : 'black',
      fontWeight : '600'
   },
   user : {
      paddingTop : 10 * metrics,
      flexDirection : 'row'
   },
   loading : {
      position : 'absolute',
      width : '100%',
      height : '100%',
      backgroundColor : 'black',
      opacity : 0.4
   },
   finish : {
      width : 0,
      height : 0,
      opacity : 0,
      position : 'absolute'
   },
})
export default AddPostScreen