import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,TextInput, ScrollView,Picker, Alert, Platform ,TouchableWithoutFeedback , Keyboard} from 'react-native';
//import ImagePicker from 'react-native-image-picker';
import ImagePicker from 'react-native-image-crop-picker';
import global_style , { metrics }from '../../../../../constants/globalStyles';
import { inject, observer } from "mobx-react";
import PropTypes from 'prop-types'
import Textarea from 'react-native-textarea';
import StorageService from '../../../../../services/storage.service';
import PostService from '../../../../../services/post.service';
import UserService from '../../../../../services/user.service';
import NotificationService from '../../../../../services/notification.service';
import GroupService from '../../../../../services/group.service';
import RNPickerSelect from 'react-native-picker-select';
import { GooglePlacesAutocomplete } from 'react-native-google-places-autocomplete';
import { Google_API_KEY } from '../../../../../utils/utils';
import { Avatar} from 'react-native-elements';
import { postId } from '../../../../../utils/utils';

import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'


@inject('storageService')
@inject('postService')
@inject('userService')
@inject('notificationService')
@inject ('groupService')
@observer

class AddPost extends Component {

    _storageService : StorageService = this.props.storageService
    _notificationService : NotificationService = this.props.notificationService
    _postService : PostService = this.props.postService
    _userService : UserService = this.props.userService
    _groupService : GroupService = this.props.groupService

    constructor (props) {
        super(props)
        this.state = {
            title: '',
            privacy : '1',
            description : '',
            friend_arr : [],
            photo_arr: [],
            updated: false,
            address : '',
            group_id : '',
            join_arr : []
        }
        
    }
    componentWillMount () {
        if (this.props.group_id == '') {
            this.setState({group_id : ''})
        } else {
            this.setState({group_id : this.props.group_id})
        }
        this.setState({photo_arr : []});
    }

    addGroupPost () {
        var _this = this;
        this.setState({btn_flag : true})
        if (this.state.title == '' || this.state.address == '') {
            return;
        }
        var random = (Math.random() * 1000) % 5

        var post_obj = {
            title : this.state.title,
            privacy : this.state.privacy,
            description : this.state.description,
            data_arr : [],
            uid : global.user_info.uid,
            check_num : '',
            comment : [],
            favorite : [],
            star_rating : parseInt(random),
            time : new Date().getTime(),
            btn_flag : false
        }

        const uploaderHandler = [];
        
        this.state.photo_arr.forEach(item => {
            uploaderHandler.push(new Promise((resolve ,rejects) => {
                if (item.downloadUrl !== undefined) {
                    resolve();
                    return;
                }
                this._storageService.uploadImage(post_obj.title, item //global.user_info.id
                    , (uploadTask, progress) => {
                    item.progress = progress;
                    item.uploadTask = uploadTask;
                    this.setState({ updated: !this.state.updated });
                }).then(async (result) => {
                    item.downloadUrl = result.url;
                    resolve()
                }).catch(err => {
                    item.err = err;
                    item.progress = -1;
                    this.setState({ updated: !this.state.updated });
                    resolve()
                });
            }));
        })
        this.props.isLoadingFunction(true);
        Promise.all(uploaderHandler).then(_ => { 
            var temp = []
            this.state.photo_arr.forEach(item => {
                temp.push(item.downloadUrl)
            });
            
            post_obj.data_arr = temp;
            this.setState({photo_arr : []})

            this._groupService.getGroupDataByUpdateId(this.state.group_id).then((result) => {
                if (result.exists) {
                    const data = result.data();
                    
                    var post_arr = data.post_arr
                    post_arr.push(post_obj)

                    data.post_arr = post_arr
                    this._groupService.updateGroup(this.state.group_id,data).then((res) => {
                        this.props.navigation.navigate('MyInfoScreen')  
                        this.props.isLoadingFunction(false);
                        this.resetAll();
                    }).catch((error)=> {
                        this.props.isLoadingFunction(false);
                        console.log(error)
                    })
                }
            }).catch((error) => {
                this.props.isLoadingFunction(false);
                console.log(error)
            })
        })
    }

    addPost() {
        this.setState({btn_flag : true})
        if (this.state.title == '' || this.state.address == '') {
            return;
        }
        if (this.state.privacy == '1' && this.state.friend_arr.length == 0) {
            Alert.alert(  
                '',  
                'Select your friends',  
                [  
                    {text: 'OK', onPress: () => console.log('Ask me later pressed')},  
                ],  
                {cancelable: false}  
            ) 
            return;
        }
        if (this.state.photo_arr.length == 0) {
            Alert.alert(  
                '',  
                'Select your photos',  
                [  
                    {text: 'OK', onPress: () => console.log('Ask me later pressed')},  
                ],  
                {cancelable: false}  
            ) 
            return;
        }
        var address = this.makeAddressInfo()

        var user_arr = [];
        for(var i = 0; i < this.state.friend_arr.length ; i++) {
            user_arr.push(this.state.friend_arr[i].uid)
        }
        this.state.join_arr = user_arr;
        var random = (Math.random() * 1000) % 5
        var obj = {
            title : this.state.title,
            privacy : this.state.privacy,
            description : this.state.description,
            friend_arr : [],
            data_arr : [],
            uid : global.user_info.uid,
            check_num : '',
            comment : [],
            favorite : [],
            address : address,
            star_rating : parseInt(random),
            join_arr: user_arr,
            time : new Date().getTime()
        }

        const uploaderHandler = [];
        
        this.state.photo_arr.forEach(item => {
            uploaderHandler.push(new Promise((resolve ,rejects) => {
                if (item.downloadUrl !== undefined) {
                    resolve();
                    return;
                }
                this._storageService.uploadImage(obj.title, item //global.user_info.id
                    , (uploadTask, progress) => {
                    item.progress = progress;
                    item.uploadTask = uploadTask;
                    this.setState({ updated: !this.state.updated });
                }).then(async (result) => {
                    console.log('completed');
                    item.downloadUrl = result.url;
                    resolve()
                }).catch(err => {
                    console.log('error', err);
                    item.err = err;
                    item.progress = -1;
                    this.setState({ updated: !this.state.updated });
                    resolve()
                });
            }));   
        })
        this.props.isLoadingFunction(true);
        Promise.all(uploaderHandler).then(_ => { 
            var temp = []
            this.state.photo_arr.forEach(item => {
                temp.push(item.downloadUrl)
            });
            
            obj.data_arr = temp;
            this.setState({photo_arr : []})
            
            this._postService.addPostData(obj).then((result) => {
                this.sendNotification(obj)
                this.resetAll();
                this.props.navigation.navigate('MyInfoScreen')  
                this.props.isLoadingFunction(false);
            }).catch((error) => {
                this.props.isLoadingFunction(false);
            })
        })
    }

    onClickedAddPost = () => {
        if (this.state.group_id != '') { //add post 
            this.addGroupPost()
        } else {
            this.addPost()
        }
    }

    sendNotification(obj) {
        this.state.join_arr.forEach(user => {
            var noti_data = {
                type : 1, //post notification 
                is_read : 0,
                recv_uid : user,
                send_uid : obj.uid,
                content : "invite post",
                id : '',
                isAccepted : -1,
                post_id : postId,
                isNotification : 0,
                time : new Date().getTime()
            }    
            this._notificationService.addNotification(noti_data).then((result) => {
                  console.log('res')
            }).catch((error) => {
                console.log(error)
            })
        });
        
    }
    resetAll =()=> {
        this.setState({title : ''});
        this.setState({description : ''});
        this.setState({friend_arr : []});
        this.setState({data_arr : []});
        this.setState({updated : false})
        this.setState({address : ''})
    }
    makeAddressInfo () {
        var photo_arr = [];
        var address_location = this.state.address.geometry.location;
        var address_name  = this.state.address.name;

        var country_name = ''
        var city_name = '';

        this.state.address.address_components.forEach(element => {
            if (element.types[0] == "country") {
                country_name = element.short_name;
            } else if (element.types[0] == "administrative_area_level_1") {//this is condition when i get city infomation
                city_name = element.short_name;
            }
        });

        var city_address = {
            country_name : country_name,
            city_name : city_name
        }
        try {
            if (this.state.address.photos.length > 0) {
                this.state.address.photos.forEach(photo => {
                    var photo_url = "https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=" + photo.photo_reference + "&key=" + Google_API_KEY;
                    photo_arr.push(photo_url);
                });
            }
    
        }catch(ex) {
            photo_arr = [];
        }
        
        var plan_address = {
            name : address_name,
            location : address_location,
            city_name : city_address,
            photo_arr : photo_arr
        }
        return plan_address;
    }

    addFriend = () => {
        this.props.navigation.navigate('MyFriendSearch',{onGoBack: this.setFriendFunc})
    }   
    setFriendFunc=(user_info)=> {
        var temp = this.state.friend_arr;
        var flag = false;
        for (var i = 0; i < temp.length ;i++) {
            if (temp[i].uid == user_info.uid) {
                flag = true;
                break;
            }
        }
        if (!flag) {
            temp.push(user_info);
            this.setState({friend_arr : temp})
        }
    }
    selectedCamera =()=> {
        ImagePicker.openCamera({
            width: 300,
            height: 400,
            cropping: true,
        }).then(response => {
            this.setState({imgData : response})
            let source = {uri: response.path}
            var arr = []
            arr = this.state.photo_arr
            arr.push(response)
            this.setState({photo_arr : arr})
        }).catch((error) => {
            console.log(error)
        });
    }
    selectedGallery = () => {
        ImagePicker.openPicker({
            width: 300,
            height: 400,
            cropping: true,
        }).then(response => {
            this.setState({imgData : response})
            let source = {uri: response.path};
            
            var arr = [];
            arr = this.state.photo_arr;
            arr.push(response)
            this.setState({photo_arr : arr})
        }).catch((error) => {
            console.log(error)
        });
    } 
    addBtn = () => {
        Alert.alert(  
                '',  
                'Select your photo',  
                [  
                    {text: 'Cancel', onPress: () => console.log('Ask me later pressed')},  
                    {text: 'Camera',onPress: () => this.selectedCamera()},  
                    {text: 'Gallery', onPress: () => this.selectedGallery()},  
                ],  
                {cancelable: false}  
            )  
    }
    selectedPrivacy =(value) => { //gender select
        this.setState({privacy : value})
    }
    closeBtn = (index) => {
        var temp = [];
        this.state.photo_arr.forEach((item, idx) => {
            if (idx != index) {
                temp.push(item);
            }
        });
        this.setState({photo_arr: temp});
    }
    render() {
        var temp_arr = [];
        if (this.state.photo_arr.length > 0) {
            this.state.photo_arr.map((item, index) => {
                temp_arr.push(
                    <View key={index}>
                        <View style={[styles.photos, {borderWidth : 1, marginTop : 10}]} >
                            <View style={{flexDirection : 'column'}}>
                                <Image source = {{uri: item.path}} style={styles.exist_img}/>
                            </View>
                        </View>
                        <TouchableOpacity onPress={() => this.closeBtn(index)} style={{position : 'absolute', top : 0, right : 0}}>
                            <Image source={require('../../../../../assets/img/icon/close.png')} style={styles.close_btn}></Image>
                        </TouchableOpacity>
                    </View>
                    
                );
            })
        }
        return (
            <View style={{width : '100%', flex : 90}}>
                <KeyboardAwareScrollView
                    resetScrollToCoords={{ x: 0, y: 0 }}
                    contentContainerStyle={{flex : 1}}
                    scrollEnabled={false}
                >
                    <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
                        <View style={{flex : 100, flexDirection : 'column'}}>
                            <ScrollView style= {{width : '100%' , marginBottom : 10 * metrics}}>
                                <View style={styles.body}>
                                    <View style={styles.edit_body}>
                                        <View style={styles.f_item}>
                                            <Text style={styles.title}>Title</Text>
                                            <TextInput
                                                underlineColorAndroid = "transparent"
                                                placeholder = ""
                                                placeholderTextColor = "gray"
                                                autoCapitalize = "none"
                                                value={this.state.title}
                                                onChangeText={(text) => this.setState({title : text})}
                                                style={global_style.text_input}/>
                                        </View>
                                        <Text style={(this.state.btn_flag && this.state.title == '') ? styles.error : styles.non_error}> Title is required.</Text>

                                        <View style={styles.item}>
                                            <Text style={styles.title}>Destination</Text>
                                            <GooglePlacesAutocomplete
                                                query={{ key: Google_API_KEY }}
                                                placeholder='Enter Location'
                                                minLength={2}
                                                autoFocus={false}
                                                returnKeyType={'default'}
                                                listViewDisplayed='false'
                                                fetchDetails={true}
                                                getDefaultValue={() => ''}
                                                onPress={(data, details = null) => { // 'details' is provided when fetchDetails = true
                                                    this.setState({address : details})
                                                }}
                                                styles={{
                                                    textInputContainer: {
                                                        backgroundColor: 'rgba(0,0,0,0)',
                                                        borderBottomWidth : 1,
                                                        borderTopWidth: 0,
                                                    },
                                                    textInput: {
                                                        marginLeft: 0,
                                                        marginRight: 0,
                                                        height: 35,
                                                        color: '#5d5d5d',
                                                        fontSize: 16
                                                    },
                                                    predefinedPlacesDescription: {
                                                        color: '#1faadb'
                                                    },
                                                }}
                                                value = {this.state.address}
                                                currentLocation={false}
                                            />
                                        </View>

                                        <Text style={(this.state.btn_flag && this.state.address == '') ? styles.error : styles.non_error}> Destination is required.</Text>

                                        {
                                            this.state.group_id != '' ? null : 
                                            <View style={[styles.item,{borderBottomWidth : 1, borderBottomColor : '#d8d8d8'}]}>
                                                <Text style={styles.title}>Privacy(premium Members)</Text>
                                                <View style={{ marginTop : 10 , marginBottom : 10}}>
                                                    {
                                                        Platform.OS == 'android' && 
                                                        <Picker selectedValue = {this.state.privacy} onValueChange = {this.selectedPrivacy} style={styles.privacy}>
                                                            <Picker.Item label = "Public" value = '0'style ={{width : '100%'}}/>
                                                            <Picker.Item label = "Private" value = '1' style ={{width : '100%'}}/>
                                                        </Picker>
                                                    }
                                                    {
                                                        Platform.OS == 'ios' && 
                                                        <RNPickerSelect
                                                            placeholder ="Select Gender"
                                                            onValueChange={(value) => this.selectedPrivacy(value)}
                                                            items={[
                                                                { label: 'Public', value: '0' },
                                                                { label: 'Private', value: '1' },
                                                            ]}
                                                        />
                                                    }
                                                    
                                                </View>
                                            </View>
                                        }
                                        <View style={styles.item}>
                                            <Text style={styles.title}>Description</Text>
                                            
                                            <Textarea
                                                containerStyle={styles.textareaContainer}
                                                style={global_style.textarea}
                                                defaultValue={this.state.text}
                                                placeholder={''}
                                                value= {this.state.description}
                                                placeholderTextColor={'#c7c7c7'}
                                                underlineColorAndroid={'transparent'}
                                                onChangeText={(text) => this.setState({description : text})}
                                            />
                                        </View>

                                        <View style={styles.item}>
                                            {
                                                this.state.group_id != '' || this.state.privacy == '0' ? null :
                                                <View>
                                                    <Text style={styles.title}>Tag Friends</Text>
                                                    <View style={styles.user}>
                                                        <TouchableOpacity style={styles.new_friend} onPress={()=> this.addFriend()}>
                                                            <Image source = {require('../../../../../assets/img/icon/plus_btn.png')} style={styles.plus_btn}/>
                                                        </TouchableOpacity>
                                                        {
                                                            this.state.friend_arr.map((user, index) => {
                                                                return (
                                                                    user.img_url == '' ? 
                                                                    <View style={[styles.profile, {backgroundColor : 'whitesmoke', borderRadius : 40}]}  key={index}></View>
                                                                    :
                                                                    <Avatar
                                                                        size="medium"
                                                                        rounded
                                                                        source={{uri : user.img_url}}
                                                                        resizeMode={'stretch'}
                                                                        style={styles.profile}
                                                                        key={index}
                                                                    />
                                                                )
                                                            })
                                                        }
                                                    </View> 
                                                </View>
                                            }
                                        </View>

                                        <View style={[styles.item, {height : 180 * metrics}]}>
                                            <Text style={styles.title}>Photos/Videos</Text>
                                            <ScrollView style={styles.photo_body} horizontal={true} showsHorizontalScrollIndicator={true} bounces={true}>
                                                <View style={styles.photos}>
                                                    <View style={{flexDirection : 'column'}}>
                                                        <View style={{flexDirection : 'column'}}>
                                                            <Image source = {require('../../../../../assets/img/icon/icon_newimg.png')} style={styles.new_img}/>
                                                            <Text style={{textAlign : "center" , color : 'gray'}}>Add Picture</Text>
                                                        </View>
                                                    </View>
                                                    
                                                </View>
                                                <TouchableOpacity onPress={() => this.addBtn()} style={{position : 'relative',right : 22 * metrics}}>
                                                    <Image source={require('../../../../../assets/img/icon/btn_new.png')} style={styles.new_btn}></Image>
                                                </TouchableOpacity>
                                                { temp_arr }
                                            </ScrollView> 
                                        </View>
                                    </View>
                                </View>
                            </ScrollView>
                            <View style={global_style.bottom}> 
                                <View style={{flex :2.5}}></View>
                                <TouchableOpacity onPress={() => this.onClickedAddPost()} style={global_style.cyan_btn}>
                                    <Text style={global_style.label}>Save</Text>
                                </TouchableOpacity>
                                <View style={{flex :2.5}}></View>
                            </View>
                        </View>
                    </TouchableWithoutFeedback>
                
                </KeyboardAwareScrollView>
            </View>
            
       )
    }
}
const styles = StyleSheet.create({
    body : {
        width : '95%',
        alignSelf : 'center',
        marginTop: 15 * metrics,
        marginBottom : 60 * metrics,
        borderRadius : 10,
        shadowOffset : {width: 0, height: 4}, 
        shadowOpacity : Platform.OS == 'ios' ? 0.2 : 0.8,
        backgroundColor : 'white',
        elevation : Platform.OS == 'android' ? 10 :  1.0, 
    },
    edit_body: {
        width: '100%',
        overflow : 'hidden',
        borderRadius: 15,
        paddingLeft : 20 * metrics,
        paddingRight : 20 * metrics,
    },
    f_item: {
        margin: 15 * metrics,
        marginBottom : 3 * metrics,
        flexDirection : 'column',
        marginTop: 40 * metrics
    },
    item : {
        margin: 15 * metrics,
        marginBottom : 3 * metrics,
        flexDirection : 'column'
    },
    user : {
        paddingTop : 10 * metrics,
        flexDirection : 'row',
    },
    photo_body : {
        height : '100%',
        marginTop : 10 * metrics,
        flexDirection : 'row',
    },
    new_friend : {
        backgroundColor : '#b9b9b9',
        width : 45 * metrics,
        height: 45 * metrics,
        alignItems : 'center',
        justifyContent: 'center',
        borderRadius : 45/2,
        borderWidth : 1,
        borderColor : '#b9b9b9',
        marginTop: 3 * metrics,
        margin:5 * metrics
    },
    plus_btn: {
        width : 25 * metrics,
        height: 25 * metrics,
        alignSelf : 'center',
    },
    profile: {
        width : 45 * metrics,
        height: 45 * metrics,
        marginTop: 3 * metrics,
        margin:5 * metrics
    },
    input : {
        borderRadius : 8 * metrics,
        backgroundColor : 'whitesmoke',
        padding: 5 * metrics,
        marginTop : 5 * metrics
    },
    new_img : {
        width : 65 * metrics,
        height : 50 * metrics,
        alignSelf : 'center',
        marginTop : 35 * metrics
    },
    exist_img : {
        width : '100%',
        height : '100%',
        borderRadius : 10,
    },
    photos : {
        width : 150 * metrics,
        height : 130 * metrics,
        marginRight : 10 * metrics,
        borderColor : '#e8dddd',
        borderWidth : 1,
        borderRadius : 10,
        alignSelf : 'center'
    },
    new_btn : {
        width : 25 * metrics,
        height : 25 * metrics
    },
    close_btn : {
        width : 25 * metrics,
        height : 25 * metrics
    },
    privacy : {
        borderWidth : 0,
        borderColor : 'white',
        height :60 * metrics,
        marginTop : 10 * metrics,
        width : '100%',
        borderBottomColor : '#d8d5d5',
        borderBottomWidth : 1,
    },
    title : {
        color :'gray',
    },
    error : {
      color : 'red',
      fontSize : 13 * metrics,
      marginLeft : 10 * metrics
    }, 
    non_error : {
        display : 'none'
    },

    last_flex : {
        flex : 18 , 
        elevation : 1.0 , 
        shadowOpacity :0.2 , 
        shadowOffset : {width : 0, height : -2 }
    },
    bottom: {
        width: '100%',
        height : '100%',
        backgroundColor : 'white',
        elevation : 4.5,
    },
    cyan_btn : {
        width: '55%',
        height: 45 * metrics,
        borderRadius: 40,
        alignItems: 'center',
        alignSelf :'center',
        top : 8 * metrics,
        backgroundColor: '#4f80ff',
        shadowRadius: 7,  
        elevation : 3.5
    },
    label : {
        height: '100%',
        alignItems: 'center',
        fontSize: 18 * metrics,
        color: 'white',
        marginTop: 10 * metrics,
    },
});

AddPost.propType = {
    isLoadingFunction : PropTypes.func,
}
export default AddPost
