import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet, TouchableOpacity,ScrollView, TextInput} from 'react-native';
import global_style , {metrics}from '../../../../constants/globalStyles';
import FriendService from '../../../../services/friend.service';
import UserService from '../../../../services/user.service';
import { inject, observer } from 'mobx-react';
import { Avatar} from 'react-native-elements';

let _this = null;

@inject ('friendService')
@inject ('userService')
@observer

class MyFriendSearch extends Component {

    _friendService : FriendService = this.props.friendService
    _userService : UserService = this.props.userService
    constructor (props) {
        super(props)
        this.state = {
            search_text : '',
            friends_arr : []
        }
    }

    componentWillUnmount() {
        this.unsubscribeFriend()
    }
    componentWillMount() {
        _this = this
        this.unsubscribeFriend = this._friendService.getFriendData(global.user_info.uid).onSnapshot(function(result) {
            const data = result.docs.map(doc => doc.data());
            var count = 0;
            if (data.length == 0) {
                _this.setState({friends_arr : []})
            } else {
                if (data[0].friends_arr.length > 0) {
                    data[0].friends_arr.forEach(element => {
                        _this._userService.getUserData(element.uid).then((result) => {
                            if (result.exists) {
                                element.uid = result.data()
                            }
                            count++;
                            if (count == data[0].friends_arr.length) {
                                _this.setState({friends_arr : data[0].friends_arr})
                            }
                        })
                    });
                } else {
                    _this.setState({friends_arr : []})
                }
            }
        })
        this.props.navigation.setParams({ search_text: ''})
        this.props.navigation.setParams({ searchFriend : this.onSearchFriendClicked})
    }
    changeText = () => {

    }
    onClickedFriends = (user) => {
        this.props.navigation.state.params.onGoBack(user.uid);
        this.props.navigation.goBack();
          
    }
    onSearchFriendClicked = () => {
        var text = this.props.navigation.getParam('search_text');
        if (text == '') return
        
        this.props.navigation.setParams({search_text: text})
    }
    static navigationOptions = ({ navigation }) => { 
        const { params = {} } = navigation.state; 
        return {
            headerLeft: (
                <View style={global_style.navigation}>
                    <TouchableOpacity 
                        style={styles.backarrow}
                        onPress={() => navigation.goBack()} >
                            <Image source = {require('../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                            <Text style={global_style.back_title}>BACK</Text>
                    </TouchableOpacity>
                </View>
            ),
            headerStyle: global_style.headerHeight,
        };
    }
    render() {
        return (
            <View style={{width : '100%', height : '100%'}}>
                
                <ScrollView style={{height : '100%' , width : '100%'}} ref="myDiv">
                    <View style={{marginTop : 15 * metrics}}></View>
                    {
                        this.state.friends_arr.map((item, index) => {
                            if (item.uid != global.user_info.uid)
                            {
                                return (
                                    <TouchableOpacity style={global_style.friends_tile} onPress={ () => this.onClickedFriends(item)} key={index}>
                                        <View style={styles.user_view}>
                                            {
                                                item.img_url != '' ? 
                                                    <Avatar
                                                        size="medium"
                                                        rounded
                                                        source={{uri : item.uid.img_url}}
                                                        resizeMode={'stretch'}
                                                        style={styles.profile}
                                                        />
                                                    : <View style={styles.profile}></View>    
                                            }
                                            <Text style={[styles.title, {flexDirection : 'row'}]}>
                                                <Text style={{fontSize : 17 * metrics}}>{item.uid.f_name} </Text>
                                                <Text style={{fontSize : 17  * metrics}}>{item.uid.l_name}</Text>
                                            </Text> 
                                            <Image source = {require('../../../../assets/img/icon/right_arrow.png')} style={styles.arrow_icon}/> 
                                        </View>
                                    </TouchableOpacity>
                                )
                            }
                        })
                    }
                    
                </ScrollView>
            </View>
        )
    }
}
const styles = StyleSheet.create({
    view: {
        width : '100%', 
        height : 60  * metrics,
        elevation : 0.5,
        paddingTop : 10, 
        marginBottom : 10 * metrics,
        flexDirection : 'row',
        shadowColor: "#dedede",
        shadowOffset: {width: 0,height: 4,},
        shadowOpacity: 0.30,
        shadowRadius: 4.65,
        elevation: 1,
        borderBottomWidth : 1,
        borderBottomColor : '#dedede'
    },  
    user_view: {
        flexDirection : 'row',
        height: '100%',
        width: '100%',
        alignItems : 'flex-start'
    },  
    search : {
        height: 40 * metrics,
        borderWidth : 1,
        borderColor : '#dedede',
        backgroundColor: 'whitesmoke',
        width : '80%',
        marginLeft : 10 * metrics,
        alignSelf: 'flex-start',
        borderRadius : 5,
        padding : 5,
    },
    search_btn : {
        width : 40 * metrics,
        height : 40 * metrics,
        position : 'absolute',
        right : 10,
        top : 10
    },
    title : {
        alignItems: 'flex-start',
        alignSelf : 'center',
        marginLeft: 0
    },
    location : {
        width : '100%', height : '100%',
    },
    arrow_icon : {
        width : 13 * metrics,
        height : 15 * metrics,
        resizeMode : 'stretch',
        alignSelf : 'center',
        position : 'absolute',
        right : 10
    },
    profile: {
        width : 45 * metrics,
        height: 45 * metrics,
        resizeMode : "stretch",
        // alignItems: 'flex-start',
        alignSelf : 'center',
        marginLeft: 15 * metrics,
        marginRight: 15 * metrics,
    },
    right_img: {
        alignItems: 'flex-end',
        alignSelf : 'center',
        marginRight : 10 * metrics,
        width: 100 * metrics,
        height: 22 * metrics,
        resizeMode: 'stretch',
        position : 'absolute',
        right : 5,
    }, 
    backarrow : {
        flex: 1,
        height: '100%',
        flexDirection : 'row',
        width: '100%'
    },
})
export default MyFriendSearch