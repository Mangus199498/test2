import React, { Component } from 'react';
import {  View , Text, Image,StyleSheet,TouchableOpacity,ScrollView} from 'react-native';
import global_style, {metrics}  from '../../../../../constants/globalStyles';

import GroupService from '../../../../../services/group.service';
import UserService from '../../../../../services/user.service';
import NotificationService from '../../../../../services/notification.service';
import {  Avatar} from 'react-native-elements';
import { inject, observer } from 'mobx-react';

let _this = null;

@inject ('groupService')
@inject ('userService')
@inject ('notificationService')

@observer


class GroupInfoScreen extends Component {
   _groupService : GroupService = this.props.groupService;
   _userService : UserService = this.props.userService;
   _notificationService : NotificationService = this.props.notificationService

   static navigationOptions = ({ navigation }) => {
      const { params = {} } = navigation.state;
      return {
         headerLeft: (
         <View style={global_style.navigation}>
               <TouchableOpacity 
                     style={styles.backarrow}
                     onPress={() => navigation.goBack()}>
                        <Image source = {require('../../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                        <Text style={global_style.back_title}>{params.groupName}</Text>
               </TouchableOpacity>
            </View>
         ),
         headerStyle: global_style.headerHeight,
      };
   };
   state = {
      starCount : 4,
      height : 0,
      detail_item : '',
      join_flag :false,
      user_info : null
   }
   componentWillMount () {
      
   }
   goBack = () => {
      this.props.navigation.navigate('TabsPage');
   }
   componentDidMount() {
      _this = this;
      var id = this.props.navigation.getParam('group_data').group_id
      this.setState({user_info : this.props.navigation.getParam('group_data').user_info})
      this.props.navigation.setParams({ goBack: this.goBack });
      
      this.reloadData(id)
   }

   componentWillUnmount () {
      this.unsubscribeGroup()      
   }

   async reloadData(id) {
      var temp = null;
      var _this = this;

      this.setState({join_flag : false})
      
      this.unsubscribeGroup = await this._groupService.getDataById(id).onSnapshot(function(result) {
         if (result.exists) {
            var data = result.data();
            temp = data;
            _this.props.navigation.setParams({ groupName: temp.title });
            if (temp.friends_arr != null && temp.friends_arr.length > 0) {
               var count = 0; 
               var friends = []
               temp.friends_arr.forEach(element => {
                  
                  if (element == global.user_info.uid) {
                     _this.setState({join_flag : true})
                  }
                  _this._userService.getUserData(element).then((res) => {
                     if (res.exists) {
                        var data = res.data()    
                        friends.push(data)
                     }
                     count ++;
                     if (count == temp.friends_arr.length) {
                        temp.friends_arr = friends
                        _this.setState({isLoading : false})
                        _this.setState({detail_item : temp})
                        
                        if (temp.uid == global.user_info.uid) {
                           _this.setState({join_flag : true})
                        }
                     }
                  })   
               });
            } else {
               _this.setState({join_flag : false})
               _this.setState({isLoading : false})
               _this.setState({detail_item : temp})
            }
            if (temp.join_arr != null && temp.join_arr.length > 0 && _this.state.join_flag == false) {
               for(var i =0; i < temp.join_arr.length ;i++) {
                  if (global.user_info.uid == temp.join_arr[i]) {
                     _this.setState({join_flag : true})
                     break;
                  }
               }
            }
            
         }
      })
  }
   onClickedJoin = () => { //join click
      
      this.state.detail_item.join_arr.push(global.user_info.uid)
      if (this.state.detail_item.friends_arr.length > 0) {
         var arr = [];
         for (var i =0 ;i < this.state.detail_item.friends_arr.length;i++) {
            arr.push(this.state.detail_item.friends_arr[i].uid)
         }
         this.state.detail_item.friends_arr = arr;
         console.log('1 = ' , arr)
      }
      this._groupService.updateGroup(this.state.detail_item.id, this.state.detail_item).then((result) => { //update group info
         var noti_data = {
            type : 4, // group notification  join/accept 0/1
            send_uid : global.user_info.uid,
            recv_uid : this.state.detail_item.uid,
            content : "join group",
            title : this.state.detail_item.title,
            group_id : this.state.detail_item.id,
            isAccepted : -1,
            is_read : 0,
            isNotification : 0,
            time : new Date().getTime()
         }
         this._notificationService.addNotification(noti_data).then((result) => { //add notification
            this.props.navigation.navigate('TabsPage')
         }).catch((error)=> {
            console.log(error)
         })
      })

   }
   render() {
      return (
         <View style={{height: '100%'}}>
            {
               this.state.detail_item == '' ? null :
               <ScrollView style={{width: '100%',height : '100%', backgroundColor : 'white'}} bounces = {false}>
                  <Image source = {{uri : this.state.detail_item.group_img}} style={styles.bg_img}/>
                  <View style = {styles.sub_body}>
                     <View style={styles.title}>
                        <Text style={{fontSize : 20 * metrics, fontWeight : '600', paddingLeft:5}}>Group Title</Text>
                     </View>
                     <View style={styles.title}>
                        <Text style={styles.gray_title}>{this.state.detail_item.title}</Text>
                     </View>
                     
                     <Text style={{fontSize : 18 * metrics, fontWeight : '600' , paddingLeft :5, marginTop: 20}}>Members</Text>
                     <View >
                        {
                           this.state.detail_item == ''  ? null : 
                           <View style={styles.user}>
                              <Avatar
                                 rounded
                                 size="medium"
                                 source={{uri : this.state.user_info.img_url}}
                                 resizeMode={'stretch'}
                                 style={styles.profile}
                                 />
                              {
                                 this.state.detail_item.friends_arr.map((item, index) => {
                                    return (
                                       <Avatar
                                          key ={index}
                                          rounded
                                          size="medium"
                                          source = {{uri : item.img_url}}
                                          resizeMode={'stretch'}
                                          style={styles.profile}
                                       />
                                    )
                                 })
                              }
                           </View>
                        }
                     </View>               
                     <Text style={{fontSize : 18 * metrics, fontWeight : '600' , paddingLeft :5, marginTop: 20}}>Images</Text>
                     <View style={styles.img_body}>
                        {
                           this.state.detail_item.post_arr.map((item, index) => {
                              if (item.data_arr.length > 0) {
                                 return (
                                    <Image source = {{uri : item.data_arr[0]}} style={styles.place_img}/>
                                 )
                              }
                           })  
                        }
                     </View>
                  </View>   
                  
               </ScrollView>
            }
            {
               this.state.join_flag == true ? null : 
               <View style={styles.bottom}> 
                  <View style={{flex : 2.5}}></View>
                     <TouchableOpacity onPress={() => this.onClickedJoin()} style={global_style.cyan_btn}>
                        <Text style={global_style.label}>Join Group</Text>
                     </TouchableOpacity>
                  <View style={{flex : 2.5}}></View>
               </View>
            }
         </View>
         
      )
   }
}
const styles = StyleSheet.create({
   bg_img: {
      width: '100%',
      height : 300* metrics
   }, 
   img_body : {
      width: '100%',
      paddingTop : 10* metrics,
      flexDirection: 'row',
      flexWrap : 'wrap'
   },
   backarrow : {
      flex: 1,
      flexDirection : 'row',
      width: '100%'
   },
   sub_body : {
      width:'100%',
      height: '100%',
      backgroundColor : 'white',
      borderTopLeftRadius : 25,
      borderTopRightRadius : 25,
      marginTop: -20 * metrics,
      padding: 10 * metrics,
      marginBottom : 55 * metrics
   },
   title : {
      //height : 'auto' , 
      width : '100%',
      flexDirection : 'row',
      paddingBottom: 0
   },   
   gray_title : {
      fontSize: 14 * metrics,
      marginLeft: 5 * metrics,
      marginTop : 5,
      color : 'gray'
   },
   about: {
      flexDirection : 'column'
   },
   lock_icon : {
      width: 25 * metrics,
      height: 25 * metrics,
      resizeMode: "stretch",
      marginRight : 10 * metrics,
      marginTop: 30 * metrics,
   },
   place_img : {
      borderRadius: 10 * metrics,
      width: '30%',
      height: 100 * metrics,
      resizeMode: "stretch",
      margin : 5 * metrics
   },
   about_description : {
      padding : 3 * metrics
   },
   cyan_btn : {
      width: '55%',
      height: 45 * metrics,
      borderRadius: 40 * metrics,
      alignItems: 'center',
      alignSelf : 'center',
      backgroundColor: '#4f80ff',
      elevation : 3.5,
      flex: 5,
   },
   label : {
      height: '100%',
      alignItems: 'center',
      fontSize: 20 * metrics,
      color: 'white',
      marginTop: 6 * metrics,
   },
   user : {
      paddingTop : 10 * metrics,
      flexDirection : 'row'
   },
   profile: {
      width : 50 * metrics,
      height: 50 * metrics,
      resizeMode : "stretch",
      marginTop: 3 * metrics,
      margin:5 * metrics
   },
   bottom: {
      borderTopWidth : 1,
      borderTopColor: '#f1f1f1',
      flexDirection: 'row',
      position : 'absolute',
      bottom: 0,
      flex : 10,
      width: '100%',
      height : 60 * metrics,
      backgroundColor : '#f7f7f7',
      shadowOffset : { width : 0, height : -10},
      shadowColor : '#d8d8d8',
      shadowRadius : 20,
      shadowOpacity : 0.7
   },
})
export default GroupInfoScreen