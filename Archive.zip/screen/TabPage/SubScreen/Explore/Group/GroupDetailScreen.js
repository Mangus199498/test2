import React, { Component } from 'react';
import { AppRegistry, View ,Text,TextInput, Image,StyleSheet,TouchableOpacity,ScrollView,Dimensions} from 'react-native';
import global_style , {metrics} from  '../../../../../constants/globalStyles';

import GroupService from '../../../../../services/group.service';
import UserService from '../../../../../services/user.service';
import { inject, observer } from 'mobx-react';
import { Input , Avatar} from 'react-native-elements';
import { get_before_day ,getCommentTime} from '../../../../../utils/moment';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
@inject ('groupService')
@inject ('userService')
@observer
class GroupDetailScreen extends Component {

   _groupService : GroupService = this.props.groupService
   _userService : UserService = this.props.userService

   constructor(props){
      super(props);
   
      this.state = {
         height : 0,
         group_id : '',
         post_data : [],
         plan_data : [],
         group_data : null,
         comment_arr : [],
         saving_data : null,
      }
   }
   
   componentWillUnmount() {
      this.unsubscribeGroup()
   }

   async componentWillMount () {
      var _this = this
      this.setState({group_id :this.props.navigation.getParam('group_id')})
      this.unsubscribeGroup = await this._groupService.getDataById(this.props.navigation.getParam('group_id')).onSnapshot(function(result) {
         if (result.exists) {
            var count1 = 0
            var count2 = 0
            const data = result.data()
            _this.setState({group_data : data})
            _this.props.navigation.setParams({ navTitle : data.title});
            if (data.privacy == '1') {//private
               _this.props.navigation.setParams({ sub_title : "PRIVATE GROUP"});
            } else {
               _this.props.navigation.setParams({ sub_title : "PUBLIC GROUP"});
            }
            if (data.post_arr.length > 0) {
               data.post_arr.forEach(element => {
                  _this._userService.getUserData(element.uid).then((res) => {
                     if (res.exists) {
                        const user_data = res.data()
                        element.uid = user_data
                     }
                     count1 ++
                     if (count1 == data.post_arr.length) {
                        if (data.plan_arr.length > 0) {
                           data.plan_arr.forEach(element => {
                              _this._userService.getUserData(element.uid).then((res) => {
                                 if (res.exists) {
                                    const user_data = res.data()
                                    element.uid = user_data
                                 }
                                 count2 ++
                                 if (count2 == data.plan_arr.length) {
                                    _this.setState({post_data : data.post_arr})
                                    _this.setState({plan_data : data.plan_arr})
                                 }
                              }).catch((error) => {
                                 console.log(error)
                              })
                           })
                        } else {
                           console.log('update')
                           _this.setState({post_data : data.post_arr})
                           _this.setState({plan_data : []})
                        }
                     } else {
                        _this.setState({post_data : []})
                        _this.setState({plan_data : []})
                     }
                  }).catch((error) => {
                     console.log(error)
                  })
               });
            }
         }
      })
      this.props.navigation.setParams({ detail: this.onClickedGroupDetail });
   }
   static navigationOptions = ({ navigation }) => {
      const { params = {} } = navigation.state;
      return {
          headerLeft: (
              <View style={global_style.navigation}>
                  <TouchableOpacity 
                      style={styles.backarrow}
                      onPress={() => navigation.goBack()} >
                          <Image source = {require('../../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                          <View style={{flexDirection : 'column', marginTop : 20, marginLeft : 15}}>
                              <Text style={{fontSize :18 * metrics, fontWeight : '400'}}>{params.navTitle}</Text>
                              <Text style={{fontSize : 13 * metrics, color : 'gray'}}>{params.sub_title}</Text>
                          </View>
                          
                  </TouchableOpacity>
              </View>
          ),
          headerStyle: global_style.headerHeight,
          headerRight : (
            <TouchableOpacity 
               style ={styles.backarrow}
               onPress = {navigation.getParam('detail')} >
                  <Image source = {require('../../../../../assets/img/icon/ico_info.png')} style={styles.lock_icon}/>
            </TouchableOpacity>
          )
      };
   };

   
   onClickedGroupDetail = () => {
      this._userService.getUserData(this.state.group_data.uid).then((result) => {
         if (result.exists) {
            var group_data = {
               group_id : this.state.group_data.id,
               user_info : result.data()
            }
            this.props.navigation.navigate('GroupInfoScreen', {group_data : group_data});
         }
      })
   }
   onClickedAddPost = () => {
      this.props.navigation.navigate('AddPostScreen',{group_id:this.state.group_id})
   }
   setPostFunc=(user_info)=> {

   }
   handleText = (index, text) => {
      var arr = this.state.comment_arr
      arr[index] = text
      this.setState({comment_arr : arr})
   }
   writeComment = (item,index) => {
      if (this.state.comment_arr[index] == '' || this.state.comment_arr[index] == null)
         return;
      var strs = this.state.comment_arr[index]

      var comment_obj = {
         date: new Date().getTime(),
         text : strs,
         uid : global.user_info
      }
      
      for (var i = 0 ; i < this.state.group_data.post_arr.length; i++) {
         this.state.group_data.post_arr[i].uid  =   this.state.group_data.post_arr[i].uid.uid
      }
      this.state.group_data.post_arr[index].comment.push(comment_obj)
      this._groupService.updateGroup(this.state.group_data.id , this.state.group_data).then((result) => {
         console.log(result)
      }).catch((error) => {
         console.log(error)
      })

      //init text
      this.state.comment_arr[index] = '';
      this.setState({comment_arr : this.state.comment_arr})
   }
   render() {
      return (
         <View style={{width: '100%', height : '100%'}}>
            <KeyboardAwareScrollView
               resetScrollToCoords={{ x: 0, y: 0 }}
               contentContainerStyle={{flex : 1}}
               scrollEnabled={false}
            >
            <ScrollView style={{backgroundColor :'#ececec'}}>
               <View style={styles.body}>
                  {
                     this.state.post_data.map((item, index) => {
                        console.log(item.uid)
                        return (
                           <View style={styles.item} key={index}>
                              <View style={styles.top_body}>
                                 <Avatar
                                    size="medium"
                                    rounded
                                    source={{uri : item.uid.img_url}}
                                    resizeMode={'stretch'}
                                    style={styles.profile}
                                    key={index}
                                 />
                                 <View style={{flexDirection : 'column',alignItems: 'flex-start', marginRight:0, marginLeft : 6  * metrics}}>
                                    <Text style={{fontSize : 15 * metrics}}>{item.uid.f_name} {item.uid.l_name}</Text>
                                    <View style={{flexDirection : 'row', marginTop : 5 * metrics }}>
                                       <Image source = {require('../../../../../assets/img/icon/clock.png')} style={styles.time_icon}></Image> 
                                       {
                                          get_before_day(item.time) == 0 ? 
                                          <Text> Just ago </Text>
                                          :<Text style={{fontSize: 12 * metrics, marginLeft: 5 * metrics , color : 'gray' ,marginTop : 3 * metrics}}>{get_before_day(item.time)} days ago</Text>
                                       }
                                       
                                    </View>
                                 </View>
                              </View>
                              <View style={styles.post_body}>
                                 {
                                    item.data_arr.length == 0 ? null : 
                                    <Image source = {{uri : item.data_arr[0]}} style={styles.post_img}/>
                                 }
                                 <Text style={styles.description}>
                                    {item.description}
                                 </Text>
                                 <View style={styles.icon_body}>
                                    <Image source = {require('../../../../../assets/img/icon/ico_like.png')} style={styles.icon_like}></Image>
                                    <Text> {item.favorite == undefined ? 0 : item.favorite.length}</Text>
                                    <Text>          </Text>
                                    <Image source = {require('../../../../../assets/img/icon/ico-inbox.png')} style={styles.icon_inbox}></Image>
                                    <Text> {item.comment.length}</Text>
                                 </View>
                                 <View style={styles.line}></View>
                                 <View style={styles.comment_body}>
                                    {
                                       item.comment == null ? null :
                                       item.comment.map((item, index) => {
                                          return (
                                             <View style={styles.user} key={index}>
                                                <Avatar
                                                      rounded
                                                      overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                                                      size="xlarge"
                                                      source={{uri : item.uid.img_url}}
                                                      resizeMode={'stretch'}
                                                      containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                                                      style = {styles.user_profile}
                                                      />
                                                <View style={styles.name}>
                                                      <Text style={{fontSize: 16 * metrics, fontWeight: '600'}}>{item.uid.f_name} {item.uid.l_name}</Text>
                                                      <Text style={{fontSize: 12 * metrics, width : 200 * metrics, backgroundColor: 'white',flexShrink: 1}}>{item.text}</Text>
                                                </View>
                                                <Text style={styles.time}>{getCommentTime(item.date)}</Text>
                                             </View>
                                          )
                                       })
                                    }
                                 </View>
                                 {
                                    global.user_info.uid == item.uid.uid ? null :
                                    <View style={styles.comment}>
                                       <TextInput
                                          underlineColorAndroid = "transparent"
                                          placeholder = "Write Comment"
                                          placeholderTextColor = "gray"
                                          autoCapitalize = "none"
                                          style={global_style.comment_style}
                                          value={this.state.comment_arr[index]}
                                          onChangeText = {(text)=> this.handleText(index,text)}/>
                                          <TouchableOpacity onPress={()=> this.writeComment(item,index)} style={{flex : 10 , alignSelf : 'center'}}>
                                             <Image source={require('../../../../../assets/img/icon/ico_next.png')} style={{width: 38 * metrics, height: 38 * metrics, resizeMode : 'stretch',alignSelf : 'center'}}></Image>
                                          </TouchableOpacity>
                                    </View>
                                 }
                              </View>
                           </View>
                        )
                     })
                  }
               </View>
            </ScrollView>
            
            <View style={global_style.bottom}>
               <View style={{flex: 2.5}}></View>
               <TouchableOpacity onPress={() => this.onClickedAddPost()} style={global_style.cyan_btn}>
                  <Text style={global_style.label}>New Post</Text>
               </TouchableOpacity>
               <View style={{flex: 2.5}}></View>
            </View>
            </KeyboardAwareScrollView>
        </View>
      )
   }
}
const styles = StyleSheet.create({
   backarrow : {
      flex: 1,
      flexDirection : 'row',
      width: '100%'
   },
   body : {
      width : '100%',
      marginBottom:70 * metrics,
   },
   item : {
      width : '95%',
      alignSelf : 'center',
      marginTop : 15 * metrics,
      flexDirection : 'column',
      backgroundColor : 'white',
      borderRadius : 10,
      elevation : 3.5,
      shadowOffset : {width : 0 , height : 4},
      shadowOpacity: 0.4
   },
   top_body : {
      alignSelf : 'flex-start',
      flexDirection : 'row', 
      marginTop : 5 * metrics,
      marginBottom : 10 * metrics,
      //marginLeft : 5
   },
   post_body : {
      flexDirection : 'column',
      marginBottom : 10 * metrics
   },
   post_img : {
      width : '95%',
      alignItems: 'center',
      alignSelf : 'center',
      height : 210 * metrics,
      borderRadius : 10 * metrics
   },
   lock_icon : {
      width: 25 * metrics,
      height: 25 * metrics,
      resizeMode: "stretch",
      marginRight : 10 * metrics,
      marginTop: 15 * metrics,
   },
   place_img : {
      borderRadius :10 * metrics,
      width: '30%',
      height: 100 * metrics,
      resizeMode: "stretch",
      margin : 5 * metrics
   },
   description : {
      margin : 10 * metrics
   },
   time_icon : {
      width: 15 * metrics,
      height : 15 * metrics,
      marginTop : 3 * metrics,
      marginRight : 5 * metrics,
      alignSelf : 'center',
      resizeMode: 'stretch',
   },
   user : {
        minHeight: 60 * metrics,
        width: '100%',
        marginTop : 10 * metrics,
        flexDirection: 'row',
        borderBottomWidth: 1,
        borderBottomColor : '#ececec'
   },
   profile : {
        width : 40 * metrics,
        height: 40 * metrics,
        resizeMode : 'stretch',
        alignSelf : 'center',
        marginRight : 10 * metrics,
        marginLeft : 10 * metrics,
    },
    name: {
        flexDirection : 'column',
        alignItems: 'flex-start',
        alignSelf : 'flex-start',
        marginLeft : 0,
        marginBottom : 15 * metrics,
    },
   icon_like : {
      width: 20 * metrics,
      height: 20 * metrics,
      resizeMode : "stretch"
   },
   line : {
        borderBottomWidth : 1, 
        borderBottomColor : '#ececec', 
        paddingTop : 7 * metrics
   },
   icon_inbox : {
      width: 20 * metrics,
      height: 20 * metrics,
      resizeMode : "stretch"
   },
   icon_body : {
      marginTop: 5 * metrics,
      paddingLeft: 10 * metrics,
      width: '100%',
      flexDirection: 'row',
   },
   comment : {
      flex : 100,
      flexDirection : 'row',
      paddingRight : 10 * metrics,
      marginTop : 5
   },
   comment_body : {
      marginLeft : 0,
   },
   // user : {
   //    minHeight: 80 * metrics,
   //    width: '100%',
   //    marginTop : 10 * metrics,
   //    flexDirection: 'row',
   //    borderBottomWidth: 1,
   //    borderBottomColor : '#ececec'
   // },
   user_profile : {
         width : 40 * metrics,
         height: 40 * metrics,
         resizeMode : 'stretch',
         alignSelf : 'flex-start',
         marginRight : 10 * metrics,
         marginLeft : 10 * metrics
   },
   time : {
        fontSize : 11 * metrics,
        color: '#b1b1b1',
        position : 'absolute',
        right : 5,
        top : 0,
        alignSelf : 'center',
    },
})
export default GroupDetailScreen