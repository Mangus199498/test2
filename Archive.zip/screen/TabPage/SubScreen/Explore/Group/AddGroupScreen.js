import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,TextInput,ScrollView,Picker,Alert,Dimensions, Platform} from 'react-native';
import global_style , {metrics} from '../../../../../constants/globalStyles';
import UserService from '../../../../../services/user.service';
import GroupService from '../../../../../services/group.service';
import RNPickerSelect from 'react-native-picker-select';
import StorageService from '../../../../../services/storage.service';
import NotificationService from '../../../../../services/notification.service';
import Textarea from 'react-native-textarea';
import ImagePicker from 'react-native-image-crop-picker';
import { inject, observer } from 'mobx-react';
import { Input , Avatar} from 'react-native-elements';

import { groupId } from '../../../../../utils/utils';
import LoadingBar from '../../../../../components/LoadingBar';

import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

@inject ('userService')
@inject ('groupService')
@inject ('storageService')
@inject ('notificationService')
@observer

class AddGroupScreen extends Component 
{
    _userService : UserService = this.props.userService
    _groupService : GroupService = this.props.groupService
    _notificationService : NotificationService = this.props.notificationService
    _storageService : StorageService = this.props.storageService

    static navigationOptions = ({ navigation }) => {
        return {
            headerLeft: (
                    <View style={global_style.navigation}>
                    <TouchableOpacity 
                        style={styles.backarrow}
                        onPress={() => navigation.goBack()} >
                            <Image source = {require('../../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                            <Text style={global_style.back_title}>NEW GROUP</Text>
                    </TouchableOpacity>
                    </View>
            ),
            headerStyle: global_style.headerHeight
        };
    };
    state = {
        height : 0,
        title : '',
        privacy : '1',
        description : '',
        friends_arr : [],
        imgData : '',
        group_img : '',
        isLoading : false,
        btn_flag : false
    }
    componentWillMount () {
        this.setState({isLoading : false})
    }
    selectedPrivacy =(value) => { //gender select
        this.setState({privacy : value})
    }
    addFriend = () => {
        this.props.navigation.navigate('MyFriendSearch',{onGoBack: this.setFriendFunc})
    }
    setFriendFunc=(user_info)=> {
        var temp = [] 
        temp = this.state.friends_arr
        var flag = false;
        for (var i = 0; i < temp.length ;i++) {
            if (temp[i].uid == user_info.uid) {
                flag = true;
                break;
            }
        }
        if (!flag) {
            temp.push(user_info);
           this.setState({friends_arr : temp})
        }
    }
    selectedCamera =()=> {
        ImagePicker.openCamera({
            width: 300,
            height: 400,
            cropping: true,
        }).then(response => {
            this.setState({imgData : response})
            let source = {uri: response.path};
            this.setState({
                group_img: source,
            });
        }).catch((error) => {
            console.log(error)
        });
    }
    selectedGallery = () => {
        ImagePicker.openPicker({
            width: 300,
            height: 400,
            cropping: true,
        }).then(response => {
            this.setState({imgData : response})
            let source = {uri: response.path}
            this.setState({
                group_img: source,
            });
        }).catch((error) => {
            console.log(error)
        });
    } 

    validation() {
        if (this.state.title == '' || this.state.privacy == '') {
            return false;
        } else {
            return true;
        }
    }

    addGroupImage = () => {
        Alert.alert(  
                'Avatar',  
                'Select your photo',  
                [  
                    {text: 'Cancel', onPress: () => console.log('Ask me later pressed')},  
                    {text: 'Camera',onPress: () => this.selectedCamera()},  
                    {text: 'Gallery', onPress: () => this.selectedGallery()},  
                ],  
                {cancelable: false}  
            )  
    }
    createGroup = () => {
        this.setState({btn_flag : true})
        if (!this.validation())
            return;
        if (this.state.imgData == '') {
            Alert.alert(  
                '',  
                'Select group photo.',  
                [  
                    {text: 'OK', onPress: () => console.log('Ask me later pressed')},  
                ],  
                {cancelable: false}  
            ) 
            return;
        }
        if (this.state.friends_arr.length == 0 && this.state.privacy == '1') {
            Alert.alert(  
                '',  
                'Select your friends.',  
                [  
                    {text: 'OK', onPress: () => console.log('Ask me later pressed')},  
                ],  
                {cancelable: false}  
            ) 
            return;
        }
        var temp = [];
        var user_id = global.user_info.uid;
        if (this.state.friends_arr.length > 0) {
            for (var i = 0; i < this.state.friends_arr.length ; i++) {
                temp.push(this.state.friends_arr[i].uid)
            }
        }
        var friends_arr = []; 
        var group_info = {
            uid : user_id,
            title : this.state.title,
            description : this.state.description,
            friends_arr : friends_arr,
            plan_arr : [],
            post_arr : [],
            join_arr : temp,
            privacy : this.state.privacy,
            group_img : '',
            time : new Date().getTime()
        }
        this.setState({isLoading : true})
        this._storageService.uploadImage(global.user_info.uid ,this.state.imgData).then((result) => {
            group_info.group_img = result.url;
            this._groupService.addGroup(group_info).then((result) => {
                if (temp.length > 0) {
                    var count = 0;
                    temp.forEach((item, index) => {
                        var noti_data = {
                            type : 0, // group notification
                            send_uid : user_id,
                            recv_uid : item,
                            content : 'invite group',
                            group_id : groupId,
                            isAccepted : -1,
                            is_read : 0,
                            isNotification : 0,
                            time : new Date().getTime()
                        }
                        this._notificationService.addNotification(noti_data).then((result) => {
                            count ++;
                            if (count == temp.length) {
                                this.setState({isLoading : false})
                                this.props.navigation.navigate('MyInfoScreen');
                            }
                        }).catch((error)=> {
                            this.setState({isLoading : false})
                            console.log(error)
                        })
                    })
                    
                } else {
                    this.setState({isLoading : false})
                    this.props.navigation.navigate('MyInfoScreen');
                }
            }).catch((error) => {
                this.setState({isLoading : false})
                console.log(error)
            })
        }).catch((error) => {
            this.setState({isLoading : false})
            console.log(error)
        })
    } 
    render() {
        return (
            <View style={{backgroundColor : '#f1f6f9' , width : '100%' , height : '100%'}}>
                <KeyboardAwareScrollView
                    resetScrollToCoords={{ x: 0, y: 0 }}
                    contentContainerStyle={{flex : 1}}
                    scrollEnabled={false}
                >

                <ScrollView style={{width: '100%'}}>
                    <View style={styles.body}>
                        <View style={styles.edit_body}>
                            <TouchableOpacity style={styles.photos} onPress={() => this.addGroupImage()} >
                                {
                                    this.state.imgData == '' ? 
                                    <View style={{flexDirection : 'column'}}>
                                        <Image source = {require('../../../../../assets/img/icon/icon_newimg.png')} style={styles.new_img}/>
                                        <Text style={{textAlign : "center" , color : 'gray'}}>Upload image</Text>
                                    </View>
                                    : <Image source = {this.state.group_img} style={{width : '100%', height : '100%' , borderRadius : 10}}/>
                                }
                                
                            </TouchableOpacity>
                            <View style={styles.f_item}>
                                <Text style={{color : 'gray'}}>Title</Text>
                                <TextInput
                                    underlineColorAndroid = "transparent"
                                    placeholder = ""
                                    placeholderTextColor = "gray"
                                    autoCapitalize = "none"
                                    value={this.state.title}
                                    onChangeText={(text) => this.setState({title : text})}
                                    style={global_style.text_input}/>
                            </View>
                            <Text style={(this.state.btn_flag && this.state.title == '') ? styles.error : styles.non_error}> Title is required.</Text>

                            <View style={[styles.item,{borderBottomWidth : 1, borderBottomColor : '#d8d8d8'}]}>
                                <Text style={{color : 'gray' ,marginLeft : 2}}>Privacy(premium Members)</Text>
                                <View style={{ marginTop : 10 , marginBottom : 10}}>
                                    {
                                        Platform.OS == 'android' && 
                                        <Picker selectedValue = {this.state.privacy} onValueChange = {this.selectedPrivacy} style={styles.privacy}>
                                            <Picker.Item label = "Public" value = '0'style ={{width : '100%'}}/>
                                            <Picker.Item label = "Private" value = '1' style ={{width : '100%'}}/>
                                        </Picker>
                                    }
                                    {
                                        Platform.OS == 'ios' && 
                                        <RNPickerSelect
                                            placeholder ="Select Privacy."
                                            onValueChange = {this.selectedPrivacy} 
                                            items={[
                                                { label: 'Public', value: '0' },
                                                { label: 'Private', value: '1' },
                                            ]}
                                        />
                                    }
                                </View>
                            </View>

                            <View style={styles.item}>
                                <Text style ={{color : 'gray' , marginBottom : 5}}>Description</Text>
                                <Textarea
                                    containerStyle={styles.textareaContainer}
                                    style={global_style.textarea}
                                    defaultValue={this.state.text}
                                    placeholder={''}
                                    value= {this.state.description}
                                    placeholderTextColor={'#c7c7c7'}
                                    underlineColorAndroid={'transparent'}
                                    onChangeText={(text) => this.setState({description : text})}
                                />
                            </View>
                            {
                                this.state.privacy == '0' ? null :
                                <View style={styles.item}>
                                    <Text style ={{color : 'gray'}}>Add Friends</Text>
                                    <View style={styles.user}>
                                        <TouchableOpacity style={styles.new_friend} onPress={()=> this.addFriend()}>
                                            <Image source = {require('../../../../../assets/img/icon/plus_btn.png')} style={styles.plus_btn}/>
                                        </TouchableOpacity>
                                        {
                                            this.state.friends_arr.map((user, index) => {
                                                return (
                                                    user.img_url == '' ? 
                                                    <View style={[styles.profile, {backgroundColor : 'whitesmoke', borderRadius : 40}]}  key={index}></View>
                                                    :
                                                    <Avatar
                                                        size="medium"
                                                        rounded
                                                        source={{uri : user.img_url}}
                                                        resizeMode={'stretch'}
                                                        style={styles.profile}
                                                        key={index}
                                                    />
                                                )
                                            })
                                        }
                                    </View>  
                                </View>
                            }
                            <View style={{marginBottom : 10}}></View>
                            </View>
                        </View>
                    
                </ScrollView>
                {
                    !this.state.isLoading ? 
                    <View style={global_style.bottom}>
                        <View style={{flex : 2.5}}></View>
                        <TouchableOpacity onPress={() => this.createGroup()} style={global_style.cyan_btn}>
                            <Text style={global_style.label}>Create Group</Text>
                        </TouchableOpacity>
                        <View style={{flex : 2.5}}></View>
                    </View> : null
                }
                
                <View style={this.state.isLoading ? styles.loading : styles.finish}>
                    <LoadingBar/>
                </View>
                </KeyboardAwareScrollView>
            </View>
            
        )
    }
}
const styles = StyleSheet.create({
    body : {
        alignItems: 'center',
        alignSelf : 'center',
        marginTop: 15 * metrics,
        marginBottom : 90 * metrics,
        width : '95%',
        shadowOffset : {width: 0, height: 4},  
        shadowOpacity : Platform.OS == 'ios' ? 0.2 : 0.8,
        elevation : Platform.OS == 'ios' ? 1.0 : 10,
        borderRadius : 10,
        backgroundColor : 'white'
    },
    edit_body: {
       
        width: '100%',
        overflow : 'hidden',
        borderRadius: 15,
        paddingLeft : 25 * metrics,
        paddingRight : 25 * metrics
    },
    f_item: {
        margin: 10 * metrics,
        flexDirection : 'column',
        marginTop: 40 * metrics
    },
    item : {
        margin: 10 * metrics,
        //marginBottom:3,
        flexDirection : 'column'
    },
    input : {
        borderRadius : 8 * metrics,
        backgroundColor : 'whitesmoke',
        padding: 5 * metrics
    },
    backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%'
    },
    user : {
        paddingTop : 10 * metrics,
        flexDirection : 'row'
    },
    new_friend : {
        backgroundColor : '#b9b9b9',
        width : 45 * metrics,
        height: 45 * metrics,
        justifyContent: 'center',
        borderRadius : 45,
        borderWidth : 1,
        borderColor : '#b9b9b9',
        marginTop: 3 * metrics,
    },
    plus_btn: {
        width : 25 * metrics,
        height: 25 * metrics,
        alignSelf: 'center'
    },
    profile: {
        width : 45 * metrics,
        height: 45 * metrics,
        marginTop: 3 * metrics,
        margin:5 * metrics
    },

    camera : {
        width : 40 * metrics,
        height : 35 * metrics,
        margin : 'auto',
    },
    bottom: {
        width: '100%',
        height : 60 * metrics,
        position : 'absolute',
        bottom : 0,
        paddingTop : 7 * metrics,
        backgroundColor : 'white',
        elevation : 4.5,
    },
    cyan_btn : {
        width: '55%',
        height: 45 * metrics,
        borderRadius: 40,
        alignItems: 'center',
        alignSelf :'center',
        backgroundColor: '#4f80ff',
        shadowRadius: 7,  
        elevation : 3.5
    },
    label : {
        height: '100%',
        alignItems: 'center',
        fontSize: 18 * metrics,
        color: 'white',
        marginTop: 10 * metrics,
    },
    photos : {
        width : 160 * metrics,
        height : 130 * metrics,
        marginRight : 10 * metrics,
        alignSelf : 'center',
        marginTop : 30 * metrics,
        borderColor : '#e8dddd',
        borderWidth : 1,
        borderRadius : 10
    },
    new_img : {
        width : 65 * metrics,
        height : 50 * metrics,
        alignSelf : 'center',
        marginTop : 35 * metrics,
        borderRadius : 10
    },
    loading : {
      position : 'absolute',
      width : '100%',
      height : '100%',
      backgroundColor : 'black',
      opacity : 0.4
   },
   finish : {
      width : 0,
      height : 0,
      position : 'absolute'
   },
   privacy : {
       margin : 0,
   },
   error : {
      color : 'red',
      fontSize : 13 * metrics,
      marginLeft : 10 * metrics
    }, 
    non_error : {
        display : 'none'
    },
})
export default AddGroupScreen