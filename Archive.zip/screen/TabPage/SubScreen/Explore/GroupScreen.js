import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet, TouchableOpacity, TouchableHighlight,ScrollView} from 'react-native';
import GroupService from '../../../../services/group.service';
import UserService from '../../../../services/user.service';
import { inject, observer } from 'mobx-react';
import {replaceTitle} from '../../../../utils/utils';
import LoadingBar from '../../../../components/LoadingBar';
import global_style , { metrics }from '../../../../constants/globalStyles';
import { Avatar } from 'react-native-elements';

@inject ('groupService','userService')
@observer

class GroupScreen extends Component {

    _groupService : GroupService = this.props.groupService;
    _userService : UserService = this.props.userService;

    constructor (props) {
        super(props)
        this.state = {
            group_arr: [],
            isLoading : false
        }
    }
    group_arr = [] //temp array
    getDetail = (item) => {
        var group_data = {
            group_id : item.id,
            user_info : item.uid
        }
        this.props.navigation.navigate('GroupInfoScreen', {group_data : group_data});
    }

    onChangeState = (val) => { //search
        if (val == '') {
            this.setState({group_arr : this.group_arr})
        } else {
            var temp_arr1 = [];
            for (var i = 0 ; i < this.group_arr.length ; i++) {
                if(this.group_arr[i].title.toLowerCase().indexOf(val.toLowerCase())!=-1) {
                    temp_arr1.push(this.group_arr[i]);
                }
            }
            this.setState({group_arr : temp_arr1})
        }
    }

    componentWillUnmount() {
        this.unsubscribeGroup()
    }

    componentDidMount() {
        var _this = this;
        this.unsubscribeGroup = this._groupService.getPublicGroupData().onSnapshot(function(result){
            const data = result.docs.map(doc => doc.data());
            var count = 0;
            if (data.length > 0) {
                data.forEach(element => {
                    _this._userService.getUserData(element.uid).then((res) => {
                        if (res.exists) {
                            element.uid = res.data()
                        }
                        count ++;
                        if (count == data.length) {
                            _this.setState({group_arr : data})
                            _this.group_arr = data
                            _this.setState({isLoading : false}) 
                        }
                    })
                });
            } else {
                _this.setState({group_arr : []})
                _this.group_arr = [];
                _this.setState({isLoading : false})
            }
        })
    }
    render() {
        return (
            <View style={{height : '100%'}}>
                <ScrollView style={styles.group_container}>
                    {
                        this.state.group_arr.map((item, index) => {
                            if (item.uid.uid == global.user_info.uid) {
                                return
                            }
                            return (
                                <View style={styles.item} key={index}>
                                    <Image source = {{uri : item.group_img}} style={styles.img}/>
                                    <View style={styles.leftbody}>
                                        <Text style={styles.big_title}>{replaceTitle(item.title)}</Text>
                                        <Text style={{marginTop: 5 * metrics}}>{item.friends_arr.length + 1} Member</Text>
                                        <View style={styles.profile_body}>
                                            {
                                                item.uid.img_url != '' ? 
                                                    <Avatar
                                                        rounded
                                                        size="medium"
                                                        source={{uri : item.uid.img_url}}
                                                        resizeMode={'stretch'}
                                                        style={styles.profile}
                                                        />
                                                    : <View style={styles.profile}></View>    
                                            }
                                            <View style={styles.profile_name}>
                                                <Text style={styles.bytag}>By</Text>
                                                <Text style={styles.name}>{item.uid.f_name} {item.uid.l_name}</Text>
                                            </View>
                                        </View>
                                        <TouchableOpacity style={styles.details} onPress={() => this.getDetail(item)}>
                                            <Text style={styles.detail_label}>View Groups <Image source = {require('../../../../assets/img/icon/right_arrow.png')} style={styles.right_arrow}/></Text>
                                        </TouchableOpacity>
                                    </View>
                                </View>
                            )
                        })
                    }
                    
                </ScrollView>
                <View style={this.state.isLoading ? global_style.loading : global_style.none}>
                    <LoadingBar />
                </View>
            </View>
                          
        )
    }
}
const styles = StyleSheet.create({
    group_container : {
        width: '100%',
        marginTop : 10 * metrics
    },  
    item : {
        flex: 1,
        flexDirection : 'row',
        margin : 10,
    },
    img : {
        width : '60%',
        height : 170 * metrics,
        borderRadius : 10,
        padding : 10 * metrics,
        elevation : 1.5,
        shadowOpacity : 0.3,
        shadowOffset : { width : 0, height : 2}
    },
    leftbody: {
        width : '50%',
        height: 140 * metrics,
        backgroundColor : 'white',
        marginLeft : -37 * metrics,
        marginTop: 15 * metrics,
        borderRadius : 10,
        padding : 10 * metrics,
        elevation : 1.5,
        shadowOpacity : 0.3,
        shadowOffset : { width : 0, height : 2}
    },
    small_title : {
        fontSize : 11 * metrics
    },
    big_title: {
        fontSize : 15 * metrics,
        color: '#4f80ff'
    },
    star_rating : {
        width: '55%',
        marginTop: 5 * metrics
    },
    profile_body : {
        flex: 1,
        flexDirection :'row',
        
    },
    profile: {
        width : 40 * metrics,
        height: 40 * metrics,
        resizeMode : "stretch",
        borderRadius : 100,
        alignSelf : 'center',
        marginRight: 15 * metrics,
    },
    profile_name : {
        flex: 1,
        flexDirection : "column",
        alignSelf : 'center',
    },
    bytag : {
        fontSize : 12 * metrics
    }, 
    name : {
        fontSize : 15 * metrics,
        fontWeight: '400'
    },
    details : {
        padding: 0,
        height: 24 * metrics,
        borderTopColor : '#ececec',
        borderTopWidth : 1,
    },
    detail_label : {
        marginTop: 10 * metrics,
        fontSize: 12 * metrics,
        textAlign : 'center'
    },
    right_arrow : {
        height: 7 * metrics,
        width: 7 * metrics
    }
})
export default GroupScreen