import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,TextInput,Dimensions,Platform} from 'react-native';
// import Star from 'react-native-star-view';
import Stars from 'react-native-stars';
import global_style, { metrics } from  '../../../../constants/globalStyles';
import UserService from '../../../../services/user.service';
import PlanService from '../../../../services/plan.service';
import { inject, observer } from 'mobx-react';
import { Input , Avatar} from 'react-native-elements';

import LoadingBar from '../../../../components/LoadingBar';
import Textarea from 'react-native-textarea';

const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const ratioX = screenWidth / 360;

@inject ('userService')
@inject ('planService')
@observer



class ReviewScreen extends Component {
    _userService : UserService= this.props.userService
    _planService : PlanService = this.props.planService
    flag = false;

    state = {
        stars : 0,
        height : 0,
        user_img : '',
        user_name : '',
        plan_item : null,
        description : '',
        isLoading : false
    }

    componentWillUnmount() {
        this.unsubscribePlan()
    }

    componentWillMount () {
        var id = this.props.navigation.getParam('place_id')

        var user_name = global.user_info.f_name + ' ' + global.user_info.l_name;
        var user_img = global.user_info.img_url
        this.setState({user_name : user_name})
        this.setState({user_img : user_img})
        var _this = this
        this.unsubscribePlan = this._planService.getDataById(this.props.navigation.getParam('plan_id')).onSnapshot(function(result){
            if (result.exists) { 
                _this.setState({plan_item : result.data()})
            }
        })
    }
    post = () => {
        if (this.flag) return; // when user clicked review btn
        this.flag = true;
        var obj = {
            rating_count : this.state.stars,
            uid : global.user_info.uid,
            description : this.state.description,
            time : new Date()
        }
        this.setState({isLoading : true})
        this.state.plan_item.reviews.push(obj)
        this._planService.updateData(this.state.plan_item.id, this.state.plan_item).then(() => {
            this.setState({isLoading : false})
            this.props.navigation.navigate('PlaceDetailScreen', {plan_id : this.props.navigation.getParam('plan_id')});   
        })
    }
    onStarRatingPress = (rating) => {
        this.setState({starCount : rating});
    }
    static navigationOptions = ({ navigation }) => {
        return {
            headerLeft: (
                <View style={global_style.navigation}>
                    <TouchableOpacity 
                        style={styles.backarrow}
                        onPress={() => navigation.goBack()} >
                            <Image source = {require('../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                            <Text style={global_style.back_title}>WRITE REVIEW</Text>
                    </TouchableOpacity>
                </View>
            ),
            headerStyle:global_style.headerHeight,
        };
    };
   render() {
      return (
        <View style ={{width : '100%' , height : '100%', backgroundColor : '#f4f9fc'}}>
            
            <View style={{height : '100%'}}>
                <View style={styles.body}>
                    <View style={styles.profile}>
                        <Avatar
                            rounded
                            overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                            size="xlarge"
                            source={{uri : this.state.user_img}}
                            resizeMode={'stretch'}
                            containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                            style={styles.profile_img}
                        />
                    </View>

                    <Text style={styles.title}>{this.state.user_name}</Text>

                    <View style={styles.user_rating}>
                    <View style={{alignItems:'center' , marginTop : 10 * metrics , marginBottom : 10 * metrics}}>
                        <Stars
                            half={false}
                            default={0}
                            update={(val)=>{this.setState({stars: val})}}
                            spacing={4}
                            starSize={40 * ratioX}
                            count={5}
                            fullStar={require('../../../../assets/img/icon/yellow-star.png')}
                            emptyStar={require('../../../../assets/img/icon/ico_star.png')}
                            halfStar={require('../../../../assets/img/icon/ico_star.png')}/>
                        </View>
                    </View>
                    
                    <View style={styles.description}>
                        <Textarea
                            containerStyle={styles.textareaContainer}
                            style={styles.textarea}
                            defaultValue={this.state.text}
                            placeholder={''}
                            value= {this.state.description}
                            placeholderTextColor={'#c7c7c7'}
                            underlineColorAndroid={'transparent'}
                            onChangeText={(text) => this.setState({description : text})}
                        />
                    </View>
                </View>
                <View style={[global_style.bottom, {flex : 10}]}>
                    <View style={{flex : 2.5}}></View>
                    <TouchableOpacity onPress={() => this.post()} style={global_style.cyan_btn}>
                        <Text style={styles.label}>Post Review</Text>
                    </TouchableOpacity>
                    <View style={{flex : 2.5}}></View>
                </View>
            </View>
            <View style={this.state.isLoading ? styles.loading : styles.none }>
                <LoadingBar />
            </View>
        </View>
        
      )
   }
}
const styles = StyleSheet.create({
    body: {
        flexDirection : 'column',
        marginTop : 20 ,
        borderRadius: 10,
        margin : 10,
        backgroundColor : 'white',
        padding : 5,
        width: '95%',
        alignItems : 'center',
        alignItems : 'center',
        shadowColor: '#dadada',
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: Platform.OS == 'ios' ?  0.4 : 0.8,
        shadowRadius: 7,  
        elevation : Platform.OS == 'ios' ? 1.5 : 10
    },
    starStyle : {
        width: '100%',
        alignSelf : 'center',
        alignItems : 'center',
    },
    profile: {
        width: '100%',
        height : 140 * ratioX,
        alignItems : 'center'
    },
    profile_img : {
        width: 120 * ratioX,
        height : 140 * ratioX,
        paddingTop:20 * ratioX,
    },
    backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%'
    },
    camera : {
        width : 40,
        height : 35,
        resizeMode : 'stretch',
        margin : 'auto',
    },
    user_rating : {
        width : '100%',
    },
    title : {
        fontSize : 17 * ratioX,
        marginTop : 10,
        textAlign : "center"
    },
    description : {
        width: '95%',
        margin : 'auto',
        marginTop: 5,
        marginBottom : 5
    },
    input : {
        borderRadius : 8,
        backgroundColor : 'whitesmoke',
        padding: 5
    },
    bottom: {
        marginTop : 40 * ratioX,
        width: '100%',
        height : 60 * ratioX,
        position : 'absolute',
        bottom : 0,
        backgroundColor : 'white',
        elevation : 3.5
     },
     cyan_btn : {
        width: '55%',
        height: 45 * ratioX,
        borderRadius: 40,
        marginTop : 7 * ratioX,
        elevation : 30,
        alignItems: 'center',
        alignSelf : 'center',
        backgroundColor: '#4f80ff',
        elevation : 3.5
     },
     label : {
        height: '100%',
        //alignItems: 'center',
        fontSize: 18 * ratioX,
        color: 'white',
        justifyContent : 'center',
        marginTop : 9 * metrics
     },
     myStarStyle: {
        color: 'yellow',
        backgroundColor: 'transparent',
        textShadowColor: 'black',
        textShadowOffset: {width: 1, height: 1},
        textShadowRadius: 2,
      },
      myEmptyStarStyle: {
        color: 'white',
      },
      textarea: {
        textAlignVertical: 'top',  // hack android
        height: 150 * ratioX,
        fontSize: 14 * ratioX,
        color: '#333',
        borderWidth : 1,
        borderColor : '#eae5e5',
        borderRadius: 4,
        padding : 10
    },
    loading : {
      position : 'absolute',
      width : '100%',
      height : '100%',
      backgroundColor : 'black',
      opacity : 0.4,
      zIndex : 999,
      elevation : 30
   },
   finish : {
      width : 0,
      height : 0,
      position : 'absolute'
   },
})
export default ReviewScreen