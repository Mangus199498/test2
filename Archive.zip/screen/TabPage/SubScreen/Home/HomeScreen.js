import React, { Component } from 'react';
import { AppRegistry,
     View , 
     Text, 
     Image,
     StyleSheet,
     ScrollView, 
     TouchableHighlight,
     TextInput, 
     PermissionsAndroid,
     ImageBackground,
     TouchableWithoutFeedback,
     TouchableOpacity,
     Platform,
     Keyboard
} from 'react-native';

import global_style, { metrics } from '../../../../constants/globalStyles';
import UserService  from '../../../../services/user.service';
import PlanService from '../../../../services/plan.service';
import { Google_API_KEY ,replacetext} from '../../../../utils/utils';
import { inject ,observer} from 'mobx-react';
import { GooglePlacesAutocomplete } from 'react-native-google-places-autocomplete';
import MapView , { Marker ,AnimatedRegion ,Callout, CustomCallout}from 'react-native-maps';

import Geolocation from 'react-native-geolocation-service';
import { Input , Avatar} from 'react-native-elements';

import active_marker from '../../../../assets/img/icon/active_google_icon.png';
import disable_marker from '../../../../assets/img/icon/disable_google_icon.png';
import myLocation from '../../../../assets/img/icon/mylocation_bg.png';
import location_bg from '../../../../assets/img/icon/location_bg.png';
import location_icon from '../../../../assets/img/icon/ico_locate.png';
import location_popup from '../../../../assets/img/icon/popup.png';
let _this = null;

@inject ('userService','planService')
@observer


class HomeScreen extends Component {
    _userService : UserService = this.props.userService;
    _planService : PlanService = this.props.planService;
    
    constructor(props) {
        super(props);
        this.state = {
            longitude : 0,
            latitude : 0,
            plan_arr : [],
            p_plan_arr : [],
            public_plan_arr : [],
            all_plan_arr : [],
            region: {
                latitude: 0,
                longitude: 0,
                latitudeDelta: 10.04864195044303443,
                longitudeDelta: 10.040142817690068,
            },
            myInfo : {},
            selected_marker_idx : -1,
            myAddress : '',
            gotoAddress : '',
            address: '',
            address_value : '',
            public_idx : 0,
            shouldDisplayListView : false
        }
        this.handlePress = this.handlePress.bind(this)
    }
    original_data = [];
    p_original_data = [];
    map_data = []; // temp array
    gotoDetail = (item) => {
        this.props.navigation.navigate('PlaceDetailScreen', {plan_id : item.id});
    }
    gotoDetailByMarker = (idx) => {
        var item = this.state.all_plan_arr[idx];
        this.gotoDetail(item)
    }
    gotoDetailByPMarker = (idx) => {

    }
    async getCurrentPosition () {
        var my_position = {}
        Geolocation.getCurrentPosition(
            (position) => {
                my_position = {
                    latitude : parseFloat(position.coords.latitude),
                    longitude : parseFloat(position.coords.longitude),
                    latitudeDelta: 0.04864195044303443,
                    longitudeDelta: 0.040142817690068,
                }
                this.setState({
                    region: my_position
                });
                this.refs.map.animateToRegion(this.state.region, 2000);
                this.setState({longitude : parseFloat(position.coords.longitude) })
                this.setState({latitude : parseFloat(position.coords.latitude)})
                fetch('https://maps.googleapis.com/maps/api/geocode/json?address=' + this.state.latitude + ',' + this.state.longitude + '&key=' + Google_API_KEY)
                    .then((response) => response.json())
                    .then((responseJson) => {
                        this.setState({myAddress : responseJson.results[0].address_components[0].short_name})
                        this.setState({gotoAddress : responseJson.results[0].address_components[0].short_name})
                })
            },
            (error) => {
                alert(error.message)
                console.log(error.code, error.message);
            },
            { enableHighAccuracy: false, timeout: 15000, maximumAge: 10000 }

        );
    }
    componentDidMount () {
        this.setState({myInfo : global.user_info})
        this.getCurrentPosition();
    }

    requestGeolocationPermission() {
        try {
           const granted = PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION)
           console.log(PermissionsAndroid.RESULTS.GRANTED)
           if (granted === PermissionsAndroid.RESULTS.GRANTED) {
           } else {
           }
         } catch (err) {
           console.warn(err)
         }
      }

    async componentWillMount () 
    {   
        this.setState({all_plan_arr : []})
        if (Platform.OS == "android")
            this.requestGeolocationPermission()
        this.index = 0;
        _this= this;
        this.getDataByPrivate()
        
    }

    componentWillUnmount() {
        this.unsubscribePlan()
        this.unsubscribePublic()
    }

    async getDataByPrivate () {
        this.unsubscribePlan = await this._planService.getAllDataByPrivate(global.user_info.uid).onSnapshot(function(result){
            _this.p_original_data = [];
            const data = result.docs.map(doc => doc.data());
            var count = 0;
            if (data.length > 0) {
                data.forEach(element => {
                    _this._userService.getUserData(element.uid).then((res) => {
                        if (res.exists) {
                            element.uid = res.data()
                        }
                        count++;
                        if (count == data.length) {
                            _this.p_original_data = data;
                            _this.getDataByPublic()
                        }
                    })
                });
            } else {
                _this.p_original_data = [];
                _this.getDataByPublic()
            }
        })
    }
    async getDataByPublic() {
        this.unsubscribePublic = await this._planService.getAllDataByPublic().onSnapshot(function(result) {
            const data = result.docs.map(doc => doc.data());
            _this.setState({all_plan_arr : []})
            _this.original_data = [];

            if (_this.p_original_data.length > 0) {
                for (var i =0 ; i < _this.p_original_data.length ;i++) {
                    _this.original_data.push(_this.p_original_data[i])
                }   
            }
            _this.p_original_data = [];
            var count = 0;
            if (data.length > 0) {
                data.forEach(element => {
                    _this._userService.getUserData(element.uid).then((res) => {
                        if (res.exists) {
                            element.uid = res.data()
                        }
                        count++;
                        if (count == data.length) {
                            for (var i = 0 ;i < data.length; i++) {
                                _this.original_data.push(data[i])
                            }
                            var final_data = _this.checkOverride(_this.original_data)
                            _this.map_data = final_data // temp array
                            _this.setState({all_plan_arr : final_data})
                            _this.nearByData();  
                        }
                    })
                });
            } else {
                _this.setState({all_plan_arr : _this.original_data})  
            }
        })
    }
    checkOverride () {
        var datas = []
        if (this.original_data.length > 0) { //remove override
            for (var i = 0 ; i < this.original_data.length; i++) {
                var num = 0;
                if (datas.length == 0 ) {
                    datas.push(this.original_data[i])
                } else {
                    for (var j = 0 ; j < datas.length ; j++) {
                        if (datas[j].id == this.original_data[i].id) {
                            num = 1;
                            break;
                        }
                    }
                    if (num == 0) {
                        datas.push(this.original_data[i])
                    }
                }
            }
        }
        return datas
    }
    async nearByData() {
        this.setState({plan_arr : []})
        var result_arr = [];
        
        var plans_arr = this.checkOverride()
        console.log('plan_arr = ' , plans_arr)
        for (var i =0 ; i < plans_arr.length ;i++) {
            var distance = await this.getDistance(this.state.region.latitude, this.state.region.longitude , plans_arr[i].address.location.lat , plans_arr[i].address.location.lng);
            if (typeof(distance) == 'undefined') {
                continue;
            } else {
                plans_arr[i].distance = distance;
                if (distance.value < 1000000) {
                    result_arr.push(plans_arr[i])
                }
            }
        }
        this.setState({plan_arr : result_arr})
    }
    async getDistance(m_lat, m_lng, p_lat, p_lng) {
        const myloc = m_lat + "," + m_lng;
        const placeloc = p_lat + "," + p_lng;

        let ApiURL = "https://maps.googleapis.com/maps/api/distancematrix/json?";
        let params = `origins=${myloc}&destinations=${placeloc}&key=${Google_API_KEY}`;

        let finalApiURL = `${ApiURL}${encodeURI(params)}`;
        let fetchResult = await fetch(finalApiURL);

        let Result =  await fetchResult.json();
        return Result.rows[0].elements[0].distance;
        
    }
    handlePress = (e) => {
        if (this.state.selected_marker_idx != -1) {
            this.setState({selected_marker_idx : -1})
        }
    }   
    onPressMarker = (e, index) => {
        console.log(index)
        this.setState({selected_marker_idx : index})
    }

    gotoPosition =(value) => {
        this.original_data = this.map_data
        this.setState({plan_arr : this.map_data})
        if (value == 'myPosition') {
            this.setState({gotoAddress : this.state.myAddress})
            position = {
                latitude : parseFloat(this.state.latitude),
                longitude : parseFloat(this.state.longitude),
                latitudeDelta: 0.04864195044303443,
                longitudeDelta: 0.040142817690068,
            }
        } else {
            this.setState({gotoAddress : this.state.address.name})
            var moveData = {
                name : this.state.address.name,
                latitude : this.state.address.geometry.location.lat,
                longitude : this.state.address.geometry.location.lng,
            }
            position = {
                latitude : parseFloat(moveData.latitude),
                longitude : parseFloat(moveData.longitude),
                latitudeDelta: 0.04864195044303443,
                longitudeDelta: 0.040142817690068,
            }
        }
        this.setState({
            region: position
        });
        setTimeout(() => {
            this.refs.map.animateToRegion(this.state.region, 2000);
            this.nearByData();    
        }, 1000);
    }

    temp_arr = []
    getNearData = () => {
        if (this.temp_arr.length == 0){
            return;
        }
        this.setState({plan_arr : this.temp_arr})
    }
    getAllData = () => {
        this.temp_arr = this.state.plan_arr
        var data = this.checkOverride(this.original_data)
        this.setState({plan_arr : data})
    }

    //search location and place
    onChangeState = (search) => { //search plan
        if (search == '') {
            this.setState({all_plan_arr : this.map_data})
            this.original_data = this.map_data
        } else {
            var temp_arr = [];
            
            for (var i = 0 ; i < this.map_data.length ; i++) {
                if(this.map_data[i].address.name.toLowerCase().indexOf(search.toLowerCase())!=-1 || this.map_data[i].description.toLowerCase().indexOf(search.toLowerCase())!=-1) {
                    temp_arr.push(this.map_data[i]);
                }
            }
            this.setState({all_plan_arr : temp_arr})
            this.original_data = temp_arr
        }
        this.getAllData();
    }
    //

    render() {
        return (
            <TouchableWithoutFeedback onPress={()=>Keyboard.dismiss()}>   
                <View style={global_style.container}>
                    <View style={global_style.google_map} id="google_map">
                        <MapView
                            ref="map"
                            zoomEnabled = {true}
                            initialRegion={this.state.region}
                            style={styles.container}
                            onPress = { this.handlePress}
                            >
                                {
                                    <MapView.Marker
                                        coordinate={{"latitude":this.state.latitude,"longitude":this.state.longitude}}
                                        title="My Location"
                                    >
                                        <View style={{height: 50, width:50 ,backgroundColor : 'transparent'}}>
                                            <Image source={myLocation} style={{height: 50, width:50}} />
                                            <Avatar
                                                rounded
                                                overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                                                size="xlarge"
                                                source={{uri : this.state.myInfo.img_url}}
                                                resizeMode={'stretch'}
                                                containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                                                style = {{width : 33, height : 33, position: 'absolute', alignSelf : 'center' , paddingTop : 2}}
                                            />
                                        </View>
                                        
                                    </MapView.Marker>
                                }
                                {
                                    this.state.all_plan_arr.map((item,index) => {
                                        return (
                                            <MapView.Marker
                                                key={index}
                                                coordinate={{latitude: item.address.location.lat,longitude: item.address.location.lng}}
                                                onPress={(e) => this.onPressMarker(e, index)}
                                            >   
                                                <Image source={this.state.selected_marker_idx == index ? active_marker : disable_marker} style={{height: 40, width:40, alignSelf : 'center'}} /> 
                                                <MapView.Callout width={180} height={60} onPress={()=>this.gotoDetailByMarker(index)}>
                                                    <View style={styles.popup_body}>
                                                        <Text style={Platform.OS =='ios' ? styles.image_bg : styles.image_bg_android}>
                                                            {
                                                                item.address.photo_arr.length == 0 ? <View style={Platform.OS == 'ios' ? styles.popup_img : styles.popup_img_android}></View> :
                                                                <Image source={{uri : item.address.photo_arr[0]}} style={Platform.OS == 'ios' ? styles.popup_img : styles.popup_img_android}  resizeMode="cover"></Image>
                                                            }
                                                        </Text>
                                                        <View style={Platform.OS == 'ios'? styles.right_body : styles.right_body_android}>
                                                            <Text style={styles.title}>
                                                            {
                                                                replacetext(item.address.name)
                                                            }
                                                            </Text>
                                                            <Text style={styles.far_away}>
                                                                {
                                                                    item.distance == undefined ? "far away" : item.distance.text + ' away'
                                                                }
                                                            </Text>
                                                            <Text style={styles.detail}>View details</Text>
                                                        </View>
                                                        
                                                    </View>
                                                </MapView.Callout>
                                                
                                            </MapView.Marker>
                                        )
                                    })
                                }
                        </MapView>
                    </View>
                    <View style={global_style.google_location}>
                        <GooglePlacesAutocomplete
                            query={{ key: Google_API_KEY }}
                            placeholder='Enter Location'
                            minLength={2}
                            autoFocus={false}
                            returnKeyType={'default'}
                            fetchDetails={true}
                            getDefaultValue={() => ''}
                            listViewDisplayed={this.state.shouldDisplayListView}                                      
                            textInputProps = {{onFocus : ()=> this.setState({shouldDisplayListView : true}), onBlur: () => this.setState({shouldDisplayListView : false})}}
                            onPress={(data, details = null) => { // 'details' is provided when fetchDetails = true
                                this.setState({address : details})
                                this.gotoPosition('address')
                            }}
                            styles={{
                                textInputContainer: {
                                    backgroundColor: 'transparent',
                                    borderBottomWidth : 0,
                                    borderTopWidth: 0,
                                    width : '95%',
                                    alignSelf : 'center',
                                    paddingLeft : 10,
                                    paddingRight : 10,
                                },
                                textInput: {
                                    marginLeft: 0,
                                    marginRight: 0,
                                    height: 45,
                                    marginTop : 5,
                                    borderRadius : 55,
                                    elevation : 1.5,
                                    color: '#5d5d5d',
                                    fontSize: 14,
                                    elevation : 10,
                                    shadowColor : 'black',
                                    shadowOffset : {width : 0, height :2},
                                    shadowOpacity : 0.4
                                },
                                listView: {
                                    backgroundColor : 'white',
                                    width : '90%',
                                    alignSelf : 'center',
                                    height : 300 * metrics,
                                    marginTop : 10 * metrics,
                                    borderRadius : 10,
                                },
                                predefinedPlacesDescription: {
                                    color: '#1faadb'
                                },
                            }}
                            ref={element => {
                                if (element) {
                                    this.input = element.refs.textInput._getText;
                                }
                            }}
                            onChangeText = {(text)=> this.setState({address_value: text}) }
                            value = {this.state.address}
                            currentLocation={false}
                        />
                        <TouchableOpacity onPress={()=> this.gotoPosition('myPosition')}style={{marginRight : 5 , height : 60* metrics ,justifyContent : 'center' , elevation : 4 , shadowOffset : {width : 0, height : 2} , shadowOpacity : 0.4}}>
                            <Image source = {location_icon} style={styles.l_icon}></Image>  
                        </TouchableOpacity>
                        
                    </View>
                    <View style={global_style.place_body}>
                        <View style={this.state.plan_arr.length > 0 ? global_style.place_label : {width : 0, height : 0}}>
                            <TouchableOpacity onPress={() => this.getNearData()} style={styles.label}>
                                <Text style={{fontSize : 14}}>NEARBY PLACES | <Text style={{color:'#4f80ff' , fontSize : 14}}>{replacetext(this.state.gotoAddress)}</Text></Text>
                            </TouchableOpacity>
                            
                            <TouchableOpacity onPress={() => this.getAllData()} style={styles.see_all}>
                                <Text style={{fontSize : 14}} >SEE ALL</Text>
                            </TouchableOpacity>
                        </View>
                        
                        <View style={global_style.place_img}>
                            <ScrollView horizontal={true} showsHorizontalScrollIndicator={true} bounces={false}>
                                {
                                    this.state.plan_arr.map((item, index) => {
                                        return (
                                            <View style={styles.place_item} key={index}>
                                                <TouchableOpacity onPress={() => this.gotoDetail(item) }>
                                                    <View style = {global_style.image}>
                                                        {
                                                            item.address.photo_arr.length == 0 ? <View style={{width: '100%', height : '100%', borderRadius: 10, backgroundColor: 'gray'}}></View> :
                                                            <Image source = {{uri : item.address.photo_arr[0]}} style={{width: '100%', height : '100%', borderRadius: 10}}></Image> 
                                                        }
                                                    </View>
                                                </TouchableOpacity>
                                                <Text style={global_style.title}>{item.address.name}</Text>
                                            </View>
                                        )
                                    }) 
                                }
                            </ScrollView>
                            
                        </View>
                    </View>
                </View>
            </TouchableWithoutFeedback>
        )
    }
}
const styles = StyleSheet.create({
    l_bg: {
        height: 55,
        width: '75%',
        resizeMode: "stretch",
        alignItems: 'center',
        marginLeft : 10,
        position : 'absolute'
    },
    l_icon : {
        height: 55,
        width : 55,
        resizeMode : "stretch",
        alignItems: 'center',
        marginLeft : 10
    },
    label : {
        marginLeft : 10
    },
    see_all: {
        alignSelf: 'center',
        position : 'absolute',
        right : 5,
        marginRight: 10
    },
    place_img : {
        borderRadius: 10,
        width: 130,
        height: 110,
        margin : 10,
        marginRight : 0, 
        resizeMode: "stretch",
        shadowOffset: {width : 0 , height : -20},
        shadowColor : 'black',
        shadowRadius : 10,
        shadowOpacity : 1,
    },
    popup_body : {
        width : '100%', height : '100%',flexDirection : 'row'
    },
    image_bg : { 
        backgroundColor : 'white',alignSelf: "center",marginLeft : -5, height : 100, borderRadius : 20,
    },
    image_bg_android : {
        backgroundColor : 'white',alignSelf: "center",marginTop : -35, height : 100, borderRadius : 20,
    },
    popup_img : {
        width : 75, height : 75,borderRadius : 10, position : 'absolute'
    },
    popup_img_android : {
        width : 80, height : 80,borderRadius : 10, position : 'absolute'
    },
    right_body : {
        flexDirection : 'column', left : 78, position : 'absolute',
    },
    right_body_android : {
        flexDirection : 'column' , marginLeft : 7 , marginTop : 3
    },
    far_away : {
        fontSize : 12, color: 'green'
    },
    detail : {
        fontSize : 11 , color : 'gray'
    },
    title : {
        fontSize : 14
    },
    container: {
        flex: 1,
    },
    // container: {
    //     flex: 1,
    //     width:300,
    //     height: 200,
    //   },
})
export default HomeScreen