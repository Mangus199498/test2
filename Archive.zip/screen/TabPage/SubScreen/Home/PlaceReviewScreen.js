import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,ScrollView} from 'react-native';
import Star from 'react-native-star-view';
import global_style , { metrics } from  '../../../../constants/globalStyles';
import PlanService from '../../../../services/plan.service';
import UserService from '../../../../services/user.service';

import LoadingBar from '../../../../components/LoadingBar';

import { inject, observer } from 'mobx-react';
import { Input , Avatar} from 'react-native-elements';
import { replaceTitle , replaceDescription,replaceHeadertitle} from '../../../../utils/utils'
import { getReviewTime } from '../../../../utils/moment';

@inject ('planService')
@inject ('userService')
@observer

class PlaceReviewScreen extends Component {
    _planService : PlanService = this.props.planService;
    _userService : UserService = this.props.userService;

    constructor(props) {
        super(props)
        this.state = {
            rating_count : 0,
            isDisableWriteReview : false,
            detail : null,
            isLoading : false, 
            isChecked : false,
        }
    }
    async componentWillMount () {
        var id = this.props.navigation.getParam('place_id')
        var _this = this
        this.setState({isLoading : true})
        this._planService.getDataByf_id(id).then((result) => {
            if (result.exists) { 
                var count = 0;
                var data = result.data();
                if (data.uid == global.user_info.uid) {
                    _this.setState({isDisableWriteReview : true})
                }
                if (data.reviews.length > 0) {
                    data.reviews.forEach(element => {
                        _this._userService.getUserData(element.uid).then((res) => {
                            if (res.exists) {
                                element.uid = res.data()
                            }
                                count ++;
                            if (count == data.reviews.length) {
                                _this.initRatingCount(data)
                                _this.setState({detail : data})
                                _this.setState({isLoading : false})
                                _this.initCheckin(data) //show checkin or no
                                _this.props.navigation.setParams({navTitle : replaceHeadertitle(data.address.name)})
                            } 
                        }).catch((error) => {
                            _this.setState({detail : null})
                            _this.setState({isLoading : false})
                            _this.props.navigation.setParams({navTitle : data.address.name})
                        })
                    });
                } else {
                    _this.setState({detail : data})
                    _this.setState({isLoading : false})
                    _this.props.navigation.setParams({navTitle : replaceHeadertitle(data.address.name)})
                }
            }
        }).catch((error) => {
            console.log(error)
        })
    }
    initCheckin = (data) => {
        if (data != undefined && data.checkin.length > 0) {
            for(var i =0 ;i < data.checkin.length ; i++) {
                if (data.checkin[i] == global.user_info.uid) {
                    this.setState({isChecked : true})
                    break;
                }
            }
        }
    }
    initRatingCount = (data) => {
        if (data.reviews.length > 0) {
            var count = 0;
            var flag = false;
            for (var i = 0; i < data.reviews.length ; i++) {
                if (data.reviews[i].uid.uid == global.user_info.uid) {
                    this.setState({isDisableWriteReview : true})
                    flag = true
                }
                
                count += data.reviews[i].rating_count    
            }
            this.setState({rating_count : count/data.reviews.length})
        }
    }
    onClickedReview = () => {
        var id = this.state.detail.id
        this.props.navigation.navigate('ReviewScreen', {plan_id : id})
    }
    static navigationOptions = ({ navigation }) => {
        const { params = {} } = navigation.state;
        return {
            headerLeft: (
                <View style={global_style.navigation}>
                    <TouchableOpacity 
                        style={styles.backarrow}
                        onPress={() => navigation.goBack()} >
                            <Image source = {require('../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                            <Text style={global_style.back_title}>{params.navTitle}</Text>
                    </TouchableOpacity>
                </View>
            ),
            headerStyle: global_style.headerHeight,
        };
    };
    render() {
        return (
            <View>
                <View style={this.state.isLoading ? global_style.loading : global_style.none}>
                    <LoadingBar />
                </View>
                <View style={!this.state.isDisableWriteReview ? styles.total_body : styles.no_padding_total_body} showsVerticalScrollIndicator={true}>
                    {
                        this.state.detail == null ? null : 
                        <ScrollView style={{height : '100%'}} bounces= {false}>
                            {
                                (this.state.detail.address.photo_arr.length == 0) ? <View style={styles.bg_img}></View> :
                                <Image source = {{uri: this.state.detail.address.photo_arr[0]}} style={styles.bg_img}/>
                                
                            }
                            {
                                this.state.isChecked ? <Text style={styles.checkin}>CHECKED IN</Text> : null
                            }
                            <View style = {styles.sub_body}>
                                <View style={styles.title}>
                                    <Text style={{fontSize : 20 * metrics, fontWeight : '500'}}>{replaceTitle(this.state.detail.address.name)}</Text>
                                    <View style={styles.star_rating}>
                                        <Star score={this.state.rating_count} style={global_style.starStyle}/>    
                                    </View>
                                </View>
                                <View style={styles.title}>
                                    <Text style={global_style.gray_title}>{this.state.detail.address.city_name.city_name} , {this.state.detail.address.city_name.country_name}</Text>
                                    <Text style={styles.check_num}>Check-Ins : {this.state.detail.checkin.length}</Text>
                                </View>

                                <View style={styles.about}>
                                    <Text style={{fontSize : 16 * metrics }}>About : </Text>
                                    <Text style={styles.about_description}>
                                        {this.state.detail.description}
                                    </Text>
                                </View>

                                <View style={styles.user_body}>
                                    <Text style={styles.review_title}>Reviews :</Text>
                                    {
                                        this.state.detail.reviews.length == 0 ? null :
                                        this.state.detail.reviews.map((item,index) => {
                                            return (
                                                <View style={styles.user} key={index}>
                                                    <Avatar
                                                        rounded
                                                        overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                                                        size="xlarge"
                                                        source={{uri : item.uid.img_url}}
                                                        resizeMode={'stretch'}
                                                        containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                                                        style={styles.profile}
                                                    />
                                                    <View style={styles.name}>
                                                        <View style={{flexDirection: 'row', width : '100%'}}> 
                                                            <Text style={{fontSize: 14, fontWeight: '700'}}>{item.uid.f_name} {item.uid.l_name}</Text>
                                                            <View style={styles.user_rating}>
                                                                <Star score={item.rating_count} style={global_style.starStyle}/>    
                                                            </View>
                                                        </View>
                                                        <Text style={styles.description} numberOfLines={5}>{item.description}</Text>
                                                        <Text style={styles.time}>{getReviewTime(item.time)}</Text>
                                                    </View>
                                                </View>
                                            )
                                        })
                                    }
                                </View>
                            </View>
                            
                        </ScrollView>
                    }
                    {
                        !this.state.isDisableWriteReview && this.state.detail != null?  
                        <View style={[global_style.bottom , {flex : 10}]}>
                            <View style={{flex : 2.5}}></View>
                            <TouchableOpacity onPress={() => this.onClickedReview()} style={global_style.cyan_btn}>
                                <Text style={global_style.label}>Write Review</Text>
                            </TouchableOpacity>
                            <View style={{flex : 2.5}}></View>
                        </View> : null
                    }
                </View>
            </View>
            
        )
    }
}
const styles = StyleSheet.create({
    total_body : {
        width: '100%', paddingBottom : 50, height : '100%', position : 'relative'
    },
    no_padding_total_body : {
        width: '100%', paddingBottom : 0 , height : '100%', position : 'relative'
    },
    total_dis_body : {
        width: '100%', 
        height : '100%'
    },
    bg_img: {
         width: '100%',
         height: 250 * metrics,
    }, 
    img_body : {
        height : 130 * metrics,
        width: '100%',
        paddingTop : 10 * metrics,
        flexDirection :'row',
    },
    backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%'
    },
    sub_body : {
         width:'100%',
         height : '100%',
         backgroundColor : 'white',
         borderTopLeftRadius : 25,
         borderTopRightRadius : 25,
         marginTop: -20,
         padding: 10
    },
    title : {
         height : 'auto' , 
         width : '100%',
         flexDirection : 'row',
         paddingBottom: 0,
         marginTop : 10 * metrics,
         paddingLeft : 10 * metrics , 
         paddingRight  : 10  * metrics
    },
    star_rating : {
         width : '25%',
         position : 'absolute',
         right : 15 * metrics,
         marginTop : 5 * metrics
    },
    user_rating : {
        width : '25%',
        alignSelf : "center",
        marginLeft : 15 * metrics,
    },
    about: {
        marginTop : 20 * metrics,
        flexDirection : 'column',
        paddingLeft : 10 * metrics , 
         paddingRight  : 10  * metrics
    },
    lock_icon : {
        width: 25 * metrics,
        height: 25 * metrics,
        resizeMode: "stretch",
        margin: 0,
        marginTop: -15,
        marginRight : 5,
    },
    place_img : {
        borderRadius: 10,
        width: '33.33%',
        height: 110 * metrics,
        marginRight : 0, 
        resizeMode: "stretch",
        marginRight : 5
    },
    about_description : {
        //color : '#4a4a4a',
        color : 'gray'
    },
    description : {
        fontSize: 11 * metrics,
        width : 240 * metrics,
        marginTop: 3 * metrics,
        alignSelf : 'flex-start',
        alignSelf: 'baseline',
        flexWrap :'wrap',
        flexDirection : 'column',
    },
    check_num : {
        position : "absolute",
        right : 10 * metrics,
        fontSize: 14 * metrics
    },
    bottom : {
        width : '100%',
        position : 'absolute',
        bottom: 0,
        backgroundColor : 'white',
        height: 60 * metrics,
        shadowColor: '#809adc',
        shadowOffset: { width: 0, height: -2 },
        shadowOpacity: 0.4,
        shadowRadius: 7,
        elevation : 1  
    },
    disble_bottom : {
        backgroundColor : 'black',
    },
    user_body: {
        width: '100%',
    },
    review_title : {
        fontSize : 16 * metrics,
        marginTop : 10 * metrics,
        marginBottom : 10 * metrics,
        paddingBottom : 15 * metrics,
        paddingLeft : 10 * metrics , 
        paddingRight  : 10  * metrics,
        borderBottomWidth: 1,
        borderBottomColor : '#ececec'
    },
    user : {
        minHeight : 80 * metrics,
        width: '100%',
        flexDirection: 'row',
        marginTop:15 * metrics,
        marginBottom : 10 * metrics,
        alignSelf : 'center',
        borderBottomWidth: 1,
        borderBottomColor : '#ececec',
    },
    profile : {
        width : 50 * metrics,
        height: 50 * metrics,
        resizeMode : 'stretch',
        alignSelf : 'flex-start',
        marginTop : 4 * metrics,
        marginLeft: 10 * metrics,
        marginRight : 5 * metrics,
    },
    name: {
         flexDirection : 'column',
         alignItems: 'center',
         alignSelf : 'center',
         marginLeft : 5,
    },
    time : {
        fontSize : 11 * metrics,
        width : '100%',
        color: '#b1b1b1',
        marginTop: 10,
        marginBottom : 10
    },
    loading : {
      position : 'absolute',
      width : '100%',
      height : '100%',
      backgroundColor : 'black',
      opacity : 0.4
    },
    finish : {
        width : 0,
        height : 0,
        position : 'absolute'
    },
    checkin : {
        position : 'absolute', right : 10, top : 10 * metrics , fontSize : 20 * metrics, color : 'white'
    },
 })
export default PlaceReviewScreen