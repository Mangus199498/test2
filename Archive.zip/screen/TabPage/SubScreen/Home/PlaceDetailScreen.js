import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,ScrollView} from 'react-native';
import Star from 'react-native-star-view';
import global_style , {metrics}from '../../../../constants/globalStyles';
import { Input , Avatar} from 'react-native-elements';
import LoadingBar from '../../../../components/LoadingBar';
import { inject, observer } from 'mobx-react';
import { replaceTitle } from '../../../../utils/utils';

import PlanService from '../../../../services/plan.service';
import UserService from '../../../../services/user.service';

let _this = null

@inject ('userService')
@inject ('planService')
@observer



class PlaceDetailScreen extends Component {

    _planService : PlanService = this.props.planService;
    _userService : UserService = this.props.userService;

    constructor(props) {
        super(props)
        this.state = {
            starCount : 4,
            detail : null,
            isLoading : false,
            isChecked : false,
            rating_count : 0,
            img_idx : 0,
        }
    }
    
    componentWillUnmount() {
        this.unsubscribePlan()
    }

    componentWillMount () {
        var id = this.props.navigation.getParam('plan_id')
        this.setState({isLoading : true})
        _this = this
        this.unsubscribePlan = this._planService.getDataById(id).onSnapshot(function(result){
            if (result.exists) {
                var data = result.data()
                _this.setState({detail : data})
                _this.initRatingCount(data) //show rating count
                _this.initCheckin(data) //show checkin or no
                _this.props.navigation.setParams({
                    navTitle : data.address.name
                })
                _this.props.navigation.setParams({
                    avatar_img : global.user_info.img_url
                })
                _this.props.navigation.setParams({ profile : this.onClickedProfile})
                _this.setState({isLoading : false})
            }
        })
    }
    onClickedProfile = () => {
        this.props.navigation.navigate('MyInfoScreen');
    }
    checkeIn = () => {
        var id = this.state.detail.id;
        this.state.detail.checkin.push(global.user_info.uid);

        this._planService.updateData(this.state.detail.id, this.state.detail).then((res) => {
            this.props.navigation.navigate('PlaceReviewScreen', {place_id : id});  
        }).catch((error) => {
            console.log(error)
        })
    }
    clickedNext = ()=> {
        var id = this.state.detail.id;
        this.props.navigation.navigate('PlaceReviewScreen', {place_id : id});  
    }
    initRatingCount = (data) => {
        if (data.reviews.length > 0) {
            var count = 0;
            for (var i = 0; i < data.reviews.length ; i++) {
                count += data.reviews[i].rating_count    
            }
            this.setState({rating_count : count/data.reviews.length})
        }
    }
    initCheckin = (data) => {
        if (data != undefined && data.checkin.length > 0) {
            for(var i =0 ;i < data.checkin.length ; i++) {
                if (data.checkin[i] == global.user_info.uid) {
                    this.setState({isChecked : true})
                    break;
                }
            }
        }
    }

    onChangeImage = (index) => {
        this.setState({img_idx : index})
    }

    static navigationOptions = ({ navigation }) => {
        const { params = {} } = navigation.state;
        return {
            headerLeft: (
                <View style={global_style.navigation}>
                    <TouchableOpacity 
                        style={styles.backarrow}
                        onPress={() => navigation.goBack()} >
                            <Image source = {require('../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                            <Text style={global_style.back_title}>{params.navTitle}</Text>
                    </TouchableOpacity>
                </View>
            ),
            headerRight : (
                <TouchableOpacity 
                    style ={styles.backarrow}
                    onPress={() => _this.onClickedProfile()}>
                        <Avatar
                            rounded
                            overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                            size="xlarge"
                            source={{uri : params.avatar_img}}
                            resizeMode={'stretch'}
                            containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                            style = {styles.profile_img}
                        />
                </TouchableOpacity>
            ),
            headerStyle: global_style.headerHeight,
        };
    };
   render() {
      return (
        <View>
            <ScrollView bounces={false}>
                {
                    this.state.detail == null ? null :
                    <ScrollView scrollEnabled ={false}>
                        <Image source = {{uri : this.state.detail.address.photo_arr[this.state.img_idx]}} style={styles.bg_img}/>
                        {
                            this.state.isChecked ? <Text style={styles.checkin}>CHECKED IN</Text> : null
                        }
                        <View style = {styles.sub_body}>
                            <View style={styles.title}>
                                <Text style={{fontSize : 20 * metrics, fontWeight : '400'}}>{replaceTitle(this.state.detail.address.name)}</Text>
                                <View style={styles.star_rating}>
                                    <Star score={this.state.rating_count} style={global_style.starStyle}/>   
                                </View>
                            </View>
                            <View style={styles.title}>
                                <Text style={global_style.gray_title}>{this.state.detail.address.city_name.city_name} , {this.state.detail.address.city_name.country_name}</Text>
                            </View>
                            <ScrollView horizontal={true}>
                                <View style={styles.img_body}>
                                    {
                                        this.state.detail.address.photo_arr.map((element,index) => {
                                            return (
                                                <TouchableOpacity style={{flex : 1}} key={index} onPress={() => this.onChangeImage(index)}>
                                                    <View style = {global_style.image}>
                                                        <Image source = {{uri : element}} style={styles.place_img}></Image> 
                                                    </View>
                                                </TouchableOpacity>          
                                            );
                                        })
                                    }
                                </View>
                            </ScrollView>
                            <View style={styles.about}>
                                <Text style={styles.about_title}>About</Text>
                                <Text style={styles.about_description}>
                                    {this.state.detail.description} 
                                </Text>
                            </View>
                        </View>
                    </ScrollView>
                }
                {
                    !this.state.isChecked ?
                    <TouchableOpacity onPress={() => this.checkeIn()} style={!this.state.isLoading ? [global_style.cyan_btn, {marginTop : 18 * metrics,marginBottom : 10 * metrics,}] : {display :'none'}}>
                        <Text style={global_style.label}>Check in</Text>
                    </TouchableOpacity> 
                    :
                    <TouchableOpacity onPress={() => this.clickedNext()} style={!this.state.isLoading ? [global_style.cyan_btn,{marginTop : 18 * metrics,marginBottom : 10 * metrics,}] : {display :'none'}}>
                        <Text style={global_style.label}>Next</Text>
                    </TouchableOpacity> 
                }
                
            </ScrollView>
            <View style={this.state.isLoading ? global_style.loading : global_style.none}>
                <LoadingBar />
            </View>
        </View>
      )
   }
}
const styles = StyleSheet.create({
    wrapper : {
        width: '100%',
        height: 250 * metrics,
   },
    bg_img: {
         width: '100%',
         height: 250 * metrics,
    }, 
    img_body : {
        height : 130 * metrics,
        width: '100%',
        paddingTop : 10,
        flexDirection :'row',
    },
    backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%'
    },
    sub_body : {
        backgroundColor : 'black',
         width:'100%',
         backgroundColor : 'white',
         borderTopLeftRadius : 25 * metrics,
         borderTopRightRadius : 25 * metrics,
         marginTop: -20 * metrics,
         padding: 10 * metrics
    },
    title : {
        height : 'auto' , 
        width : '100%',
        flexDirection : 'row',
        paddingBottom: 0,
        marginTop : 10 * metrics,
        paddingLeft : 10 * metrics , 
        paddingRight  : 10  * metrics
    },   
    star_rating : {
        position : 'absolute',
        right: 10,
        width : '25%',
        alignItems : 'center',
        marginLeft : 20 * metrics,
        marginTop : 3 * metrics
    },
    about: {
        marginTop : 20 * metrics
    },
    about_title : {
        fontSize : 18 * metrics, 
        fontWeight : '400',
        paddingLeft : 10 * metrics , 
        paddingRight  : 10  * metrics
    }, 
    lock_icon : {
        width: 25 * metrics,
        height: 25 * metrics,
        resizeMode: "stretch",
        margin: 0,
        marginTop: -15 * metrics,
        marginRight : 5 * metrics, 
    },
    place_img : {
        borderRadius: 5,
        width: '100%',
        height: 110 * metrics,
        marginRight : 0, 
        resizeMode: "stretch",
        marginRight : 5
    },
    about_description : {
        padding : 3,
        color : 'gray',
        paddingLeft : 10 * metrics , 
        paddingRight  : 10  * metrics
    },
    cyan_btn : {
        width: '55%',
        height: 45 * metrics,
        borderRadius:40,
        alignItems: 'center',
        alignSelf : 'center',
        marginTop : 18 * metrics,
        marginBottom : 10 * metrics,
        backgroundColor: '#4f80ff',
        shadowColor: '#809adc',
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.4,
        shadowRadius: 7,  
        elevation : 3.5
    },
    label : {
        height: '100%',
        alignItems: 'center',
        alignSelf : 'center',
        fontSize: 20 * metrics,
        color: 'white',
        marginTop: 6,
    },
    checkin : {
        position : 'absolute', right : 10 * metrics, top : 10 * metrics, fontSize : 20 * metrics, color : 'white'
    },
    profile_img : {
        width : 37 * metrics, height : 37 * metrics,resizeMode :'stretch' , marginRight : 10 * metrics, marginTop : 10 * metrics
    }
 })
export default PlaceDetailScreen