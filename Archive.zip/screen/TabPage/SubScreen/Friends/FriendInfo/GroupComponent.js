import React, { Component } from "react";
import { Text, View, StyleSheet ,TouchableOpacity,Image, ScrollView, Dimensions} from "react-native";
import PropTypes from 'prop-types'
import UserService from '../../../../../services/user.service';
import GroupService from '../../../../../services/group.service';
import { replaceTitle } from '../../../../../utils/utils';
import { inject, observer } from "mobx-react";
import {metrics} from '../../../../../constants/globalStyles'

@inject ('userService')
@inject ('groupService')
@observer

class GroupComponent extends Component {

  _userService : UserService = this.props.userService
  _groupService : GroupService = this.props.groupService

  state = {
    group_arr : []
  }

  addGroup = () => {
    this.props.navigation.navigate('AddGroupScreen');
  }
  viewDetail = (item) => {
    var group_id = item.id
    this.props.navigation.navigate('GroupDetailScreen', {group_id : group_id});
  }

  componentWillUnmount () {
    this.unsubscribeGroup()
  }

  componentWillMount() {
    var _this = this;
    var user_id = this.props.user_id
    this.unsubscribeGroup = this._groupService.getGroupDataUID(user_id).onSnapshot(function(result) {
      const data = result.docs.map(doc => doc.data());
      _this.setState({group_arr : data})
    })  
  }
  render() {
     return (
        <View style={{width : '100%',paddingLeft : 10 * metrics, paddingRight : 10 * metrics, flex : 50,backgroundColor : '#e2e2e2'}} >
          <View style={{marginTop : 15 * metrics}}></View>
         <ScrollView>
          {
            this.state.group_arr.map((item, index) => {
              return (
                <TouchableOpacity style={styles.componentCard}  key={index}>
                  <Image source = {require('../../../../../assets/img/icon/img1.png')} style={styles.image}/>
                  <View style={styles.body}>
                    <Text style={styles.title}>{replaceTitle(item.title)}</Text>
                    <Text style={styles.gray_title}>Last message here</Text>
                    <View style={styles.icon_body}>
                        <Image source = {require('../../../../../assets/img/icon/ico_friend.png')} style={styles.icon_like}></Image>
                        <Text style={{marginTop : -3}}> {item.friends_arr.length}</Text>
                    </View>
                  </View>
                </TouchableOpacity>
              )
            })
          }
        </ScrollView>
       </View>
     )
  }
}
GroupComponent.propType = {
  user_id : PropTypes.string,
}
const styles = StyleSheet.create({
  container: {
    width : '100%',
    padding : 10 * metrics,
    overflow: 'scroll'
  },
  componentCard: {
    width : '100%',
    height: 110 * metrics,
    borderColor : '#e4e2e2',
    borderWidth : 1,
    shadowOpacity: 0.1,
    elevation : 2.5,
    borderRadius : 10,
    marginTop: 5 * metrics,
    marginBottom: 5 * metrics,
    flexDirection : 'row',
    backgroundColor : 'white'
  },
  image : {
    width : 100 * metrics,
    height : 100 * metrics,
    alignItems: 'center',
    alignSelf : 'center',
    marginLeft : 5 * metrics,
    borderRadius : 5 * metrics,
    marginRight : 0
  },
  body : {
    flexDirection: 'column',
    padding: 10 * metrics,
    marginTop : 7 * metrics
  },
  time : {
    flexDirection: 'row',
    marginTop : 8 * metrics
  },
  icon : {
    width : 15 * metrics,
    height : 15 * metrics,
    resizeMode : "stretch",
    margin : 'auto',
    marginLeft : 0,
    marginRight : 5 * metrics
  },
  title : {
    fontSize : 20 * metrics,
    fontWeight : '600',
    flexWrap: 'nowrap',
    width : 200 * metrics,
  },
  gray_title : {
    marginTop : 10 * metrics
  },
  icon_body : {
      marginTop: 10 * metrics,
      width: '100%',
      flexDirection: 'row',
  },
  icon_like : {
    width: 15 * metrics,
    height: 15 * metrics,
    marginTop : 1,
    resizeMode : "stretch"
  },
});

export default GroupComponent