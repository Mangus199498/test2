import React, { Component } from "react";
import { Text, View, StyleSheet ,TouchableOpacity, Image , Dimensions} from "react-native";
import global_style, { metrics } from  '../../../../../constants/globalStyles'

import FriendProfileComponent from './FriendProfileComponent';
import FeedComponent from './FeedComponent';
import GroupComponent from './GroupComponent';

import FriendService from '../../../../../services/friend.service';
import UserService from '../../../../../services/user.service';
import NotificationService from '../../../../../services/notification.service';

import { inject, observer } from 'mobx-react';

const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const ratioX = screenWidth / 360;
const ratioY = screenHeight / 896;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#bbbbbb",
    justifyContent: "center",
    alignItems: "center"
  },
  backarrow : {
    flex: 1,
    flexDirection : 'row',
    width: '100%'           
  },
  bottom : {
      flex : 10,
      width : '100%',
      paddingTop : 10,
      backgroundColor : '#e2e2e2'
  },
});
let _this=null;

@inject ('userService')
@inject ('friendService')
@inject ('notificationService')
@observer

class FriendInfoScreen extends Component {
    _userService : UserService = this.props.userService
    _friendService : FriendService = this.props.friendService
    _notificationService : NotificationService = this.props.notificationService

    constructor (props) {
        super(props)
        this.state = {
            isSelected : 1,
            isLoading : false,
            user_info : {},
            status : 0,
            isClicked : false
        }
    }
    
    onChangeState = (value) => {
        this.setState({isSelected : value});
    }
    addFriend = () => {
        if (this.state.isClicked) return;
        var obj = {
            uid : global.user_info.uid,
            friend_uid : this.state.user_info.uid,
            status : -1
        }
        var _this = this;
        this.setState({isClicked : true})
        this._friendService.inviteFriend(global.user_info.uid).then((result) => {
            const data = result.docs.map(doc => doc.data())[0];
            if (data == null) { // add database
                _this._friendService.addFriend(obj).then((res) => {
                    this.sendNotification(obj) // send notification    
                }).catch((error) => {
                    console.log(error)
                })
            } else {
                _this._friendService.updateFriend(data, obj).then((res) => {
                    this.sendNotification(obj) // send notifcation
                }).catch((error) => {
                    console.log(error)
                })
            }
        })
    }
    
    sendNotification(obj) {
        var noti_data = {
            type : 2, // invite friend
            is_read : 0,
            recv_uid : obj.friend_uid,
            send_uid : obj.uid,
            content : "invite friends",
            id : '',
            isAccepted : -1,
            isNotification : 0,
            time : new Date().getTime()
        }
        this._notificationService.addNotification(noti_data).then((result) => {
            _this.props.navigation.navigate('TabsPage')  
        }).catch((error) => {
            console.log(error)
        })
    }

    componentWillMount() {
        _this = this;
        var userInfo = this.props.navigation.getParam('data');
        this.setState({user_info : userInfo});
        this._friendService.getFriendSearchData(global.user_info.uid).then((result) => {
            console.log('currentUser = ' , global.user_info)
            const myFriendData = result.docs.map(doc => doc.data())[0];
            if (typeof(myFriendData) == 'undefined') {// no friend 
                this.setState({status : 0})
            } else {
                for(var i =0 ; i < myFriendData.friends_arr.length ; i++) {
                    if (myFriendData.friends_arr[i].uid == userInfo.uid) {
                        this.setState({status : myFriendData.friends_arr[i].status})
                        break;
                    }
                }
            }
        }).catch((error) => {
            console.log(error)
        })
        this.props.navigation.setParams({title: userInfo.f_name + " " + userInfo.l_name})
        
    }
    static navigationOptions = ({ navigation }) => {
        const { params = {} } = navigation.state; 
        return {
            headerLeft: (
                <View style={[global_style.navigation, {elevation : 3.5}]}>
                    <TouchableOpacity 
                        style={styles.backarrow}
                        onPress={() => navigation.goBack()} >
                            <Image source = {require('../../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                            <Text style={global_style.back_title}>{params.title}</Text>
                    </TouchableOpacity>
                </View>
            ),
            headerStyle: global_style.headerHeight,
        };
    };
    render() {
       return (
            <View style={{width: '100%', height: '100%'}}>
                {
                    <View style ={{flex : 100 , flexDirection : 'column'}}>
                        <FriendProfileComponent isSelected = {this.state.isSelected} onChangeState={this.onChangeState} userInfo={this.state.user_info}/>
                        {
                            this.renderComponent()
                            
                        }
                        {
                            this.state.status != 0 ? null :
                            <View style={this.state.status != 0? null : styles.bottom}>
                            {
                                <TouchableOpacity onPress={() => this.addFriend()} style={global_style.cyan_btn}>
                                    <Text style={global_style.label}>Add as friend</Text>
                                </TouchableOpacity>
                            }
                            </View>
                        }
                    </View>
                }
            </View>
       )
    }
    renderComponent() {
        if (this.state.isSelected == 1) {
            return <FeedComponent navigation={this.props.navigation} user_id = {this.state.user_info.uid}/>
        } else if (this.state.isSelected == 2) {
            return <GroupComponent navigation={this.props.navigation}  user_id = {this.state.user_info.uid}/>
        }
    }
 }

export default FriendInfoScreen
