import React, { Component } from "react";
import { Text, View, StyleSheet , Image,ScrollView,TouchableOpacity, Dimensions} from "react-native";
import PostService from '../../../../../services/post.service';
import PlanService from '../../../../../services/plan.service';
import UserService from '../../../../../services/user.service';
import { inject, observer } from "mobx-react";
import { replaceTitle } from '../../../../../utils/utils';
import { get_before_day } from '../../../../../utils/moment';
import PropTypes from 'prop-types'
import { isEmptyStatement } from "@babel/types";
import { metrics } from "../../../../../constants/globalStyles";

const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const ratioX = screenWidth / 360;
const ratioY = screenHeight / 896;

@inject ('postService')
@inject ('planService')
@inject ('userService')
@observer

class FeedComponent extends Component {

    _planService : PlanService = this.props.planService
    _postService : PostService = this.props.postService
    _userService : UserService = this.props.userService
    constructor (props) {
      super(props)
      this.state = {
        plan_arr : [],
        post_arr : [],
        user_id : ''
      }
    }
    componentWillMount() {
      //this.setState({user_id : this.props.user_id})
      //console.log(this.props.navigation.getParams('user_id'))
    }
    componentDidMount() {
      this.setState({user_id : this.props.user_id})
      this.getPostData(this.props.user_id)
      this.getPlanData(this.props.user_id)
    }

    componentWillUnmount() {
      this.unsubscribePlan()
      this.unsubscribePost()
    }

    async getPostData(user_id) { //init post data
      var temp_data = [];
        var _this = this;

        this.unsubscribePost = await this._postService.getAllDataByUID(user_id).onSnapshot(function(result){
          const data = result.docs.map(doc => doc.data());
          temp_data = data;
          temp_data.forEach((item) => {
            _this._userService.getUserData(item.uid).then((result) =>{
              if (result.exists) {
                item.uid = result.data();
              }
            })
          })
          _this.setState({post_arr : temp_data})
        })
    }
    async getPlanData(user_id) { //init plan data 
        var temp_data = [];
        var _this = this;

        this.unsubscribePlan = await this._planService.getAllDataByUID(user_id).onSnapshot(function(result){
          const data = result.docs.map(doc => doc.data());
          temp_data = data;
          temp_data.forEach((item) => {
            _this._userService.getUserData(item.uid).then((result) =>{
              if (result.exists) {
                item.uid = result.data();
              }
            })
          })
          _this.setState({plan_arr : temp_data})
        })
    }
    addpost = () => {
      this.props.navigation.navigate('AddPostScreen');
    }
    componentDidUpdate() {
     
    }
    viewDetail = (item, type) => {
      if (type == 1) {
        this.props.navigation.navigate('PlaceReviewScreen', {place_id : item.id});
      }
      else {
        this.props.navigation.navigate('PostDetailScreen', {post_id : item.id});
      }
    }
    render() {
       return (
         <View style={styles.main_view} >
           <ScrollView bounces={false}>
             <View style={{marginTop : 15 * metrics}}></View>
            {
              this.state.plan_arr.map((item ,index) => {
                return (
                  <TouchableOpacity style={styles.componentCard} key={index}>
                    <View style={{alignSelf : 'center'}}>
                      {
                        item.address.photo_arr.length > 0 ? 
                        <Image source = {{uri : item.address.photo_arr[0]}} style={styles.image}/>   : null
                      }
                      <Image source = {require('../../../../../assets/img/icon/trip_icon.png')} style={styles.trip_icon}/>
                    </View>
                    
                    <View style={styles.body}>
                      <Text style={styles.title} numberOfLines={1}>{item.address.name}</Text>
                      <View style={styles.time}>
                        <Image source = {require('../../../../../assets/img/icon/clock.png')} style={styles.icon}/>
                        {
                          get_before_day(item.time) == 0 ? 
                            <Text> Just ago </Text>
                            : <Text> { get_before_day(item.time)} days ago</Text>
                        }
                      </View>
                      <View style={styles.icon_body}>
                          <Image source = {require('../../../../../assets/img/icon/ico_like.png')} style={styles.icon_like}></Image>
                          <Text> 4</Text>
                          <Text>   </Text>
                          <Image source = {require('../../../../../assets/img/icon/ico-inbox.png')} style={styles.icon_inbox}></Image>
                          <Text> {item.comment.length}</Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                )
              })
            }
            {
              this.state.post_arr.map((item ,index) => {
                return (
                  <TouchableOpacity style={styles.componentCard} key={index}>
                    {
                      item.data_arr.length > 0 ? <Image source = {{uri : item.data_arr[0]}} style={styles.image}/> : null
                    }
                    <View style={styles.body}>
                      <Text style={styles.title} numberOfLines={1}>{replaceTitle(item.title)}</Text>
                      <View style={styles.time}>
                        <Image source = {require('../../../../../assets/img/icon/clock.png')} style={styles.icon}/>
                        {
                          get_before_day(item.time) == 0 ? 
                            <Text> Just ago </Text>
                            : <Text> { get_before_day(item.time)} days ago</Text>
                        }
                      </View>
                      <View style={styles.icon_body}>
                          <Image source = {require('../../../../../assets/img/icon/ico_like.png')} style={styles.icon_like}></Image>
                          <Text style={{alignSelf : 'center'}}> {item.favorite.length}</Text>
                          <Text>   </Text>
                          <Image source = {require('../../../../../assets/img/icon/ico-inbox.png')} style={styles.icon_inbox}></Image>
                          <Text style={{alignSelf : 'center'}}> {item.comment.length}</Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                  
                )
              })
            }
            
          </ScrollView>
         </View>
       )
    }
  }
FeedComponent.propType = {
  user_id : PropTypes.string,
}
 const styles = StyleSheet.create({
  main_view : {
    width : '100%',
    paddingLeft : 10, 
    paddingRight : 10, 
    flex : 50 , 
    backgroundColor : '#e2e2e2'
  },
  container: {
    width : '100%',
    padding : 10,
    overflow: 'scroll',
  },
  componentCard: {
    width : '100%',
    height: 110 * ratioX,
    elevation : 2.5,
    shadowOpacity : 0.1,
    borderRadius : 10,
    marginTop: 5,
    marginBottom: 5,
    flexDirection : 'row',
    backgroundColor : 'white'
  },
  image : {
    width : 100 * ratioX,
    height : 100 * ratioX, 
    alignItems: 'center',
    alignSelf : 'center',
    marginLeft : 5,
    borderRadius : 5,
    marginRight : 0
  },
  body : {
    flexDirection: 'column',
    padding: 10 * ratioX,
    marginTop : 7 * metrics
  },
  time : {
    flexDirection: 'row',
    marginTop : 8
  },
  icon : {
    width : 15 * ratioX,
    height : 15 * ratioX,
    resizeMode : "stretch",
    alignSelf : 'center'
  },
  title : {
    fontSize : 18 * ratioX,
    fontWeight : '600',
    overflow: "hidden",
    width : 200 * ratioX,
  },
  icon_inbox : {
    width: 15 * ratioX,
    height: 15 * ratioX,
    marginTop: 3,
    alignSelf : 'center',
    resizeMode : "stretch"
  },
  icon_body : {
      marginTop: 8 * ratioX,
      width: '100%',
      flexDirection: 'row',
  },
  icon_like : {
    width: 15 * ratioX,
    height: 15 * ratioX,
    marginTop: 3,
    alignSelf : 'center',
    resizeMode : "stretch"
   },
  trip_icon : {
    position: 'absolute', 
    width : 70 * ratioX,
    height : 20 * ratioX, 
    alignSelf : 'center', 
    bottom : 10, 
    resizeMode : 'stretch'
  }
});

export default FeedComponent
