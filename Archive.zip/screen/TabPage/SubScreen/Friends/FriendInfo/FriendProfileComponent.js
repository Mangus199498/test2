import React, { Component } from "react";
import { Text, View, StyleSheet,TouchableOpacity, Dimensions} from "react-native";
import PropTypes from 'prop-types'
import UserService from "../../../../../services/user.service";
import { inject, observer } from "mobx-react";
import { Input , Avatar} from 'react-native-elements';

const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const ratioX = screenWidth / 360;
const ratioY = screenHeight / 896;

@inject ('userService')
@observer

class FriendProfileComponent extends Component {
    _userService : UserService = this.props.userService
    state = {
        isSelected : 1,
        profile_img : '',
        user_name : ''
    }
    componentWillMount() {
        console.log(this.props.userInfo)
        var userInfo = this.props.userInfo
        this.setState({user_name : userInfo.f_name + ' ' + userInfo.l_name})
        this.setState({profile_img : userInfo.img_url})
    }
    onClickedTab = (value) => {
        this.props.onChangeState(value);
        this.setState({isSelected : value});
    }
    render() {
        return (
            <View style={styles.container}>
                <View style ={{flex : 100, flexDirection : 'column' , width : '100%'}}>
                    <View style={{flex : 5}}></View>
                    <View style ={{flex : 50, alignItems : 'center',justifyContent: 'center',}}>
                        <View>
                            <Avatar
                                rounded
                                overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                                size="xlarge"
                                source={{uri : this.state.profile_img}}
                                resizeMode={'stretch'}
                                containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                                style = {styles.profile_img}
                            />
                        </View>
                    </View>
                    <View style={{flex : 15 ,justifyContent: 'center'}}>
                        <View>
                            <Text style={styles.name}>{this.state.user_name}</Text>
                        </View>
                    </View>
                    <View style={{flex : 20}}>
                        <View style={styles.tabbar}>
                            <TouchableOpacity onPress={ ()=> this.onClickedTab(1)} style={this.state.isSelected == 1? styles.active : styles.non_active} >
                                <View style={{flex : 10}}>
                                    <View style={{flex : 4}}></View>
                                    <Text style={this.state.isSelected == 1 ? styles.active_text : styles.normal_text}>Feed</Text>
                                    <View style={{flex : 2}}></View>
                                </View>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={ ()=> this.onClickedTab(2)}  style={this.state.isSelected == 2? styles.active : styles.non_active} >
                                <View style={{flex : 10}}>
                                    <View style={{flex : 4}}></View>
                                    <Text style={this.state.isSelected == 2 ? styles.active_text : styles.normal_text}>Groups</Text>
                                    <View style={{flex : 2}}></View>
                                </View>
                            </TouchableOpacity>
                        </View>
                    </View>
                    
                </View>
                
                
                
            </View>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex : 30,
        width: '100%',
        backgroundColor: 'white',
        borderBottomWidth: 1,
        borderBottomColor : '#ececec',
        elevation : 10, 
        shadowOpacity : 0.8,
        shadowOffset : {width: 0, height : 5}
    },
    profile_img: {
        width: 100 * ratioX,
        height : 100 * ratioX,
        resizeMode : "stretch",
        alignSelf : 'center',
        justifyContent: 'center',
    },
    name : {
        fontSize: 18 * ratioX, 
        textAlign : "center",
        marginTop : 10,
    },
    tabbar : {
        flexDirection : 'row',
        height : '100%',
        
    },
    non_active : {
        width : '50%',
        borderBottomWidth: 2,
        marginBottom : 0,
        borderBottomColor: 'white'
    }, 
    active : {
        width : '50%',
        borderBottomWidth: 2,
        marginBottom : 0,
        borderBottomColor : '#4f80ff',
    },
    text: {
        width: '100%',
        alignItems: 'center',
        textAlign: 'center',
    },
    active_text: {
        color :'#4f80ff',
        width: '100%',
        alignItems: 'center',
        textAlign: 'center',
        fontSize : 17 * ratioX
    },
    normal_text : {
        color :'gray',
        width: '100%',
        alignItems: 'center',
        textAlign: 'center',
        fontSize : 17 * ratioX
    }
});

FriendProfileComponent.propType = {
    isSelected : PropTypes.number,
    onChangeState : PropTypes.func,
    userInfo : PropTypes.object
}
export default FriendProfileComponent
