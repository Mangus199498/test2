import React, { Component } from 'react';
import { View , Text, Image , StyleSheet, TouchableOpacity,ScrollView} from 'react-native';
import { Avatar} from 'react-native-elements';
import { replaceTitle } from '../../../../utils/utils'; 
import global_style , { metrics } from '../../../../constants/globalStyles';
import FriendService from '../../../../services/friend.service';
import UserService from '../../../../services/user.service';
import { inject, observer } from 'mobx-react';

@inject ('userService','friendService')
@observer

class FriendsScreen extends Component {

    _userService : UserService = this.props.userService
    _friendService : FriendService = this.props.friendService

    state = {
        friends_arr : []
    }
    friends_arr = [] //temp array
    componentDidMount() {
        this.getAllFriend()
    }

    onChangeState  = (val) => {
        if (val == '') {
            this.setState({friends_arr : this.friends_arr})
        } else {
            var temp_arr1 = [];
            for (var i = 0 ; i < this.friends_arr.length ; i++) {
                if(this.friends_arr[i].uid.f_name.toLowerCase().indexOf(val.toLowerCase())!=-1 || this.friends_arr[i].uid.l_name.toLowerCase().indexOf(val.toLowerCase())!=-1) {
                    temp_arr1.push(this.friends_arr[i]);
                }
            }
            this.setState({friends_arr : temp_arr1})
        }
    }
    componentWillUnmount() {
        this.unsubscribeFriend()
    }
    getAllFriend() {
        var _this = this;
        this.unsubscribeFriend = this._friendService.getFriendData(global.user_info.uid).onSnapshot(function(result) {
            const data = result.docs.map(doc => doc.data())
            var count = 0;
            if (data.length == 0) {
                _this.setState({friends_arr : []})
            } else {
                if (data[0].friends_arr.length > 0) {
                    data[0].friends_arr.forEach(element => {
                        _this._userService.getUserData(element.uid).then((result) => {
                            if (result.exists) {
                                element.uid = result.data()
                            }
                            count++;
                            if (count == data[0].friends_arr.length) {
                                _this.friends_arr = data[0].friends_arr
                                _this.setState({friends_arr : data[0].friends_arr})
                            }
                        })
                    });
                } else {
                    _this.friends_arr = []
                    _this.setState({friends_arr : []})
                }
            }
        })
    }
    onClickedFriends = (item) => {
        this.props.navigation.navigate('FriendInfoScreen', {data : item.uid});
    }
    render() {
        return (
            <ScrollView style={{height : '100%' , width : '100%'}} ref="myDiv"> 
                <View style={{marginTop : 15 * metrics}}></View>
                {
                    this.state.friends_arr.map((item, index) => {
                        return (
                            <TouchableOpacity style={global_style.friends_tile} onPress={ () => this.onClickedFriends(item)} key={index}>
                                <View style={styles.view}>
                                    <Avatar
                                        rounded
                                        overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                                        size="xlarge"
                                        source={{uri : item.uid.img_url}}
                                        resizeMode={'stretch'}
                                        containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                                        style = {styles.profile}
                                    />
                                    <Text style={styles.title}>{replaceTitle(item.uid.f_name + ' ' + item.uid.l_name)}</Text> 
                                    {
                                        item.status != -1 ?
                                            <Image source = {require('../../../../assets/img/icon/right_arrow.png')} style={styles.arrow_icon}/> 
                                        :
                                        <Image source = {require('../../../../assets/img/icon/btn_send.png')} style={styles.right_img}></Image>
                                    }
                                    
                                </View>
                            </TouchableOpacity>
                        )
                    })   
                }
            </ScrollView>
        )
    }
}
const styles = StyleSheet.create({
    view: {
        flexDirection : 'row',
        height: '100%',
        width: '100%',
        alignItems : 'flex-start'
    },  
    title : {
        alignItems: 'flex-start',
        alignSelf : 'center',
        marginLeft: 0,
        fontSize : 20  * metrics
    },
    arrow_icon : {
        width : 13 * metrics,
        height : 18 * metrics,
        resizeMode : 'stretch',
        alignSelf : 'center',
        position : 'absolute',
        right : 10
    },
    profile: {
        width : 50 * metrics,
        height: 50 * metrics,
        resizeMode : "stretch",
        borderRadius : 100,
        alignSelf : 'center',
        marginLeft: 15 * metrics,
        marginRight: 15 * metrics,
    },
    right_img: {
        alignItems: 'flex-end',
        alignSelf : 'center',
        marginRight : 10 * metrics,
        width: 100 * metrics,
        height: 25 * metrics,
        resizeMode: 'stretch',
        position : 'absolute',
        right : 5 * metrics,
    }
})
export default FriendsScreen