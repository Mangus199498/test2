import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,TextInput,ScrollView, Dimensions} from 'react-native';
import global_style , {metrics}from '../../../../constants/globalStyles';
import FaqService from '../../../../services/faq.service';
import { inject, observer } from 'mobx-react';
import Textarea from 'react-native-textarea';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
@inject ('faqService')
@observer

class FaqScreen extends Component {
    _faqService : FaqService = this.props.faqService

   static navigationOptions = ({ navigation }) => {
      return {
          headerLeft: (
              <View style={global_style.navigation}>
                  <TouchableOpacity 
                      style={styles.backarrow}
                      onPress={() => navigation.goBack()} >
                          <Image source = {require('../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                          <Text style={global_style.back_title}>FAQ</Text>
                  </TouchableOpacity>
              </View>
          ),
          headerStyle: global_style.headerHeight,
      };
   };
   state = {
      question : '',
      userInfo : null,
      faq_arr : []
   }
   componentWillMount () {
        this.reloadData();
   }
   reloadData() {
        this._faqService.getFaqData().then((result) => {
            const data = result.docs.map(doc => doc.data());
            this.setState({faq_arr : data});
        })
   }
   submitFaq = () => {
        if (this.state.question == '')
           return;

        var obj = {
            question : this.state.question,
            date : new Date()
        }

        this._faqService.addFaqData(obj).then((result) => {
            this.setState({question : ''});
            this.reloadData();
        }).catch((error) => {
            console.log(error)
        })
   } 
   render() {
        return (
            <View style={{width: '100%', height : '100%',backgroundColor : '#f1f6f9'}}>
                <KeyboardAwareScrollView
                    resetScrollToCoords={{ x: 0, y: 0 }}
                    contentContainerStyle={{flex : 1}}
                    scrollEnabled={false}
                >
                <ScrollView style={{marginBottom : 155 * metrics}}>
                    { 
                        this.state.faq_arr.map((item, index) => {
                            return (
                                <View style={styles.body} key={index}>
                                    <View style={styles.item}>
                                        <Text style={styles.title}>Question { index + 1 } :</Text>
                                        <Text style={styles.description}> { item.question }</Text>
                                    </View>
                                </View>  
                            );
                        })
                    }
                </ScrollView>
                
                <View style={styles.bottom}> 
                    <View style={styles.question}>
                        <Text style ={{marginBottom : 5 * metrics}}>Do you have a question ? </Text>
                        
                        <Textarea
                            style={global_style.faq_textarea}
                            defaultValue={this.state.text}
                            placeholder={'Ask your question'}
                            value= {this.state.question}
                            placeholderTextColor={'#c7c7c7'}
                            underlineColorAndroid={'transparent'}
                            onChangeText={(text) => this.setState({question : text})}
                        />
                    </View>
                    <View style={styles.submit}>
                        <TouchableOpacity onPress={() => this.submitFaq()} style={global_style.cyan_btn}>
                            <Text style={global_style.label}>Submit</Text>
                        </TouchableOpacity>
                    </View> 
                </View>
                </KeyboardAwareScrollView>
            </View>
        )
   }
}
const styles = StyleSheet.create({
    body: {
        width: '100%',
        flexDirection: 'column'
    },
    item: {
        margin: 15 * metrics,
        flexDirection: 'column'
    },
    backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%'
    },
    title : {
        fontSize : 16 * metrics,
        color : '#3a3939',
        fontWeight : '600'
    },
    description : {
        fontSize : 13 * metrics,
        color : '#777676',
        marginTop : 5 * metrics
    },
    bottom: {
        position : 'absolute', //made by martin
        bottom: 0,
        width: '100%',
        height : 165 * metrics,
        backgroundColor : 'white',
        shadowOpacity : 0.1,
        elevation : 1.0,
        shadowOffset : { width : 0, height : -4 }
    },  
    question : {
        height : '100%',
        margin: 10 * metrics,
        padding : 10 * metrics,
        paddingBottom: 0,
        paddingTop: 0,
        marginBottom : 0
    },
    submit: {
        position : 'absolute',
        bottom : 5,
        width : '100%',
    }
})
export default FaqScreen