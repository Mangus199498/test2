import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,Modal, WebView, Dimensions} from 'react-native';
import global_style from  '../../../../constants/globalStyles';
import { CreditCardInput, LiteCreditCardInput } from "react-native-credit-card-input";
//import PayPal from 'react-native-paypal-wrapper';
import Stripe from 'react-native-stripe-api';
import RNPaypal from 'react-native-paypal-lib';

import CardService from '../../../../services/card.service';
import UserService from '../../../../services/user.service';

import LoadingBar from '../../../../components/LoadingBar';
import { inject, observer } from 'mobx-react';

import Toast from 'react-native-simple-toast';

const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const ratioX = screenWidth / 360;
const ratioY = screenHeight / 896;

@inject ('cardService')
@inject ('userService')
@observer

class PaymentScreen extends Component {
    _userService : UserService = this.props.userService
    _cardService : CardService = this.props.cardService

    state = {
        starCount : 4,
        height : 0,
        showModal : false,
        card_obj : null,
        card_arr : [],
        isLoading : false
    }

    componentWillUnmount() {
        this.unsubscribeCard()
    }

    componentWillMount () {
        var _this = this
        this.unsubscribeCard = this._cardService.getCardData(global.user_info.uid).onSnapshot(function(result){
            const data = result.docs.map(doc => doc.data());
            _this.setState({card_arr : data})
        })
    }

    static navigationOptions = ({ navigation }) => {
        return {
            headerLeft: (
                <View style={global_style.navigation}>
                    <TouchableOpacity 
                        style={styles.backarrow}
                        onPress={() => navigation.goBack()} >
                            <Image source = {require('../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                            <Text style={global_style.back_title}>PAYMENT</Text>
                    </TouchableOpacity>
                </View>
            ),
            headerStyle: global_style.headerHeight
        };
    };
    onClickedPaypal =() =>{
        RNPaypal.paymentRequest({
            clientId: 'AUIWCY5Uvc13kZ46ZnPiMMXz5wgCcdcWDW3TEezqUSmjdVle1RVb6oMh4KVlut8bNBlBwTDC6SzgwQTm',
            environment: RNPaypal.ENVIRONMENT.NO_NETWORK,
            intent: RNPaypal.INTENT.SALE,
            price: 9.99,
            currency: 'USD',
            description: `Your membership is updating...`,
            acceptCreditCards: true
        }).then(result => {
            global.user_info.membership = 'premium'
            this._userService.updateUser(global.user_info).then((result) => {
                Toast.show('Your membership has been updated!', Toast.LONG);
                console.log(result)
            }).catch((error) => {
                Toast.show(error.message, Toast.LONG)
            })
        }).catch(err => {
            // alert(err.message)
            // Toast.show(err.message, Toast.LONG)
        })
    }
    async makeStripePayment(token) {
        const uri = 'https://stark-cove-10185.herokuapp.com/paystripe/';
        const obj = {
            amount: '9.99',
            stripetoken: token
        };
        const response = await fetch(uri, {
            method: 'POST',
            body: JSON.stringify(obj),
            headers: {
                'Content-Type': 'application/json'
            }
        });
        return response.json();
    }
    payByCard = async(element) => {
        const apiKey = 'pk_test_dRRHj8oGI0kouK73pJjKDjqT00ZWev64YY';
        const client = new Stripe(apiKey);
        var info = {
            //number : '4242 4242 4242 4242',
            number : element.number,//'4242 4242 4242 4242', this is test api
            exp_month : element.expiry.split('/')[0],
            exp_year : element.expiry.split('/')[1],
            cvc: element.cvc
        } //test
        this.setState({isLoading : true})
        //Create a Stripe token with new card infos
        try {
            const token = await client.createToken(info);
            this.makeStripePayment(token.id).then((result) => {
                if (result == true) { //success
                    global.user_info.membership = 'premium'
                    this._userService.updateUser(global.user_info).then((result) => {
                        this.setState({isLoading : false})
                        this.props.navigation.navigate('UpgradePlanScreen');
                        Toast.show('Your membership has been updated!', Toast.LONG);
                    }).catch((error) => {
                        this.setState({isLoading : false})
                        Toast.show("Your membership hasn't been updated!", Toast.LONG);
                    })
                } else {
                    this.setState({isLoading : false})
                    Toast.show("Your membership hasn't been updated!", Toast.LONG);
                }
            }).catch((error) => {
                this.setState({isLoading : false})
                Toast.show("Card number is not exist.", Toast.LONG);
            })
        } catch(error) {
            this.setState({isLoading : false})
            Toast.show("Card number is not exist.", Toast.LONG);
        }
    }
    onClickedCard = () => {
        this.setState({showModal : true})
    }
    
    _onChange = (form) => { //this is change card input func
        var obj = form.values;
        this.setState({card_obj : obj})
    }

    onClickedSaveBtn = () => { //this is add card func
        this.state.card_obj.uid = global.user_info.uid
        this._cardService.addCard(this.state.card_obj).then((result) => {
            this.setState({showModal : false})
        }).catch((error) => {
            console.log(error)
        })
    }
    render() {
      return (
        <View>
            <View style={{width: '100%', height: '100%',backgroundColor : '#f1f6f9'}}>
                <Modal 
                    visible = {this.state.showModal}
                    onRequestClose = {()=> this.setState({showModal : false})}>
                    <View style={{marginTop : 100 * ratioX}}>
                        <CreditCardInput onChange={this._onChange} />
                    </View>
                    <TouchableOpacity onPress={() => this.onClickedSaveBtn()} style={styles.cyan_btn}>
                    <Text style={styles.label}>SAVE</Text>
                </TouchableOpacity>
                </Modal>
                <View style={styles.paybody}>
                    <Text style={{marginBottom : 5* ratioX, marginLeft: 10* ratioX}}>Payment Methods</Text>
                    {
                        this.state.card_arr.map((element, idx) => {
                            console.log(element)
                            return (
                                <TouchableOpacity style = {styles.plan_body} key={idx} onPress={()=> this.payByCard(element)}>
                                    <Image source = {require('../../../../assets/img/icon/icon_plan.png')} style={styles.plan}></Image>
                                    <Text style={styles.card_label}> {element.number.slice(element.number.length -4, element.number.length)}</Text>
                                    <View></View>
                                    <Image source = {require('../../../../assets/img/icon/right_arrow.png')} style = {styles.rightarrow}/> 
                                </TouchableOpacity>
                            )   
                        })
                    }
                    <TouchableOpacity onPress={()=> this.onClickedPaypal()} style = {styles.paypal}>
                        <Image source = {require('../../../../assets/img/icon/icon_paypal.png')} style={styles.paypal_img}></Image>
                        <Image source = {require('../../../../assets/img/icon/right_arrow.png')} style = {styles.rightarrow}/> 
                    </TouchableOpacity>
                </View>

                <View style={styles.paybody}>
                    <Text style={{marginBottom : 5* ratioX, marginLeft: 10* ratioX}}>Add New Card</Text>
                    <TouchableOpacity style = {styles.card_body} onPress={()=> this.onClickedCard()}>
                        <Image source = {require('../../../../assets/img/icon/icon_card.png')} style={styles.card}></Image>
                        <Text style={styles.card_label}> Add Card</Text>
                        <Image source = {require('../../../../assets/img/icon/right_arrow.png')} style = {styles.rightarrow}/> 
                    </TouchableOpacity>
                </View>
            </View>
            <View style={this.state.isLoading ? styles.loading : styles.finish}>
                <LoadingBar/>
            </View>
        </View>
        
      )
   }
}
const styles = StyleSheet.create({
    paybody : {
        width : '100%',
        flexDirection : 'column',
        marginTop : 20* ratioX,
        marginBottom : 10* ratioX,
        
    },
    plan_body : {
        width : '100%',
        height : 50* ratioX,
        flexDirection: 'row',
        borderTopColor : '#e0e0e0',
        borderBottomColor : '#e0e0e0',
        borderTopWidth : 1,
        borderBottomWidth : 1,
        backgroundColor : 'white'
    },
    paypal : {
        width : '100%',
        height : 50* ratioX,
        flexDirection: 'row',
        borderTopColor : '#e0e0e0',
        borderBottomColor : '#e0e0e0',
        borderBottomWidth : 1,
        backgroundColor : 'white'
    },
    plan : {
        width : 65* ratioX,
        height : 17* ratioX,
        resizeMode : "stretch",
        alignItems: 'center',
        alignSelf : 'center',
        marginLeft : 10* ratioX,
        marginRight : 10* ratioX,
    },
    card_body : {
        width : '100%',
        height : 50* ratioX,
        flexDirection: 'row',
        borderTopColor : '#e0e0e0',
        borderBottomColor : '#e0e0e0',
        borderTopWidth : 1,
        borderBottomWidth : 1,
        backgroundColor : 'white'
    },
    card_label : {
        alignItems: 'center',
        alignSelf : 'center',
        marginLeft : 0,
        marginRight : 0,
    },
    paypal_img : {
        width : 75* ratioX,
        height : 22* ratioX,
        resizeMode : "stretch",
        alignItems: 'center',
        alignSelf : 'center',
        marginLeft : 10* ratioX,
        marginRight : 10* ratioX
    },
    card : {
        width : 25* ratioX,
        height : 20* ratioX,
        resizeMode : "stretch",
        alignItems: 'center',
        alignSelf : 'center',
        marginLeft : 10* ratioX,
        marginRight : 10* ratioX
    },
    card_label : {
        alignItems: 'center',
        alignSelf : 'center',
        marginLeft : 0,
        marginRight : 0,
        color : '#4870d4'
    },
    backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%'
    },
    rightarrow : {
        width : 13* ratioX, height : 15* ratioX, alignItems: 'center', marginRight : 5* ratioX, position : 'absolute', right: 5* ratioX, alignSelf : 'center'
    },
    cyan_btn : {
        width: '55%',
        height: 45* ratioX,
        borderRadius: 40,
        alignItems: 'center',
        alignSelf : 'center',
        backgroundColor: '#4f80ff',
        elevation : 3.5,
        marginTop : 50 * ratioX,
        // position : 'absolute',
        // bottom : 20* ratioX
    },
    label : {
        height: '100%',
        alignItems: 'center',
        fontSize: 18 * ratioX,
        color: 'white',
        marginTop: 10 * ratioX,
    },
    loading : {
      position : 'absolute',
      width : '100%',
      height : '100%',
      backgroundColor : 'black',
      opacity : 0.4
   },
   finish : {
      width : 0,
      height : 0,
      position : 'absolute'
   },
})
export default PaymentScreen