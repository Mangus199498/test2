import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,TextInput,ScrollView,Dimensions} from 'react-native';
import global_style , { metrics } from  '../../../../constants/globalStyles';
import UserService from '../../../../services/user.service';
import { inject, observer } from 'mobx-react';
import { encryptString , decryptString} from '../../../../utils/utils';
import LoadingBar from '../../../../components/LoadingBar';

@inject('userService')
@observer

class ChangePassword extends Component {
    _userService : UserService = this.props.userService;

    state = {
        old_password: '',
        password : '',
        new_password : '',
        confirm_password : '',
        btn_flag : false,
        isLoading : false
    }
    componentWillMount () {
        this.setState({old_password : decryptString(global.user_info.token)})
    }

    onClickedSaveBtn = () => {
        this.setState({btn_flag : true});
        if (this.state.old_password != this.state.password) {
            console.log('password1')    
            return;
        }
        if (this.state.new_password.length < 6 || this.state.new_password != this.state.confirm_password || this.state.confirm_password.length < 6) {
            console.log('password2 = ' , this.state.new_password + " " + this.state.confirm_password)
            return;
        }
        this.setState({isLoading : true})
        this._userService.changePassword(this.state.new_password).then((result) => {
            var obj = {
                uid : global.user_info.uid,
                f_name : global.user_info.f_name,
                l_name : global.user_info.l_name,
                email : global.user_info.email,
                phone_number : global.user_info.phone_number,
                img_url : global.user_info.img_url,
                token : encryptString(this.state.new_password),
                gender : global.user_info.gender
            }
            this._userService.updateUser(obj).then((res) => {
                //this.setState({btn_flag : false})
                this.getUserData();
             }).catch((error) => {
                 this.setState({isLoading : false})
                //alert(JSON.stringify(error))
             })
            
        }).catch((error) => {
            console.log(error)
        })
    }
    getUserData() {
        this._userService.getUserData(global.user_info.uid).then((result) => {
            if (result.exists) {
                global.user_info = result.data();
                this.setState({isLoading : false})
                this.props.navigation.navigate('TabsPage');
            }
        }).catch((error) => {
            console.log(error)
            this.setState({isLoading : false})
        })
    }
    static navigationOptions = ({ navigation }) => {
        return {
            headerLeft: (
                <View style={global_style.navigation}>
                    <TouchableOpacity 
                        style={styles.backarrow}
                        onPress={() => navigation.goBack()} >
                            <Image source = {require('../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                            <Text style={global_style.back_title}>CHANGE PASSWORD</Text>
                    </TouchableOpacity>
                </View>
            ),
            headerStyle: global_style.headerHeight,
        };
    };
   render() {
      return (
        <View style={{width: '100%', height :'100%'}}>
            <ScrollView style={styles.body} bounces = {false}>
                <Text style={styles.sub_title}>Password</Text>
                <TextInput 
                    underlineColorAndroid = "transparent"
                    placeholder = ""
                    placeholderTextColor = "gray"
                    autoCapitalize = "none"
                    secureTextEntry={true} 
                    value= {this.state.password}
                    onChangeText={(text) => this.setState({password : text})}
                    style={global_style.name_input}/>
                <Text style={(this.state.btn_flag && this.state.password.length < 6) ? styles.error : styles.non_error}> Password must be at least 6 characters long.</Text>
                <Text style={(this.state.btn_flag && (this.state.old_password != this.state.password) && (this.state.password.length > 6 && this.state.old_password.length > 6))  ? styles.error : styles.non_error}> Mismatch old password. Please check it.</Text>

                <Text style={styles.sub_title}>New Password</Text>
                <TextInput 
                    underlineColorAndroid = "transparent"
                    placeholder = ""
                    placeholderTextColor = "gray"
                    autoCapitalize = "none"
                    secureTextEntry={true} 
                    value= {this.state.new_password}
                    onChangeText={(text) => this.setState({new_password : text})}
                    style={global_style.name_input}/>
                <Text style={(this.state.btn_flag && this.state.new_password.length < 6) ? styles.error : styles.non_error}> New password must be at least 6 characters long.</Text>

                <Text style={styles.sub_title}>Confirm Password</Text>
                <TextInput 
                    underlineColorAndroid = "transparent"
                    placeholder = ""
                    placeholderTextColor = "gray"
                    autoCapitalize = "none"
                    secureTextEntry={true} 
                    value= {this.state.confirm_password}
                    onChangeText={(text) => this.setState({confirm_password : text})}
                    style={global_style.name_input}/>
                <Text style={(this.state.btn_flag && this.state.confirm_password.length < 6) ? styles.error : styles.non_error}> Confirm Password must be at least 6 characters long.</Text>
                <Text style={(this.state.btn_flag && (this.state.confirm_password != this.state.new_password) && (this.state.new_password.length > 0 && this.state.confirm_password.length > 0))  ? styles.error : styles.non_error}>Mismatch confirm password. Please check it.</Text>

                
            </ScrollView>
            <View style={global_style.bottom}>
                    <View style={{flex : 2.5}}></View>
                    <TouchableOpacity onPress={() => this.onClickedSaveBtn()} style={global_style.cyan_btn}>
                        <Text style={global_style.label}>Save</Text>
                    </TouchableOpacity>
                    <View style={{flex : 2.5}}></View>
                </View>
            <View style={this.state.isLoading ? styles.loading : styles.finish}>
                <LoadingBar/>
            </View>
        </View>
      )
   }
}
const styles = StyleSheet.create({
    body: {
        flexDirection : 'column',
        borderRadius: 10,
        margin : 10 * metrics,
        padding: 10 * metrics,
        paddingTop : 20  * metrics,
        height : '100%',
        width: '95%',
        shadowColor: '#dadada',
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.4,
        shadowRadius: 7,  
    },
    sub_title : {
        marginTop : 10 * metrics,
    },
    backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%'
    },
    bottom: {
        width: '100%',
        height : 60 * metrics,
        backgroundColor : 'white',
        shadowOffset : { width : 0, height : -10},
        shadowColor : '#e2e2e2',
        shadowRadius : 20,
        shadowOpacity : 0.7,
        marginTop: 60 * metrics,
        marginBottom : 20 * metrics
    },
    error : {
        color : 'red',
        fontSize : 13 * metrics
     }, 
     non_error : {
        display : 'none'
     },
    cyan_btn : {
        width: '60%',
        height: 45 * metrics,
        borderRadius: 40,
        alignItems: 'center',
        alignSelf : 'center',
        backgroundColor: '#4f80ff', 
        elevation : 3.5
    },
    label : {
        height: '100%',
        alignItems: 'center',
        fontSize: 18 * metrics,
        color: 'white',
        marginTop: 10 * metrics,
    },
    loading : {
      position : 'absolute',
      width : '100%',
      height : '100%',
      backgroundColor : 'black',
      opacity : 0.4
   },
   finish : {
      width : 0,
      height : 0,
      position : 'absolute'
   },
})
export default ChangePassword