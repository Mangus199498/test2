import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,TextInput, ScrollView,Alert, Platform, TouchableHighlight, KeyboardAvoidingView} from 'react-native';
import global_style , { metrics } from  '../../../../constants/globalStyles';
import UserService  from '../../../../services/user.service';
import StorageService from '../../../../services/storage.service';
import { observer ,inject} from 'mobx-react';
import { Input , Avatar} from 'react-native-elements';
import ImagePicker from 'react-native-image-crop-picker';
import PhoneInput from 'react-native-phone-input';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import LoadingBar from '../../../../components/LoadingBar';
import { removePlusCharacter } from '../../../../utils/utils'
import checkImg from '../../../../assets/img/icon/ico_checked.png';
import unCheckImg from '../../../../assets/img/icon/ico_uncheck.png';


@inject ('userService')
@inject ('storageService')
@observer

class EditProfileScreen extends Component {

   _userService : UserService = this.props.userService;
   _storageSevice : StorageService =  this.props.storageService

   static navigationOptions = ({ navigation }) => {
      return {
          headerLeft: (
            <View style={global_style.navigation}>
                  <TouchableOpacity 
                      style={styles.backarrow}
                      onPress={() => navigation.goBack()} >
                          <Image source = {require('../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                          <Text style={global_style.back_title}>EDIT MY PROFILE</Text>
                  </TouchableOpacity>
              </View>
          ),
          headerStyle: global_style.headerHeight
      };
   };
   state = {
      userInfo : null,
      f_name: '',
      l_name: '',
      phone_number: '',
      email: '',
      avatar_url : '',
      check1: '',
      check2: '',
      gender : '0',
      imgData : null,
      btn_flag : false,
      country_code : '+1',
      phone_valid : '',
      email_valid : '',
      enable : true
   }
   componentWillMount () {
      this.setState({btn_flag : false});
      this.setState({userInfo : global.user_info});
      this.setState({f_name: global.user_info.f_name})
      this.setState({l_name: global.user_info.l_name})
      this.setState({email: global.user_info.email})
      this.setState({country_code : global.user_info.country_code})
      this.setState({phone_number : global.user_info.country_code + ' ' + global.user_info.phone_number})
      this.setState({avatar_url: global.user_info.img_url})
      this.setState({gender : global.user_info.gender})
      this.setState({validate : { phone : global.user_info.phone_number, email : true} })
      this.setState({check1 : global.user_info.gender == '0' ? checkImg : unCheckImg})
      this.setState({check2 : global.user_info.gender == '1' ? checkImg : unCheckImg})
      this.setState({email_valid : true})
      this.setState({phone_valid : true})
      if (global.user_info.google || global.user_info.fb || global.user_info.twitter) {
         this.setState({enable : false})
      }
   }
   //phone
   changeMobileNumber = (value) => {
      this.setState({phone_valid : this.phone.isValidNumber()})
      this.setState({country_code : '+' + this.phone.getCountryCode()})
      this.setState({phone_number : value})
  }
   onCheckBox = (value) =>{
      this.setState({gender : value})
      if (value == 0) {
         this.setState({check1 : checkImg})
         this.setState({check2 : unCheckImg})
      } else {
         this.setState({check1 : unCheckImg})
         this.setState({check2 : checkImg})
      }
      console.log(this.state.gender)
   }
   updateProfile = () => {
      this.setState({btn_flag : true})
      var phone_num = removePlusCharacter(this.state.phone_number , this.state.country_code)
      this.setState({phone_number : phone_num})
      if (!this.validation())
         return;
      this.setState({isLoading : true})
      var obj = {
         f_name : this.state.f_name,
         l_name : this.state.l_name,
         email : this.state.email,
         gender : this.state.gender,
         phone_number : phone_num,
         country_code : this.state.country_code,
         img_url : '',
         uid : global.user_info.uid
      }
      if (global.user_info.google || global.user_info.fb || global.user_info.twitter) {
         this.updateData(obj)
         return;
      }
      if (this.state.email != global.user_info.email) { //change email
         this._userService.changeEmail(this.state.email).then((result) => {
            this.updateData(obj)
         }).catch((error) => {
            this.setState({isLoading : false})
            Alert.alert(  
               '',  
               error.message,  
               [  
                  {text: 'OK', onPress: () => console.log('Ask me later pressed')},                     
               ],  
               {cancelable: false}  
           )  
         })
      } else {
         this.updateData(obj)
      }
   } 
   validation() {
      if (global.user_info.google || global.user_info.fb || global.user_info.twitter) {
         if (this.state.l_name == '' || this.state.f_name == '' || this.state.phone_number == '') {
            return false;
         } else {
            return true;
         }
      } else {

         if (this.state.email != '' && this.state.email_valid && this.state.l_name != '' && this.state.f_name != '' && this.state.phone_number != '' && this.state.phone_valid) {
            return true;
         } else {
            
            return false;
         }
      }
   }
   validateText = (text) => {
      let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;
      if(reg.test(text) === false)
      {
         this.setState({email_valid : false})
         this.setState({email:text})
         return false;
      }
      else {
         this.setState({email_valid : true})
         this.setState({email:text})
      }
   }
   setPhoneNumber = (value) => {
      this.setState({validate : { phone : value, email : this.state.validate.email} })
   }

   updateData(obj) {
      
      if (this.state.imgData == null) {
         if (this._userService.google || global.user_info.fb || global.user_info.twitter) {
            obj.email = global.user_info.email
         }
         obj.img_url = this.state.avatar_url;
         this._userService.updateUser(obj).then((res) => {
            this.getUserData();
            this.setState({isLoading : false})
         }).catch((error) => {
            this.setState({isLoading : false})
         })
      } else {

         this._storageSevice.uploadAvatarImage(global.user_info.uid, this.state.imgData).then((data) => {
            obj.img_url = data.url;
            this._userService.updateUser(obj).then((res) => {
               this.setState({isLoading : false})
               this.getUserData();
            }).catch((error) => {
               this.setState({isLoading : false})
            })
         }).catch((error) => {
            this.setState({isLoading : false})
         })
      }
   }

   getUserData() {
      this._userService.getUserData(global.user_info.uid).then((result) => {
         if (result.exists) {
             global.user_info = result.data();
             this.props.navigation.navigate('TabsPage');
         }
     }).catch((error) => {
         console.log(error)
     })
   }
   selectedCamera =()=> {
      ImagePicker.openCamera({
         width: 300,
         height: 400,
         cropping: true,
      }).then(image => {
         this.setState({imgData : image})
         let source = {uri : image.path}
         this.setState({
            avatar_url: source,
         });
      }).catch((error) => {
         console.log(error)
      });
   }
   selectedGallery = () => {
      ImagePicker.openPicker({
         width: 300,
         height: 400,
         cropping: true,
      }).then(image => {
         this.setState({imgData : image})
         let source = {uri : image.path}
         this.setState({
            avatar_url: source,
         });
      }).catch((error) => {
         console.log(error)
      });
   } 
   selectPhotoTapped = () => {
      Alert.alert(  
            'Avatar',  
            'Select your photo',  
            [  
                {text: 'Cancel', onPress: () => console.log('Ask me later pressed')},  
                {text: 'Camera',onPress: () => this.selectedCamera()},  
                {text: 'Gallery', onPress: () => this.selectedGallery()},  
            ],  
            {cancelable: false}  
        )  
   }
   render() {
      return (
         <View style={{width : '100%' , height : '100%'}}>
            <KeyboardAwareScrollView
               resetScrollToCoords={{ x: 0, y: 0 }}
               contentContainerStyle={{flex : 1}}
               scrollEnabled={false}
            >
            <ScrollView style={{width: '100%',height : '100%',  backgroundColor : '#f7fcff'}} bounces={false} >
               <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "position" : null}>
                  <View style={styles.profile}>
                     <TouchableOpacity onPress={()=> this.selectPhotoTapped()} style={{width : '50%', alignSelf : 'center'}}>
                        {
                           this.state.imgData == null ? <Avatar
                              rounded
                              size="xlarge"
                              source={{uri : this.state.avatar_url}}
                              resizeMode={'stretch'}
                              containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                              style = {{width : 130 * metrics, height : 130 * metrics, alignSelf : 'center', elevation : 10}}
                           /> 
                           :
                           <Avatar
                              rounded
                              size="xlarge"
                              source={this.state.avatar_url}
                              resizeMode={'stretch'}
                              containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                              style = {{width : 130 * metrics, height : 130 * metrics, alignSelf : 'center', elevation : 10}}
                           />
                        }
                     <Image source = {require('../../../../assets/img/icon/ico_camera.png')} style={styles.camera}/> 
                     </TouchableOpacity>
                  </View>
                  <View style={styles.body}>
                     <View style={styles.edit_body}>
                        <View style={styles.f_item}>
                           <Text>First Name</Text>
                           <TextInput style = {styles.input}
                              underlineColorAndroid = "transparent"
                              placeholder = ""
                              value={this.state.f_name}
                              placeholderTextColor = "gray"
                              autoCapitalize = "none"
                              onChangeText={(text) => this.setState({f_name : text})}
                              style={global_style.text_input}/>
                        </View>
                        <Text style={[(this.state.btn_flag && this.state.f_name == '') ? styles.error : styles.non_error , {alignSelf : 'flex-start'}]}> First name is required.</Text>

                        <View style={styles.item}>
                           <Text>Last name</Text>
                           <TextInput style = {styles.input}
                              underlineColorAndroid = "transparent"
                              placeholder = ""
                              value={this.state.l_name}
                              placeholderTextColor = "gray"
                              autoCapitalize = "none"
                              onChangeText={(text) => this.setState({l_name : text})}
                              style={global_style.text_input}/>
                        </View>
                        <Text style={[(this.state.btn_flag && this.state.l_name == '') ? styles.error : styles.non_error , {alignSelf : 'flex-start'}]}> Last name is required.</Text>

                        <View style={styles.item}>
                           <Text>Email</Text>
                           <TextInput style = {styles.input}
                              underlineColorAndroid = "transparent"
                              placeholder = ""
                              value={this.state.email}
                              placeholderTextColor = "gray"
                              autoCapitalize = "none"
                              editable = {this.state.enable}
                              onChangeText={(text) => this.validateText(text)}
                              style={global_style.text_input}/>
                        </View>
                        {
                           (global.user_info.google || global.user_info.fb || global.user_info.twitter) ? null : 
                           <View>
                              <Text style={(this.state.btn_flag && !this.state.email_valid && this.state.email != '') ? styles.error : styles.non_error}> Please enter a valid email.</Text>
                              <Text style={(this.state.btn_flag && this.state.email == '') ? styles.error : styles.non_error}> Email is required.</Text>
                           </View>
                        }
                        <View style={styles.item}>
                           <Text>Phone</Text>
                           <PhoneInput
                              ref={ref => {
                                 this.phone = ref;
                              }}
                              value={this.state.phone_number}
                              onChangePhoneNumber = {(value) => this.changeMobileNumber(value)}
                              style={global_style.text_input}
                           />
                        </View>
                        <Text style={(this.state.btn_flag && this.state.phone_number == "") ? styles.error : styles.non_error}> Phone number is required.</Text>
                        <Text style={(this.state.btn_flag && this.state.phone_number != "" && !this.state.phone_valid) ? styles.error : styles.non_error}> Please valid a phonenumber.</Text>

                        <View style={styles.gender}>
                           <Text>Gender</Text>
                           <TouchableOpacity onPress={() => this.onCheckBox(0)} style={styles.checkbox}>
                              <Image source = {this.state.check1} style={styles.check_img}></Image> 
                              <Text style={styles.check_label}>Male</Text>
                           </TouchableOpacity>
                           <TouchableOpacity onPress={() => this.onCheckBox(1)} style={styles.checkbox}>
                              <Image source = {this.state.check2} style={styles.check_img}></Image> 
                              <Text style={styles.check_label}>Female</Text>
                           </TouchableOpacity>      
                        </View>
                     </View>
                  </View>   
               </KeyboardAvoidingView>
               
            </ScrollView>
            <View style={global_style.bottom}>
               <View style={{flex : 2.5}}></View>
               <TouchableOpacity onPress={() => this.updateProfile()} style={global_style.cyan_btn}>
                  <Text style={global_style.label}>Update Profile</Text>
               </TouchableOpacity>
               <View style={{flex : 2.5}}></View>
            </View>

            <View style={this.state.isLoading ? styles.loading : styles.finish}>
               <LoadingBar/>
            </View>
            </KeyboardAwareScrollView>
         </View>
         
      )
   }
}
const styles = StyleSheet.create({
   body : {
      alignItems: 'center',
      alignSelf : "center",
      marginTop:90 * metrics,
      marginBottom :90 * metrics,
      width : '95%',
      borderRadius: 15,
      backgroundColor : 'white',
      elevation : Platform.OS == 'android' ? 8.0 : 0.8,
      shadowOpacity : 0.5,
      shadowOffset : {width : 1, height : Platform.OS == 'ios' ? 1 : 4},
   },
   edit_body: {
      width: '100%',
      overflow : 'hidden',
      padding : 10,
      borderRadius: 5,
      flexDirection : 'column',
      backgroundColor : 'white',
   },
   f_item: {
      margin: 15 * metrics,
      flexDirection : 'column',
      marginTop: 40 * metrics
   },
   item : {
      margin: 15 * metrics,
      flexDirection : 'column'
   },
   gender : {
      flexDirection : 'row',
      marginTop: 10 * metrics,
      marginBottom : 10 * metrics,
      margin: 15 * metrics,
      marginBottom : 30 * metrics
   },
   backarrow : {
      flex: 1,
      flexDirection : 'row',
      width: '100%'
   },
   checkbox: {
      flexDirection: 'row',
      alignSelf : 'center', 
      marginLeft : 15 * metrics
   },
   check_img : {
      width: 20 * metrics,
      height: 20 * metrics,
      resizeMode : 'stretch'
   },
   check_label : {
      marginLeft : 5 * metrics
   },
   profile: {
      width: '100%',
      position : 'absolute',
      top: 30  * metrics,
      zIndex : 999,
      elevation : Platform.OS == 'android' ?10 : 0.1,
   },
   profile_img : {
      width: 115 * metrics,
      height : 115 * metrics,
      borderRadius : 115/2,
      alignItems: 'center',
      alignSelf : 'center',
      zIndex : 999,
   },
   camera : {
      width: 45 * metrics,
      height: 35 * metrics,
      position : "absolute",
      alignItems: 'center',
      top: 47 * metrics,
      alignSelf : "center",

   },
   bottom: {
      position : 'absolute', //made by martin
      bottom: 0,
      width: '100%',
      height : 60 * metrics,
      backgroundColor : 'white',
      shadowOffset : { width : 0, height : -5},
      elevation : 1.0,
      shadowOpacity : 0.3,
      flex: 10
   },
   error : {
      color : 'red',
      fontSize : 13,
      marginLeft : 10 * metrics,
      marginTop : -3 * metrics
   }, 
   non_error : {
      display : 'none'
   },
   loading : {
      position : 'absolute',
      width : '100%',
      height : '100%',
      backgroundColor : 'black',
      opacity : 0.4
   },
   finish : {
      width : 0,
      height : 0,
      position : 'absolute'
   },
})
export default EditProfileScreen