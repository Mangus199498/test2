import React, { Component } from 'react';
import { View , Text, Image,StyleSheet, TouchableOpacity,Switch,ScrollView,Dimensions,AsyncStorage,NativeModules} from 'react-native';
import global_style, { metrics } from  '../../../../constants/globalStyles';
import AuthService from '../../../../services/auth.service';
import UserService from '../../../../services/user.service';
import { setNotiData } from '../../../../utils/global'; //init notification data
import { GoogleSignin,statusCodes } from 'react-native-google-signin';
import { inject, observer } from 'mobx-react';
import { LoginManager } from 'react-native-fbsdk';
//const { RNTwitterSignIn } = NativeModules
import { StackActions, NavigationActions } from 'react-navigation'

const resetAction = (routeName) => StackActions.reset({
	index: 0,
	actions: [
		NavigationActions.navigate({ routeName: routeName }),
	]
});

@inject ('authService')
@inject ('userService')
@observer
class SettingScreen extends Component {

    _authService : AuthService = this.props.authService
    _userService : UserService = this.props.userService

    state = {
        check_value : false,
        membership : 'free'
    }
    googlSignOut = async () => {
        try {
            await GoogleSignin.revokeAccess();
            await GoogleSignin.signOut();
            global.user_info = null;
            this.props.navigation.dispatch(resetAction('LoginScreen'));
        } catch (error) {
            console.error(error);
        }
    }
    fbSignOut = () => {
        global.user_info = null;
        LoginManager.logOut();
        this.props.navigation.dispatch(resetAction('LoginScreen'));
    }
    twitterSignOut = () => {
        // global.user_info = null;
        // RNTwitterSignIn.logOut()
        // this.props.navigation.dispatch(resetAction('LoginScreen'));
    }
    logout = async() => {
        setNotiData([]); //init notification local data
        await AsyncStorage.setItem('remember_flag' , 'false')
        var user = global.user_info;
        if (user.google) {
            this.googlSignOut();
        } else if (user.fb) { 
            this.fbSignOut();
        } else if (user.twitter) {
            //this.twitterSignOut();
        } else {
            this._authService.signOut().then((res) => {
                global.user_info = null;
                this.props.navigation.dispatch(resetAction('LoginScreen'));
            });
        }
    }
    gotoProfile = () => {
        this.props.navigation.navigate('EditProfileScreen');
    }
    gotoFaq = () => {
        this.props.navigation.navigate('FaqScreen');
    }
    gotoUpgrade = () => {
        this.props.navigation.navigate('UpgradePlanScreen');
    }
    gotoChangePassword = () => {
        this.props.navigation.navigate('ChangePassword')
    }
    onChangedSwitch =() => {
        if (this.state.check_value == false) {
            this.setNotficiationFlag(true)
            this.setState({check_value : true})
        } else {
            this.setNotficiationFlag(false)
            this.setState({check_value : false})
        }
    }
    initMembership () {
        this.setState({membership : global.user_info.membership})
    }
    async componentWillMount () {
        this.initMembership()
        await this.getNotificationFlag();
    }
    setNotficiationFlag = async (flag) => {
        var text = ''
        if (flag)
            text = 'true'
        else
            text = 'false'
        try {
            await AsyncStorage.setItem('notification_flag', text);
        } catch (error) {

        }
    };

    getNotificationFlag = async () => {
        try {
            const value = await AsyncStorage.getItem('notification_flag');
            this.auto_flag = value
            if (value !== null) {
                if (value == 'true')
                    this.setState({check_value : true})
                else
                    this.setState({check_value : false})
                this.auto_flag = value
            }
        } catch (error) {

        }
    }


    render() {
        return (
            <ScrollView style={{width: '100%', height : '100%'}} ref="myDiv">
                <View style={{marginTop : 15 * metrics}}></View>
                <View style={global_style.setting_tile}>
                    <TouchableOpacity onPress = { () => this.gotoProfile() } style={styles.touch_body}>
                        <View style={styles.view}>
                            <Image source = {require('../../../../assets/img/icon/ico_person.png')} style={styles.icon}></Image> 
    
                            <Text style={styles.title}> Edit Profile</Text> 
                            <Image source = {require('../../../../assets/img/icon/right_arrow.png')} style={styles.right_arrow_icon}/> 
                        </View>
                    </TouchableOpacity>
                </View>
                <View style={global_style.setting_tile}>
                    <TouchableOpacity  style={styles.touch_body}>
                        <View style={styles.view}>
                            <Image source = {require('../../../../assets/img/icon/ico_notification.png')} style={styles.icon}></Image> 
                            <Text style={styles.title}> Notifications</Text> 
                            <Switch
                                onValueChange = {() => this.onChangedSwitch()}
                                value = {this.state.check_value}
                                style={{alignSelf : 'center' , position : 'absolute', right : 5}}
                                trackColor={{true: '#4f80ff', false: '#e2e2e2'}}
                                // style ={{position : 'absolute', right : 5, marginTop : 20 * metrics}}
                                />
                        </View>
                    </TouchableOpacity>
                </View>
                {
                    global.user_info.google || global.user_info.fb || global.user_info.twitter ? null :
                    <View style={global_style.setting_tile}>
                        <TouchableOpacity style={styles.touch_body} onPress={ () => this.gotoChangePassword()}>
                            <View style={styles.view}>
                                <Image source = {require('../../../../assets/img/icon/ico_lock.png')} style={styles.lock_icon}></Image> 
                                <Text style={styles.title}> Change Password</Text> 
                                <Image source = {require('../../../../assets/img/icon/right_arrow.png')} style={styles.right_arrow_icon}/>
                            </View>
                        </TouchableOpacity>
                    </View>
                }
                
                <View style={global_style.setting_tile}>
                    <TouchableOpacity onPress = { () => this.gotoUpgrade() } style={styles.touch_body}>
                        <View style={styles.view}>
                            <Image source = {require('../../../../assets/img/icon/ico_stars.png')} style={styles.icon}></Image> 
                            <Text style={styles.title}> Upgrade Plan</Text> 
                            <View style={{flexDirection : 'row' , justifyContent : 'flex-end' , flex : 1}}>
                                <Text style={[styles.text,]}>{this.state.membership.toUpperCase()}  </Text>
                                <Image source = {require('../../../../assets/img/icon/right_arrow.png')} style={styles.right_arrow}/>
                            </View>
                        </View>
                    </TouchableOpacity>
                </View>
                <View style={global_style.setting_tile}>
                    <TouchableOpacity onPress = { () => this.gotoFaq() } style={styles.touch_body}>
                        <View style={styles.view}>
                            <Image source = {require('../../../../assets/img/icon/ico_faq.png')} style={styles.icon}></Image> 
                            <Text style={styles.title}> FAQ</Text> 
                            <Image source = {require('../../../../assets/img/icon/right_arrow.png')} style={styles.right_arrow_icon}/>
                        </View>
                    </TouchableOpacity>
                </View>
                <View style={global_style.setting_tile}>
                    <TouchableOpacity onPress = { () => this.logout() } style={styles.touch_body}>
                        <View style={styles.view} >
                            <Image source = {require('../../../../assets/img/icon/ico_logout.png')} style={styles.logout_icon}></Image> 
                            <Text style={[styles.title, {color : '#fd0b22'}]}> Log Out</Text> 
                            <Image source = {require('../../../../assets/img/icon/right_arrow.png')} style={styles.right_arrow_icon}/>
                        </View>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        )
    }
}
const styles = StyleSheet.create({
    view: {
        flex: 1,
        flexDirection : 'row',
        height: '100%'
    },  
    icon : {
        height: 25 * metrics,
        width: 25 * metrics,
        resizeMode: "stretch",
        alignItems: 'center',
        alignSelf : 'center',
        marginLeft : 15 * metrics,
        marginRight: 10 * metrics,
    },
    lock_icon: {
        height: 27 * metrics,
        width: 22 * metrics,
        resizeMode: "stretch",
        alignItems: 'center',
        alignSelf : 'center',
        marginLeft: 15 * metrics,
        marginRight: 10 * metrics,
    },
    logout_icon: {
        height: 20 * metrics,
        width: 25 * metrics,
        resizeMode: "stretch",
        alignItems: 'center',
        alignSelf : 'center',
        marginLeft: 15 * metrics,
        marginRight: 10 * metrics,
    },
    title : {
        alignItems: 'center',
        alignSelf : 'center',
        marginLeft: 0,
        
    },
    right_arrow_icon : {
        width : 11 * metrics,
        height : 17 * metrics,
        resizeMode : 'stretch',
        alignItems: 'center',
        marginRight: 10 * metrics,
        position : 'absolute',
        right : 5,
        top : 25
    },
    right_arrow : {
        width : 11 * metrics,
        height : 17 * metrics,
        resizeMode : 'stretch',
        alignItems: 'center',
        marginRight: 10 * metrics,
        alignItems: 'center',
        alignSelf : 'center',
    },
    right_icon : {
        alignItems: 'center',
        alignSelf : 'center',
        marginRight: 6 * metrics,
    },
    text : {
        alignItems: 'center',
        alignSelf : 'center',
        marginRight: 5
    },
    touch_body : {
        height: '100%',
        width : '100%'
    },
    toggle: {
        alignItems: 'center',
        alignSelf : 'center',
        marginRight:6 * metrics
    }
})
export default SettingScreen