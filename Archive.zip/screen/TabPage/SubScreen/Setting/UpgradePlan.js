import React, { Component } from 'react';
import { View , Text, Image,StyleSheet,TouchableOpacity , Alert,Dimensions, Platform} from 'react-native';
import global_style , {metrics} from  '../../../../constants/globalStyles';
import UserService from '../../../../services/user.service';
import { inject, observer } from 'mobx-react';

import Toast from 'react-native-simple-toast';

@inject ('userService')
@observer

class UpgradePlanScreen extends Component {

    _userService : UserService = this.props.userService

    state = {
        isSelected : 0,
    }
    componentWillMount () {
        if (global.user_info.membership == "free") {
            this.setState({isSelected : 0})
        } else {
            this.setState({isSelected : 1})
        }
        
    }
    onClickedPremium = () =>{
        this.setState({isSelected : 1})
    }
    onClickedFree = () => {
        this.setState({isSelected : 0})
    }

    changeMembership = () => {
        if (global.user_info.membership != "free") {
            var user = global.user_info
            user.membership = "free"

            this._userService.updateUser(user).then((result) => {
                Toast.show('Your membership has been removed!', Toast.LONG);
            }).catch((error) => {
                console.log(error)
            })
        }
    }

    onClickedNext = () => {
        if (this.state.isSelected == 1) { //premium
            if (global.user_info.membership == 'free') {
                this.props.navigation.navigate('PaymentScreen')
            } else {
                Alert.alert(
                    'Upgrade Plan',
                    'You have already upgrade membership.',
                    [
                        {
                            text : 'OK',
                            onPress: ()=> console.log('ok')
                        },
                    ]
                )
            }
        } else { //free
            if (global.user_info.membership != "free") {
                Alert.alert(
                    'Upgrade Plan',
                    'Do you really delete membership?',
                    [
                        {
                            text : 'OK',
                            onPress: ()=> this.changeMembership()
                        },
                        {
                            text : 'Cancel',
                            onPress: ()=> console.log('ok')
                        },
                    ]
                )
            }
        }
    }
    static navigationOptions = ({ navigation }) => {
        return {
            headerLeft: (
                <View style={global_style.navigation}>
                    <TouchableOpacity 
                        style={styles.backarrow}
                        onPress={() => navigation.goBack()} >
                            <Image source = {require('../../../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                            <Text style={global_style.back_title}>UPGRADE PLAN</Text>
                    </TouchableOpacity>
                </View>
            ),
            headerStyle: global_style.headerHeight
        };
    };
    render() {
        return (
            <View style={{width: '100%', height :'100%',backgroundColor : '#f1f6f9'}}>
                <View style={[styles.body, this.state.isSelected == 0 ? {borderColor : '#4f80ff'} : {borderColor : '#e6e6e6'}]}>
                    <TouchableOpacity onPress={ () => this.onClickedFree()} style={{flexDirection : 'row'}}>
                        <View style={styles.left_body}>
                            <Text style ={{color: 'gray', fontSize : 17 * metrics}}>FREE</Text>
                            <Text style={{ color: 'gray',width: 240 * metrics,marginTop : 5 * metrics, fontSize: 14 * metrics}}>Create posts and events and groups for public</Text>
                        </View>
                        <View style={styles.right_body}>
                            <View style={{flexDirection : "row"}}>
                                <Text style={{fontSize : 16 * metrics, marginTop : -5 * metrics}}>$</Text> 
                                <Text style={{fontSize: 20 * metrics, fontWeight : '600'}}> 0.00</Text>
                            </View>
                            <Text style={{fontSize : 14 * metrics, color : 'gray'}}>FREE</Text>
                        </View>
                    </TouchableOpacity>
                </View>

                <View style={[styles.premium_body, this.state.isSelected == 1 ? {borderColor : '#4f80ff'} : {borderColor : '#e6e6e6'}]}>
                    <TouchableOpacity onPress={() => this.onClickedPremium()} style={{flexDirection : 'row'}}>
                        <View style={styles.left_body}>
                            <View style ={{flexDirection : 'row'}}>
                                <Text style ={{color: 'gray', fontSize : 17 * metrics}}>PREMIUM</Text>
                                <Image source = {require('../../../../assets/img/icon/recommend.png')} style={styles.recommend}></Image> 
                            </View>
                            
                            <Text style={{ color: 'gray',width: 240 * metrics , marginTop : 5 * metrics, fontSize: 14 * metrics}}>Create posts and events and groups for public</Text>
                        </View>
                        <View style={styles.right_body}>
                            <View style={{flexDirection : "row"}}>
                                <Text style={{fontSize : 16 * metrics, marginTop : -5 * metrics}}>$</Text> 
                                <Text style={{fontSize: 20 * metrics, fontWeight : '600'}}> 9.99</Text>
                            </View>
                            <Text style={{fontSize : 13 * metrics, color : 'gray'}}>MONTHLY</Text>
                        </View>
                    </TouchableOpacity>
                    
                </View>
                {
                    <View style={global_style.bottom}>
                        <View style ={{flex : 2.5}}></View>
                        <TouchableOpacity onPress={() => this.onClickedNext()} style={global_style.cyan_btn}>
                            <Text style={global_style.label}>Next</Text>
                        </TouchableOpacity>
                        <View style ={{flex : 2.5}}></View>
                    </View>
                }
                
            </View>
        )
    }
}
const styles = StyleSheet.create({
    body: {
        flexDirection : 'row',
        marginTop : 20,
        borderWidth : 1,
        borderRadius: 10,
        margin : 10 * metrics,
        padding: 15 * metrics,
        width: '95%',
        shadowColor: '#dadada',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 1,
        elevation : Platform.OS == 'ios' ? 1.0 : 3.6,
        backgroundColor : 'white'
    },
    premium_body : {
        flexDirection : 'row',
        borderWidth : 1,
        borderRadius: 10,
        marginTop: 0,
        margin : 10 * metrics,
        padding: 15 * metrics,
        width: '95%',
        shadowColor: '#dadada',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 1,
        elevation : Platform.OS == 'ios' ? 1.0 : 3.6,
        backgroundColor : 'white'
    },
    left_body : {
        flexDirection : 'column',
        width : '80%'
    },
    right_body : {
        width :'20%',
        alignItems: 'center',
        marginTop : 0,
        flexDirection : 'column',
    },
    backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%'
    },
    bottom: {
        position : 'absolute', //made by martin
        bottom: 0,
        width: '100%',
        height : 60 * metrics,
        backgroundColor : 'white',
    },
    recommend : {
        width : 100 * metrics,
        height : 20 * metrics,
        resizeMode : 'stretch',
        marginLeft : 5 * metrics
    }
})
export default UpgradePlanScreen