import React , {Component} from "react";
import { Text, View, StyleSheet, Image ,TextInput,TouchableOpacity} from "react-native";
import global_style from '../../constants/globalStyles';
import PropTypes from 'prop-types'

import HomeScreen from './SubScreen/Home/HomeScreen';
import ExploreScreen from './SubScreen/Explore/ExploreScreen';
import MessageScreen from './SubScreen/Message/MessageScreen';
import SettingScreen from './SubScreen/Setting/SettingScreen';
import FriendsScreen from './SubScreen/Friends/FriendsScreen';

class Screen extends Component {
  
  friendRef = null
  homeRef = null
  static navigationOptions = ({ navigation }) => {
    return {
      header:null,
    }

  };
  
  constructor(props) {
    super(props)

    this.state = {
      body_height: 0,
      isSelected : 1,
    }
    this.exploreRef = React.createRef()  
  }
  
  componentWillMount () {
    this.setState({isSelected : 1});
  }
  onClickHandle () {
   if (this.state.isSelected == 1) {
    return 'active'
   } else {
    return 'non-active'
   }
  }
  onClickHandle2 () {
    if (this.state.isSelected == 2) {
     return 'active'
    } else {
     return 'non-active'
    }
   }
   onPostClicked = () => {
     this.setState({isSelected : 1})
   }
   onGroupClicked = () => {
    this.setState({isSelected : 2})
  }
  onChangeState = (val, type) => {
    if (type == 'friend')
      this.friendRef.wrappedInstance.onChangeState(val)
    else if (type == 'explore')
      this.exploreRef.current.onChangeState(val);
    else if (type == 'home')
      this.homeRef.wrappedInstance.onChangeState(val);
  }
  //render
  renderElement(){
    if(this.props.name == 'HOME')
      return <HomeScreen navigation={this.props.navigation} ref={(ref) => this.homeRef = ref}/>;
    else if (this.props.name == 'EXPLORE')
      return <ExploreScreen isSelected = {this.props.isSelected} navigation={this.props.navigation} style={{backgroundColor : '#f1f6f9'}} ref={this.exploreRef}/>
    else if(this.props.name == 'MESSAGES')
      return <MessageScreen navigation={this.props.navigation}/>;
    else if(this.props.name == 'FRIENDS')
      return <FriendsScreen navigation={this.props.navigation} ref={(ref) => this.friendRef = ref}/>;
    else if(this.props.name == 'SETTINGS')
      return <SettingScreen navigation={this.props.navigation}/>;
  }
  render() {
     return (
       <View style={global_style.body_container}>
          { this.renderElement() }
        </View>
     )
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    justifyContent: "center",
    alignItems: "center",
    height: '100%',
  },
  profile : {
    width: 50,
    height : 50,
    resizeMode: "stretch"
  },
});

Screen.propType = {
  isSelected : PropTypes.number,
}
export default Screen;