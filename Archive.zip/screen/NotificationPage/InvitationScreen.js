import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,TextInput,ScrollView} from 'react-native';
import global_style from  '../../constants/globalStyles';

import JoinGroupInvitation from './JoinGroupInvitation';
import FriendInvitation from './FriendInvitation';
import PostInvitation from './PostInvitation';
import PlanInvitation from './PlanInvitation';

import FriendService from '../../services/friend.service';
import UserService from '../../services/user.service';
import NotificationService from '../../services/notification.service';
import MessageService from '../../services/message.service';
import GroupService from '../../services/group.service';
import PostService from '../../services/post.service';
import PlanService from '../../services/plan.service';
import { inject, observer } from 'mobx-react';

let _this = null

@inject ('notificationService')
@inject ('userService')
@inject ('friendService')
@inject ('groupService')
@inject ('messageService')
@inject ('groupService')
@inject ('postService')
@inject ('planService')
@observer

class InvitationScreen extends Component {

    _friendService : FriendService = this.props.friendService
    _userService : UserService  = this.props.userService
    _notificationService : NotificationService = this.props.notificationService
    _messageService : MessageService = this.props.messageService
    _groupService : GroupService = this.props.groupService
    _postService : PostService = this.props.postService
    _planService : PlanService = this.props.planService

    static navigationOptions = ({ navigation }) => {
        //const 
        const { params = {} } = navigation.state;
        if (params.type == 2) {
            console.log(2)
            return {
                headerLeft: (
                    <View style={global_style.navigation}>
                        <TouchableOpacity 
                            style={styles.backarrow}
                            onPress={() => navigation.goBack()} >
                                <Image source = {require('../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                                <Text style={global_style.back_title}>Invitation By {params.navTitle}</Text>
                        </TouchableOpacity>
                    </View>
                ),
                headerStyle: global_style.headerHeight,
            };
        } else {
            return {
                headerLeft: (
                    <View style={global_style.navigation}>
                        <TouchableOpacity 
                            style={styles.backarrow}
                            onPress={() => navigation.goBack()} >
                                <Image source = {require('../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                                <Text style={global_style.back_title}>Invitation By {params.navTitle}</Text>
                        </TouchableOpacity>
                    </View>
                ),
                headerStyle: global_style.headerHeight,
            };
        }
    };
    constructor (props) {
        super(props)
        this.state = {
            starCount : 4,
            height : 0,
            type : -1,
            noti_data : {},
            send_user : {}
        }
    }
    
    componentWillMount () {
        _this =  this
        var noti = this.props.navigation.getParam('noti_data').data
        var send_user = this.props.navigation.getParam('noti_data').send_user
        this.setState({noti_data : noti})
        this.setState({send_user : send_user})
        this.setState({type : noti.type})
        console.log(noti)
        this.props.navigation.setParams({ type : noti.type})
        this.props.navigation.setParams({ navTitle : send_user.f_name + " " + send_user.l_name})
    }
    //accept
    async acceptedGroupInvite() {
        await this._groupService.getDataByf_Id(this.state.noti_data.group_id).then((res) => {
            if (res.exists) {
                var data = res.data();
                if (data.join_arr.length > 0) {
                    var t_join_arr = []
                    var t_friend_arr = data.friends_arr
                    for (var i = 0 ; i < data.join_arr.length ;i ++) {
                        if (data.join_arr[i] == global.user_info.uid) {
                            t_friend_arr.push(data.join_arr[i])
                        } else {
                            t_join_arr.push(data.join_arr[i])
                        }
                    }
                    data.join_arr = t_join_arr
                    data.friends_arr = t_friend_arr
                }
                this._groupService.updateGroup(data.id,data).then((result) => {
                    console.log('updated')
                }).catch((error) => {
                    console.log('update_error = ',  error)
                })
            }
        })
    }
    async acceptedJoinGroupInvite() {
        await this._groupService.getDataByf_Id(this.state.noti_data.group_id).then((res) => {
            if (res.exists) {
                var data = res.data();
                if (data.join_arr.length > 0) {
                    var t_join_arr = []
                    var t_friend_arr = data.friends_arr
                    for (var i = 0 ; i < data.join_arr.length ;i ++) {
                        if (data.join_arr[i] == this.state.send_user.uid) {
                            t_friend_arr.push(data.join_arr[i])
                        } else {
                            t_join_arr.push(data.join_arr[i])
                        }
                    }
                    data.join_arr = t_join_arr
                    data.friends_arr = t_friend_arr
                }
                _this._groupService.updateGroup(data.id,data).then((result) => {
                    console.log('updated')
                }).catch((error) => {
                    console.log('update_error = ',  error)
                })
            }
        })
    }
    async acceptedPostInvite () {
        await this._postService.getDataById_F(this.state.noti_data.post_id).then((res) => {
            if (res.exists) {
                var data = res.data();
                if (data.join_arr.length > 0) {
                    var t_join_arr = []
                    var t_friend_arr = data.friend_arr
                    for (var i = 0 ; i < data.join_arr.length ;i ++) {
                        if (data.join_arr[i] == global.user_info.uid) {
                            t_friend_arr.push(data.join_arr[i])
                        } else {
                            t_join_arr.push(data.join_arr[i])
                        }
                    }
                    data.join_arr = t_join_arr
                    data.friend_arr = t_friend_arr
                }
                _this._postService.updateData(data.id,data).then((result) => {
                    console.log('updated')
                }).catch((error) => {
                    console.log('update_error = ',  error)
                })
            }
        })
    }

    async acceptedPlantInvite () {
        await this._planService.getDataByf_id(this.state.noti_data.plan_id).then((res) => {
            if (res.exists) {
                var data = res.data();
                if (data.join_arr.length > 0) {
                    var t_join_arr = []
                    var t_friend_arr = data.friend_arr
                    for (var i = 0 ; i < data.join_arr.length ;i ++) {
                        if (data.join_arr[i] == global.user_info.uid) {
                            t_friend_arr.push(data.join_arr[i])
                        } else {
                            t_join_arr.push(data.join_arr[i])
                        }
                    }
                    data.join_arr = t_join_arr
                    data.friend_arr = t_friend_arr
                }
                _this._planService.updateData(data.id,data).then((result) => {
                    console.log('updated')
                }).catch((error) => {
                    console.log('update_error = ',  error)
                })
            }
        })
    }
    async rejectedPostInvite () {
        this._postService.getDataById_F(this.state.noti_data.post_id).then((result) => {
            if (result.exists) {
                var data = result.data()
                if (data.join_arr.length > 0) {
                    var t_join_arr = []
                    for (var i = 0 ; i < data.join_arr.length ;i ++) {
                        if (data.join_arr[i] != global.user_info.uid) {
                            t_join_arr.push(data.join_arr[i])
                        }
                    }
                    data.join_arr = t_join_arr
                }
                _this._postService.updateData(data.id,data).then((result) => {
                    console.log('updated')
                }).catch((error) => {
                    console.log('update_error = ',  error)
                })
            }
        })
    }
    async rejectedPlanInvite () {
        this._planService.getDataByf_id(this.state.noti_data.post_id).then((result) => {
            if (result.exists) {
                var data = result.data()
                if (data.join_arr.length > 0) {
                    var t_join_arr = []
                    for (var i = 0 ; i < data.join_arr.length ;i ++) {
                        if (data.join_arr[i] != global.user_info.uid) {
                            t_join_arr.push(data.join_arr[i])
                        }
                    }
                    data.join_arr = t_join_arr
                }
                _this._planService.updateData(data.id,data).then((result) => {
                    console.log('updated')
                }).catch((error) => {
                    console.log('update_error = ',  error)
                })
            }
        })
    }
    async rejectedGroupInvite () {
        this._groupService.getDataByf_Id(this.state.noti_data.group_id).then((result) => {
            if (result.exists) {
                var data = result.data()
                if (data.join_arr.length > 0) {
                    var t_join_arr = []
                    for (var i = 0 ; i < data.join_arr.length ;i ++) {
                        if (data.join_arr[i] != global.user_info.uid) {
                            t_join_arr.push(data.join_arr[i])
                        }
                    }
                    data.join_arr = t_join_arr
                }
                _this._groupService.updateGroup(data.id,data).then((result) => {
                    console.log('updated')
                }).catch((error) => {
                    console.log('update_error = ',  error)
                })
            }
        })
    }
    //
    RejectBtn = () => {
        if (this.state.type == 2) { // invite friend
            this.rejectedFriendInvite ()
        } else if (this.state.type == 0) { //join group
            this.rejectedGroupInvite ()
        } else if (this.state.type == 1) { //post Accepted
            this.rejectedPostInvite ()
        } else if (this.state.type == 3) { //plan Accepted
            this.rejectedPlanInvite ()
        } else if (this.state.type == 4) { //join group Accepted
            this.rejectedGroupInvite()
        }
        this._notificationService.deletteNotificationById(this.state.noti_data.id).then((res) => {
            this.props.navigation.goBack()
        }).catch((error) => {
            console.log(error)
        })
    } 
    AcceptBtn = () => {
        if (this.state.type == 2) { // invite friend
            this.acceptedFriendInvite ()
        } else if (this.state.type == 0) { //join group
            this.acceptedGroupInvite ()
        } else if (this.state.type == 1) { //post Accepted
            this.acceptedPostInvite ()
        } else if (this.state.type == 3) { //plan Accepted
            this.acceptedPlantInvite ()
        } else if (this.state.type == 4) { //join Accepted
            this.acceptedJoinGroupInvite()
        }
        
        this.state.noti_data.isAccepted = 1
        this.state.send_uid = this.state.send_user.uid
        var noti_data = {
            type : this.state.type, // invite friend
            is_read : 1,
            recv_uid : this.state.noti_data.recv_uid,
            send_uid : this.state.send_user.uid,
            content : this.state.noti_data.content,
            id : this.state.noti_data.id,
            isAccepted : 1
        }
        this._notificationService.updateNotification(this.state.noti_data.id, noti_data).then((result) => {
            this.props.navigation.goBack()
            console.log(result)
        }).catch((error) => {
            console.log(error)
        })
    } 

    bodyRender() {
        if (this.state.type == 0) { //join group invite
            return <JoinGroupInvitation style={styles.sub_body} noti_data= {this.state.noti_data}/>
        } else if (this.state.type == 3) { //plan invite 
            return <PlanInvitation noti_data= {this.state.noti_data}/>
        } else if (this.state.type == 1) { //post invite 
            return <PostInvitation style={styles.sub_body} noti_data= {this.state.noti_data}/>
        } else if (this.state.type == 4) { //join group
            return <JoinGroupInvitation style={styles.sub_body} noti_data= {this.state.noti_data}/>
        }
        // else  if (this.state.type == 2){ //invite friend
        //     return <FriendInvitation style={styles.sub_body} noti_data= {this.state.noti_data} navigation={this.props.navigation}/>
        // }
    }

    render() {
        return (
            <View style={{width: '100%', height : '100%'}}>
                {
                    this.state.type == 2 ? <FriendInvitation style={styles.sub_body} noti_data= {this.state.noti_data} navigation={this.props.navigation}/> :
                    <ScrollView style={{width: '100%', height : '100%',backgroundColor : '#ececec'}}>
                    {
                        this.bodyRender()                            
                    }
                    </ScrollView>
                }
                
                {
                    this.state.type == 2 ? null : 
                    <View style={this.state.noti_data.isAccepted == 1 ? styles.none_bottom : styles.bottom}> 
                        <View style={{flex : 1}}></View>
                        <TouchableOpacity onPress={() => this.RejectBtn()} style={styles.white_btn}>
                                <Text style={styles.black_label}>Reject</Text>
                        </TouchableOpacity>
                        <View style={{flex : 1}}></View>
                        <TouchableOpacity onPress={() => this.AcceptBtn()} style={styles.cyan_btn}>
                                <Text style={styles.label}>Accept</Text>
                        </TouchableOpacity>
                        <View style={{flex : 1}}></View>
                    </View>
                }
            </View>
            
        )
    }
}
const styles = StyleSheet.create({
    body : {
        alignItems: 'center',
        alignSelf : "center",
        marginTop:90,
        marginBottom :90,
        width : '95%',
     },
     info_body: {
        shadowColor:'#d4d3d3',
        shadowOffset : {width: 0, height: 0}, 
        shadowRadius: 40, 
        shadowOpacity : 0.8,
        elevation : 0.5,
        width: '100%',
        overflow : 'hidden',
        borderRadius: 15,
        padding : 10,
        flexDirection : 'column'
     },
     sub_body : {
        width : '100%', height : '100%'
     },
     item : {
        margin: 15,
        flexDirection : 'column'
     },
     backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%'
     },
     about_description : {
        marginTop : 15,
        flexDirection : 'column'
     },
     image_body : {
        marginTop: 15
     },
     image : {
        height : 'auto',
        width: '100%',
        overflow : 'scroll',
        paddingTop : 10,
        flexDirection: 'row',
        flexWrap : 'wrap'
     },
     place_img : {
        borderRadius: 10,
        width: '30%',
        height: 100,
        resizeMode: "stretch",
        margin : 5
     },
     date: {
         flexDirection : 'row'
     },
     profile: {
        width: '100%',
        position : 'absolute',
        top: -65
     },
     description : {
        
     },
     profile_img : {
        width: 115,
        height : 115,
        borderRadius : 115/2,
        alignItems: 'center',
        alignSelf : "center",
     },
     camera : {
        width : 40,
        height : 35,
        resizeMode : 'stretch',
        margin : 'auto',
     },
     none_bottom : {
        width : 0,
        height : 0
     },
     bottom: {
        borderTopWidth : 1,
        borderTopColor: '#f1f1f1',
        flexDirection: 'row',
        alignItems : 'center',
        bottom: 0,
        width: '100%',
        height : 60,
        backgroundColor : 'white',
        shadowOffset : { width : 0, height : -4},
        shadowRadius : Platform.OS == 'android' ? 10 : 8,
        shadowOpacity :Platform.OS == 'android' ? 0.7 : 0.3,
        elevation : Platform.OS == 'android' ? 10 : 0.6,
        position : 'absolute', //made by martin
        flexDirection : 'row',
        flex : 10,
        
     },
     cyan_btn : {
        width: '40%',
        height: 40,
        borderRadius: 40,
        alignSelf : "center",
        backgroundColor: '#4f80ff',
        shadowColor: '#809adc',
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.4,
        shadowRadius: 7, 
        flex : 3 ,
        elevation : 3.5
     },
     white_btn : {
        width: '40%',
        height: 40,
        borderRadius: 40,
        alignSelf : "center",
        backgroundColor: 'white',
        flex : 3,
     },
     black_label : {
        height: '100%',
        alignItems: 'center',
        alignSelf : "center",
        fontSize: 18,
        color: 'black',
        marginTop: 6,
     },
     label : {
        height: '100%',
        alignItems: 'center',
        alignSelf : "center",
        fontSize: 18,
        color: 'white',
        marginTop: 6,
     },
})
export default InvitationScreen