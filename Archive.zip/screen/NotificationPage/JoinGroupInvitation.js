import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,TextInput,ScrollView,Dimensions, Platform} from 'react-native';
import global_style from  '../../constants/globalStyles';
import { Input , Avatar} from 'react-native-elements';

import NotificationService from '../../services/notification.service';
import GroupService from '../../services/group.service';

import { inject, observer } from 'mobx-react';

const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const ratioX = screenWidth / 360;

@inject ('notificationService')
@inject ('groupService')
@observer

class JoinGroupInvitation extends Component {

    _notificationService : NotificationService = this.props.notificationService
    _groupService : GroupService = this.props.groupService

    constructor (props) {
        super(props)
        
    }
    state = {
        starCount : 4,
        height : 0,
        group_data : {},
        send_user : {},
        noti_data : {}
    }

    componentWillUnmount () {
        this.unsubscribeGroup()
    }
    componentWillMount () {
        this.setState({send_user : this.props.noti_data.send_uid}) 
        this.setState({noti_data : this.props.noti_data})
        var _this = this
        this.unsubscribeGroup = this._groupService.getDataById(this.props.noti_data.group_id).onSnapshot(function(result) {
            if (result.exists) { 
                const data = result.data()
                console.log(data)
                _this.setState({group_data : data})    
            }
        })
        
        if (this.props.noti_data.is_read != 1) {
            var upgrade_data = this.props.noti_data;
            upgrade_data.send_uid = this.props.noti_data.send_uid.uid
            upgrade_data.is_read = 1;
            this._notificationService.updateNotification(upgrade_data.id, upgrade_data).then((result) => {
                console.log(result) //update notification
            }).catch((error) => {
                console.log(error)
            })
        }
    }
    render() {
        return (
            <ScrollView style={{width: '100%', height : '100%'}}>
                <View style={styles.profile}>
                    <Avatar
                        rounded
                        overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                        size="xlarge"
                        source = {{uri : this.state.send_user.img_url}}
                        resizeMode={'stretch'}
                        containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                        style={styles.profile_img}
                    />
                </View>
                <View style={styles.body}>
                    <View style={styles.info_body}>
                        <View style={{marginTop: 60}}></View>
                        <Text style={{textAlign : "center", fontSize : 17 * ratioX, fontWeight : '600', marginBottom : 5 * ratioX}}>{this.state.group_data.title}</Text>
                        <Text style={{textAlign : "center", fontSize : 14 * ratioX, marginBottom : 5 * ratioX}}>{this.state.noti_data.content}</Text>
                        <Text style={{fontWeight : '700', marginBottom : 20 * ratioX}}>Members : {this.state.group_data.friends_arr == undefined ? '' : this.state.group_data.friends_arr.length + 1}</Text>
                        <View style={styles.about_description}>
                            <Text style={{fontWeight : '700'}}>About Group</Text>
                            <Text style={styles.description}>
                                {this.state.group_data.description}
                            </Text>
                        </View>
                        <View style={styles.image_body}>
                            <Text style={{fontWeight : '700'}}>Images</Text>
                            
                            <View style={styles.image}>
                            {
                                this.state.group_data.length > 0 ? 
                                this.state.group_data.post_arr.map((item , index) => {
                                    if (item.data_arr.length > 0) {
                                        return (
                                            <Image source = {{uri : item.data_arr[0]}} style={styles.place_img}/>
                                        )
                                    }
                                }) : null
                            }
                            </View>
                        </View>
                    </View>
                    
                </View>
            </ScrollView>
        )
    }
}
const styles = StyleSheet.create({
    body : {
        alignItems: 'center',
        alignSelf : "center",
        marginTop:90 * ratioX,
        marginBottom :90 * ratioX,
        width : '100%',
        borderRadius: 15,
        backgroundColor : 'white',
     },
     info_body: {
        shadowColor:'#d4d3d3',
        shadowOffset : {width: 0, height: 4}, 
        shadowRadius: 40, 
        shadowOpacity : 0.8,
        elevation : Platform.OS == 'ios' ? 2 : 10,
        width: '100%',
        overflow : 'hidden',
        padding : 10,
        borderRadius : 15,
        flexDirection : 'column',
        backgroundColor : 'white',
     },
     item : {
        margin: 15 * ratioX,
        flexDirection : 'column'
     },
     backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%'
     },
     about_description : {
        flexDirection : 'column'
     },
     image_body : {
        marginTop: 15 * ratioX
     },
     image : {
        height : 'auto',
        width: '100%',
        overflow : 'scroll',
        paddingTop : 10,
        flexDirection: 'row',
        flexWrap : 'wrap'
     },
     place_img : {
        borderRadius: 10,
        width: '30%',
        height: 100 * ratioX,
        resizeMode: "stretch",
        margin : 5
     },
     date: {
         flexDirection : 'row'
     },
     profile: {
        width: '100%',
        position : 'absolute',
        top: 30,
        elevation : Platform.OS == 'android' ?10 : 0.1,
        zIndex : 999
     },
     profile_img : {
        width: 115 * ratioX,
        height : 115 * ratioX,
        elevation : 10,
        borderRadius : 100,
        backgroundColor : 'white',
        alignSelf : "center",
     },
     bottom: {
        borderTopWidth : 1,
        borderTopColor: '#f1f1f1',
        flexDirection: 'row',
        alignItems : 'center',
        bottom: 0,
        width: '100%',
        height : 60 * ratioX,
        shadowOffset : { width : 0, height : -10},
        shadowColor : '#d8d8d8',
        shadowRadius : 20,
        shadowOpacity : 0.7,
        position : 'absolute', //made by martin
        flexDirection : 'row',
        flex : 10,
     },
     cyan_btn : {
        width: '40%',
        height: 40 * ratioX,
        borderRadius: 40,
        alignSelf : "center",
        backgroundColor: '#4f80ff',
        shadowColor: '#809adc',
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.4,
        shadowRadius: 7, 
        flex : 3 ,
        elevation : 3.5
     },
     white_btn : {
        width: '40%',
        height: 40 * ratioX,
        borderRadius: 40,
        alignSelf : "center",
        backgroundColor: 'white',
        flex : 3,
        elevation : 3.5
     },
     black_label : {
        height: '100%',
        alignItems: 'center',
        alignSelf : "center",
        fontSize: 18 * ratioX,
        color: 'black',
        marginTop: 6,
     },
     label : {
        height: '100%',
        alignItems: 'center',
        alignSelf : "center",
        fontSize: 18 * ratioX,
        color: 'white',
        marginTop: 6 * ratioX,
     },
})
export default JoinGroupInvitation