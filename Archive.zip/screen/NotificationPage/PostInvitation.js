import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,TextInput,ScrollView,Dimensions} from 'react-native';
import global_style, { metrics } from  '../../constants/globalStyles';
import { Input , Avatar} from 'react-native-elements';
import { inject, observer } from 'mobx-react';

import NotificationService from '../../services/notification.service';
import PostService from '../../services/post.service';


const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const ratioX = screenWidth / 360;
const ratioY = screenHeight / 896;


@inject ('notificationService')
@inject ('postService')
@observer

class PostInvitation extends Component {

    _postService : PostService = this.props.postService
    _notificationService : NotificationService = this.props.notificationService

    static navigationOptions = ({ navigation }) => {
        return {
            headerLeft: (
                <View style={global_style.navigation}>
                    <TouchableOpacity 
                        style={styles.backarrow}
                        onPress={() => navigation.goBack()} >
                            <Image source = {require('../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                            <Text style={global_style.back_title}>Invitation By John D</Text>
                    </TouchableOpacity>
                </View>
            ),
            headerStyle: global_style.headerHeight
        };
    };
    constructor (props) {
        super(props)
        this.state = {
            post_data : null,
            send_user : null
        }
    }
    
    componentWillMount () {
        this.getPostData(this.props.noti_data.post_id)
        this.setState({send_user : this.props.noti_data.send_uid})
        
        if (this.props.noti_data.is_read != 1) {
            var upgrade_data = this.props.noti_data;
            upgrade_data.send_uid = this.props.noti_data.send_uid.uid
            upgrade_data.is_read = 1;
            this._notificationService.updateNotification(upgrade_data.id, upgrade_data).then((result) => {
                console.log(result) //update notification
            }).catch((error) => {
                console.log(error)
            })
        }
    }
    getPostData(id) {
        this._postService.getDataById_F(id).then((res)=> {
            if (res.exists) {
                this.setState({post_data : res.data()})
            }
        }).catch((error) => {
            console.log(error)
        })
    }
    render() {
        return (
            <ScrollView style={{width: '100%', height : '100%'}}>
                <View style={styles.profile}>
                    <Avatar
                        rounded
                        overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                        size="xlarge"
                        source = {{uri : this.state.send_user.img_url}}
                        resizeMode={'stretch'}
                        containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                        style={styles.profile_img}
                    />
                </View>
                <View style={styles.body}>
                    <View style={styles.info_body}>
                        <View style={{marginTop: 60}}></View>
                        <Text style={{textAlign : "center", fontSize : 17 * ratioX, fontWeight : '600', marginBottom : 5 * ratioX}}>{this.state.post_data == null ? '' :this.state.post_data.title}</Text>
                        <Text style={{textAlign : "center", fontSize : 14 * ratioX, marginBottom : 5 * ratioX}}>Invite post</Text>
                        
                        <View style={styles.about_description}>
                            <Text style={{fontSize : 18 * metrics , marginBottom : 15 * metrics}}>About Post</Text>
                            <Text style={styles.description}>
                                {this.state.post_data == null ? '' : this.state.post_data.description}
                            </Text>
                        </View>
                        <View style={styles.image_body}>
                            <Text style={{fontSize : 18 * metrics, marginBottom : 15 * metrics}}>Images</Text>
                            <View style={styles.image}>
                                {
                                    this.state.post_data == null ? null :
                                    this.state.post_data.data_arr.map((item,index) => {
                                        return (
                                            <Image source = {{uri : item}} style={styles.place_img} key={index}/>
                                        )
                                    })
                                }
                            </View>
                        </View>
                    </View>
                    
                </View>
                
            </ScrollView>
        )
    }
}
const styles = StyleSheet.create({
    body : {
        alignItems: 'center',
        alignSelf : "center",
        marginTop:90  * ratioX,
        marginBottom :90  * ratioX,
        width : '100%',
        borderRadius: 15,
        backgroundColor : 'white',
        backgroundColor : 'white',shadowOffset : {width: 0, height: 4}, 
        shadowRadius: 10, 
        shadowOpacity : 0.5,
        elevation : Platform.OS == 'ios' ? 1 : 10,
     },
     info_body: {
        // shadowColor:'#d4d3d3',
        // shadowOffset : {width: 0, height: 0}, 
        // shadowRadius: 40, 
        // shadowOpacity : 0.8,
        // elevation : Platform.OS == 'ios' ? 2 : 10,
        width: '100%',
        overflow : 'hidden',
        padding : 10,
        borderRadius: 15,
        flexDirection : 'column',
        backgroundColor : 'white',
     },
     item : {
        margin: 15  * ratioX,
        flexDirection : 'column'
     },
     backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%'
     },
     about_description : {
        flexDirection : 'column'
     },
     image_body : {
        marginTop: 15  * ratioX
     },
     image : {
        height : 'auto',
        width: '100%',
        overflow : 'scroll',
        paddingTop : 10,
        flexDirection: 'row',
        flexWrap : 'wrap'
     },
     place_img : {
        borderRadius: 10,
        width: '30%',
        height: 100,
        resizeMode: "stretch",
        margin : 5  * ratioX
     },
     date: {
         flexDirection : 'row'
     },
     profile: {
        width: '100%',
        position : 'absolute',
        top: 30,
        zIndex : 999,
        elevation : Platform.OS == 'android' ?10 : 0.1,
     },
     profile_img : {
        width: 115 * ratioX,
        height : 115 * ratioX,
        alignSelf : "center",
     },
     bottom: {
        borderTopWidth : 1,
        borderTopColor: '#f1f1f1',
        flexDirection: 'row',
        alignItems : 'center',
        bottom: 0,
        width: '100%',
        height : 60 * ratioX,
        shadowOffset : { width : 0, height : -10},
        shadowColor : '#d8d8d8',
        shadowRadius : 20,
        shadowOpacity : 0.7,
        position : 'absolute', //made by martin
        flexDirection : 'row',
        flex : 10,
        
     },
     cyan_btn : {
        width: '40%',
        height: 40 * ratioX,
        borderRadius: 40,
        alignSelf : "center",
        backgroundColor: '#4f80ff',
        shadowColor: '#809adc',
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.4,
        shadowRadius: 7, 
        flex : 3 ,
        elevation : 3.5
     },
     white_btn : {
        width: '40%',
        height: 40 * ratioX,
        borderRadius: 40,
        alignSelf : "center",
        backgroundColor: 'white',
        flex : 3,
        elevation : 3.5
     },
     black_label : {
        height: '100%',
        alignItems: 'center',
        alignSelf : "center",
        fontSize: 18 * ratioX,
        color: 'black',
        marginTop: 6 * ratioX,
     },
     label : {
        height: '100%',
        alignItems: 'center',
        alignSelf : "center",
        fontSize: 18 * ratioX,
        color: 'white',
        marginTop: 6 * ratioX,
     },
})
export default PostInvitation