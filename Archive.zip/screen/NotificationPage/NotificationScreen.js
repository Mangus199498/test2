import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,TextInput,ScrollView,Dimensions} from 'react-native';
import global_style from  '../../constants/globalStyles';
import { Input , Avatar} from 'react-native-elements';

import { get_before_day } from '../../utils/moment';
import { sortDataByTime } from '../../utils/global';

import UserService from '../../services/user.service';
import NotificationService from '../../services/notification.service';
import { inject, observer } from 'mobx-react';

const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const ratioX = screenWidth / 360;
const ratioY = screenHeight / 896;

@inject ('userService')
@inject ('notificationService')
@observer

class NotificationScreen extends Component {

    _userService : UserService = this.props.userService
    _notificationService : NotificationService = this.props.notificationService

    static navigationOptions = ({ navigation }) => {
        return {
            headerLeft: (
                <View style={global_style.navigation}>
                <TouchableOpacity 
                    style={styles.backarrow}
                    onPress={() => navigation.goBack()} >
                        <Image source = {require('../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                        <Text style={global_style.back_title}>NOTIFICATIONS</Text>
                </TouchableOpacity>
                </View>
            ),
            headerStyle: global_style.headerHeight
        };
    };
    state = {
        notification_arr : []
    }

    componentWillUnmount () {
        this.unsubscribeNoti()
    }

    async componentWillMount () {
        var _this = this
        
        var uid = global.user_info.uid;
        
        this.unsubscribeNoti = this._notificationService.getAllData(uid).onSnapshot(function(result) {
            const data = result.docs.map(doc => doc.data());
            var count = 0;
            if (data.length > 0) {
                data.forEach(element => {
                    _this._userService.getUserData(element.send_uid).then((result) => {
                        if (result.exists) {
                            element.send_uid = result.data()
                        }
                        count ++;
                        if (count == data.length) {
                            
                            _this.setState({notification_arr : sortDataByTime(data)})
                        }
                    })
                });
            } else {
                _this.setState({notification_arr : []})
            }
        })
    }
    onClickedNotification = (item) => {
        var noti_data = {
            data : item,
            send_user : item.send_uid
        }
        this.props.navigation.navigate('InvitationScreen', {noti_data : noti_data});
    } 
    render() {
        return (
            <ScrollView style={{width: '100%', height : '100%', backgroundColor : '#f1f6f9'}}>
                {
                    this.state.notification_arr.map((item, index) => {
                        if (item.send_uid.uid != global.user_info.uid)  {
                            return (
                                <View style={styles.body} key={index}>
                                    <View style={styles.item}>
                                        <TouchableOpacity onPress = { () => this.onClickedNotification(item) } style={styles.touch_body}>
                                            <Avatar
                                                rounded
                                                overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                                                size="xlarge"
                                                source = {{uri : item.send_uid.img_url}}
                                                resizeMode={'stretch'}
                                                containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                                                style={styles.profile}
                                            />
                                            <View style= {styles.text}>
                                                <View style={{flexDirection : 'row'}}>
                                                    <Text style={styles.title}>{item.send_uid.f_name} {item.send_uid.l_name}</Text> 
                                                    <Text style={{fontSize : 14 * ratioX, color : 'gray', alignItems: 'center' ,marginLeft : 5 * ratioX}}> {item.content}</Text> 
                                                </View>
                                                {
                                                    get_before_day(item.time) == 0 ? 
                                                    <Text style={styles.time}>Just now</Text> : <Text style={styles.time}> { get_before_day(item.time) } days ago</Text>
                                                }
                                                
                                            </View>
                                            {
                                                item.is_read != 0 ? null :
                                                <Image source = {require('../../assets/img/icon/red_circle.png')} style={styles.circle}></Image> 
                                            }
                                        </TouchableOpacity>
                                    </View>
                                </View>
                            )
                        }
                    })
                }
                
            </ScrollView>
        )
   }
}
const styles = StyleSheet.create({
    body: {
        width: '100%',
        flexDirection: 'column',
        backgroundColor : 'white'
    },
    item: {
        width: '100%',
        height : 60 * ratioX,
        borderBottomColor : '#f1f1f1',
        borderBottomWidth : 1
    },
    backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%'
    },
    profile: {
        width : 45 * ratioX,
        height: 45 * ratioX,
        marginLeft : 15 * ratioX,
        marginRight : 10 * ratioX,
        alignSelf : 'center'
    },
    circle : {
        width : 15 * ratioX,
        height: 15 * ratioX,
        resizeMode : "stretch",
        alignItems: 'center',
        alignSelf : 'center',
        //marginRight: 10,
        position : 'absolute',
        right : 5,
    },
    title : {
        fontSize: 15 * ratioX
    },
    time : {
        fontSize : 12 * ratioX,
        color : 'gray'
    },
    text: {
        alignItems: 'flex-start',
        alignSelf : 'center',
        marginLeft: 0,
        flexDirection: 'column',
    },
    touch_body : {
        width: '100%',
        height: '100%',
        flexDirection: 'row',
    },
})
export default NotificationScreen