import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,TextInput,ScrollView, Dimensions} from 'react-native';
import global_style from  '../../constants/globalStyles';
import { Input , Avatar} from 'react-native-elements';

import UserService from '../../services/user.service';
import PlanService from '../../services/plan.service';
import PostService from '../../services/post.service';
import FriendService from '../../services/friend.service';
import NotificationService from '../../services/notification.service';
import MessageService from '../../services/message.service';

import { replaceTitle } from '../../utils/utils';
import { inject, observer } from 'mobx-react';

const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const ratioX = screenWidth / 360;
const ratioY = screenHeight / 896;

@inject ('userService')
@inject ('planService')
@inject ('postService')
@inject ('messageService')
@inject ('friendService')
@inject ('notificationService')
@observer

class FriendInvitation extends Component {
    _userService  : UserService = this.props.userService
    _postService : PostService = this.props.postService
    _planService : PlanService = this.props.planService
    _friendService : FriendService = this.props.friendService
    _notificationService : NotificationService = this.props.notificationService
    _messageService : MessageService = this.props.messageService

    constructor (props) {
        super(props)
        this.state = {
            starCount : 4,
            height : 0,
            friend_data : null,
            noti_data : null,
            plan_arr : [],
            post_arr : [],
            send_uid : '',
            isAccepted : false
        }
    }
    
    componentWillMount () {
        this.setState({send_uid : this.props.noti_data.send_uid.uid})
        this.setState({friend_data : this.props.noti_data.send_uid})
        this.setState({noti_data : this.props.noti_data})
        this.getPostData(this.props.noti_data.send_uid.uid)
        this.getPlanData(this.props.noti_data.send_uid.uid)
        if (this.props.noti_data.is_read != 1) {
            var upgrade_data = this.props.noti_data;
            upgrade_data.send_uid = this.props.noti_data.send_uid.uid
            upgrade_data.is_read = 1;
            this._notificationService.updateNotification(upgrade_data.id, upgrade_data).then((result) => {
                console.log(result)
            }).catch((error) => {
                console.log(error)
            })
        }
    }

    async getPostData(user_id) { //init post data
        var temp_data = [];
          await this._postService.getAllDataByUID(user_id).get().then(result => {
            const data = result.docs.map(doc => doc.data());
            temp_data = data;
            temp_data.forEach((item) => {
                this._userService.getUserData(item.uid).then((result) =>{
                if (result.exists) {
                  item.uid = result.data();
                }
              })
            })
            this.setState({post_arr : temp_data})
        })
    }
    async getPlanData(user_id) { //init plan data 
        var temp_data = [];
        await this._planService.getAllDataByUID(user_id).get().then(result => {
            const data = result.docs.map(doc => doc.data());
            temp_data = data;
            temp_data.forEach((item) => {
                this._userService.getUserData(item.uid).then((result) =>{
                if (result.exists) {
                    item.uid = result.data();
                }
                })
            })
            this.setState({plan_arr : temp_data})
        })
    }

    onCheckBox = (value) =>{

    }
    RejectBtn = async() => {
        this._friendService.getFriendSearchData(this.state.noti_data.send_uid.uid).then((result) => {
            const data = result.docs.map(doc => doc.data());
            if (data.length > 0) {
                var friend_Data = data[0]
                if (friend_Data.friends_arr.length > 0) {
                    var t_friends_arr = []
                    for (var i = 0 ; i < friend_Data.friends_arr.length ;i ++) {
                        if (friend_Data.friends_arr[i].uid != global.user_info.uid) {
                            t_friends_arr.push(friend_Data.friends_arr[i])
                        }
                    }
                    friend_Data.friends_arr = t_friends_arr
                }
                this._friendService.updateFriendById(friend_Data.id,friend_Data).then((result) => {
                    this.props.navigation.goBack();
                }).catch((error) => {
                })
            }
        })
        
        this._notificationService.deletteNotificationById(this.state.noti_data.id).then((res) => {
            this.props.navigation.goBack()
        }).catch((error) => {
            console.log(error)
        })
    } 
    async acceptedFriendInvite () {
        var other_id = this.state.send_uid
        var my_id = global.user_info.uid//this.state.noti_data.recv_uid

        var msg_obj = {
            user_data : [other_id , my_id],
            status_data : [true ,true],
            type : 0,
            message_content : [],
        }
        await this._messageService.addMessage(msg_obj).then((result) => {

        }).catch((error) => {   
            console.log(error)
        })
        
        await this._friendService.inviteFriend(other_id).then((result) => {
            const data = result.docs.map(doc => doc.data())[0];
            console.log('data = ' ,data)
            if (data.friends_arr.length > 0) { //friend arr
                data.friends_arr.forEach(item => {
                    if (item.uid == my_id) {
                        item.status = 1; // set friend
                    }
                });
            }
            this._friendService.updateFriendById(data.id , data).then((result) => { //update friend
                var obj = {
                    uid : my_id,
                    friend_uid : other_id,
                    status : 1
                }
                this._friendService.inviteFriend(my_id).then((res) => {
                    console.log('5 = ' + this.state.send_user)
                    const data = res.docs.map(doc => doc.data())[0];
                    if (data == null) { // add database
                        this._friendService.addFriend(obj).then((res) => {
                            
                            console.log('add')
                        }).catch((error) => {
                            console.log(error)
                        })
                    } else {
                        this._friendService.updateFriend(data, obj).then((res) => {
                            console.log('update')
                        }).catch((error) => {
                            console.log(error)
                        })
                    }
                })
            }).catch((error) => {
                console.log(error)
            })
            
        }).catch((error) => {
            console.log(error)
        })
        

    }
    AcceptBtn = () => {
        if (this.state.isAccepted) return

        this.setState({isAccepted : true})
        this.acceptedFriendInvite ()

        this.state.noti_data.isAccepted = 1
        var noti_data = {
            type : this.state.noti_data.type, // invite friend
            is_read : 1,
            recv_uid : this.state.noti_data.recv_uid,
            send_uid : this.state.send_uid,
            content : this.state.noti_data.content,
            id : this.state.noti_data.id,
            isAccepted : 1
        }
        this._notificationService.updateNotification(this.state.noti_data.id, noti_data).then((result) => {
            this.props.navigation.goBack()
            console.log(result)
        }).catch((error) => {
            console.log(error)
        })

        
    } 
    render() {
        return (
            <View style={{width: '100%', height : '100%' ,backgroundColor : 'white'}}>
                <View style={styles.total_body}>
                    <View style={styles.profile}>
                        <Avatar
                            rounded
                            overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                            size="xlarge"
                            source = {{uri : this.state.friend_data.img_url}}
                            resizeMode={'stretch'}
                            containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                            style={styles.profile_img}
                        />  
                    </View>
                    <View style={styles.info_body}>
                        <View style={{marginTop: 30}}></View>
                        <Text style={{textAlign : "center", fontSize : 17 * ratioX, fontWeight : '600', marginBottom : 5 * ratioX}}>{this.state.friend_data.f_name} {this.state.friend_data.l_name}</Text>
                        <Text style={{textAlign : "center", fontSize : 14 * ratioX, marginBottom : 5 * ratioX}}>Sent you friend request</Text>
                        {
                            this.state.noti_data.isAccepted != 1 ? 
                            <View style={styles.btn_group}> 
                                <TouchableOpacity onPress={() => this.RejectBtn()} style={styles.white_btn}>
                                        <Text style={styles.black_label}>Reject</Text>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => this.AcceptBtn()} style={styles.cyan_btn}>
                                        <Text style={styles.label}>Accept</Text>
                                </TouchableOpacity>
                            </View>    
                            : null
                        }
                        
                    </View>
                    <ScrollView>
                    {
                        this.state.plan_arr.map((item ,index) => {
                            return (
                            <TouchableOpacity style={styles.componentCard} key={index}>
                                <View style={{alignSelf : 'center'}}>
                                {
                                    item.address.photo_arr.length > 0 ? 
                                    <Image source = {{uri : item.address.photo_arr[0]}} style={styles.image}/>   : null
                                }
                                <Image source = {require('../../assets/img/icon/trip_icon.png')} style={styles.trip_icon}/>
                                </View>
                                
                                <View style={styles.body}>
                                <Text style={styles.title}>{replaceTitle(item.address.name)}</Text>
                                <View style={styles.time}>
                                    <Image source = {require('../../assets/img/icon/clock.png')} style={styles.icon}/>
                                    <Text> 2 days ago</Text>
                                </View>
                                <View style={styles.icon_body}>
                                    <Image source = {require('../../assets/img/icon/ico_like.png')} style={styles.icon_like}></Image>
                                    <Text> 4</Text>
                                    <Text>   </Text>
                                    <Image source = {require('../../assets/img/icon/ico-inbox.png')} style={styles.icon_inbox}></Image>
                                    <Text> {item.comment.length}</Text>
                                </View>
                                </View>
                            </TouchableOpacity>
                            )
                        })
                    }
                    {
                        this.state.post_arr.map((item ,index) => {
                        return (
                            <TouchableOpacity style={styles.componentCard} key={index}>
                                {
                                    item.data_arr.length > 0 ? <Image source = {{uri : item.data_arr[0]}} style={styles.image}/> : null
                                }
                                <View style={styles.body}>
                                    <Text style={styles.title}>{item.title}</Text>
                                    <View style={styles.time}>
                                        <Image source = {require('../../assets/img/icon/clock.png')} style={styles.icon}/>
                                        <Text> 2 days ago</Text>
                                    </View>
                                    <View style={styles.icon_body}>
                                        <Image source = {require('../../assets/img/icon/ico_like.png')} style={styles.icon_like}></Image>
                                        <Text style={{alignSelf : 'center'}}> {item.favorite.length}</Text>
                                        <Text>   </Text>
                                        <Image source = {require('../../assets/img/icon/ico-inbox.png')} style={styles.icon_inbox}></Image>
                                        <Text style={{alignSelf : 'center'}}> {item.comment.length}</Text>
                                    </View>
                                    </View>
                                </TouchableOpacity>
                            )
                        })
                    }
                    </ScrollView>
                </View>
            </View>
        )
    }
}
const styles = StyleSheet.create({
    total_body : {
        flexDirection: 'column',
        padding: 10,
        alignItems: 'center',
        alignSelf : "center",
        height : '100%',
        elevation : 2,
    },
    info_body: {
        width: '100%',
        overflow : 'hidden',
        padding : 10,
        flexDirection : 'column',
    },

    item : {
        margin: 15,
        flexDirection : 'column'
    },
    backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%'
    },
    about_description : {
        flexDirection : 'column'
    },
    image_body : {
        marginTop: 15 * ratioX
    },
    image : {
        height : 'auto',
        width: '100%',
        overflow : 'scroll',
        paddingTop : 10,
        flexDirection: 'row',
        flexWrap : 'wrap'
    },
    place_img : {
        borderRadius: 10,
        width: '30%',
        height: 100 * ratioX,
        resizeMode: "stretch",
        margin : 5 * ratioX
    },
    date: {
        flexDirection : 'row'
    },
    
    black_label : {
        height: '100%',
        alignItems: 'center',
        alignSelf : "center",
        fontSize: 18 * ratioX,
        color: 'black',
        marginTop: 6 * ratioX,
    },
    label : {
        height: '100%',
        alignItems: 'center',
        alignSelf : "center",
        fontSize: 18 * ratioX,
        color: 'white',
        marginTop: 6 * ratioX,
    },
    btn_group : {
        width : '100%',
        flexDirection : 'row'
    },
    cyan_btn : {
        width: '20%',
        height: 40 * ratioX,
        borderRadius: 40,
        alignSelf : "center",
        backgroundColor: '#4f80ff',
        shadowColor: '#809adc',
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.4,
        shadowRadius: 7, 
        flex : 3 ,
        elevation : 3.5,
        margin : 10 * ratioX
    },
    white_btn : {
        width: '40%',
        margin : 10 * ratioX,
        height: 40 * ratioX,
        borderRadius: 40,
        alignSelf : "center",
        backgroundColor: 'white',
        flex : 3,
    },
    black_label : {
        height: '100%',
        alignItems: 'center',
        alignSelf : "center",
        fontSize: 18 * ratioX,
        color: 'black',
        marginTop: 6,
    },
    label : {
        height: '100%',
        alignItems: 'center',
        alignSelf : "center",
        fontSize: 18 * ratioX,
        color: 'white',
        marginTop: 6,
    },


    componentCard: {
        width : '100%',
        height: 110 * ratioX,
        borderColor : '#e4e2e2',
        borderWidth : 1,
        // shadowRadius: 30,
        // shadowOffset : { width : 0, height : 0},
        // shadowColor : '#cccbcb',
        // shadowOpacity: 1,
        borderRadius : 10,
        marginTop: 5 * ratioX,
        marginBottom: 5 * ratioX,
        flexDirection : 'row'
    },
    image : {
        width : 100 * ratioX,
        height : 100 * ratioX,
        alignItems: 'center',
        alignSelf : 'center',
        marginLeft : 5 * ratioX,
        borderRadius : 5,
        marginRight : 0
    },
    
    body : {
        flexDirection: 'column',
        padding: 10,
    },
    time : {
        flexDirection: 'row',
        marginTop : 8 * ratioX
    },
    icon : {
        width : 15 * ratioX,
        height : 15 * ratioX,
        resizeMode : "stretch",
        alignSelf : 'center'
    },
    title : {
        fontSize : 18 * ratioX,
        fontWeight : '600',
        overflow: "hidden",
        width : 200 * ratioX,
    },
    icon_inbox : {
        width: 15 * ratioX,
        height: 15 * ratioX,
        marginTop: 3 * ratioX,
        alignSelf : 'center',
        resizeMode : "stretch"
    },
    icon_body : {
        marginTop: 8 * ratioX,
        width: '100%',
        flexDirection: 'row',
    },
    icon_like : {
        width: 15 * ratioX,
        height: 15 * ratioX,
        marginTop: 3 * ratioX,
        alignSelf : 'center',
        resizeMode : "stretch"
    },
    trip_icon : {
        position: 'absolute', width : 70 * ratioX, height : 20 * ratioX, alignSelf : 'center', bottom : 10, resizeMode : 'stretch'
    },
    profile: {
        width: '100%',
        //position : 'absolute',
        elevation : Platform.OS == 'android' ?10 : 0.1,
        top: 30,
        zIndex : 999
    },
    profile_img : {
        width: 115 * ratioX,
        height : 115 * ratioX,
        alignSelf : "center",
        zIndex : 999
    },
})
export default FriendInvitation