import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,TouchableOpacity,TextInput,ScrollView,Dimensions, Platform} from 'react-native';
import global_style from  '../../constants/globalStyles';
import { Input , Avatar} from 'react-native-elements';
import NotificationService from '../../services/notification.service';
import PlanService from '../../services/plan.service';
import { inject, observer } from 'mobx-react';

const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const ratioX = screenWidth / 360;
const ratioY = screenHeight / 896;

@inject ('notificationService')
@inject ('planService')
@observer

class PlanInvitation extends Component {
    _planService : PlanService = this.props.planService
    _notificationService : NotificationService = this.props.notificationService
    static navigationOptions = ({ navigation }) => {
        return {
            headerLeft: (
                <View style={global_style.navigation}>
                    <TouchableOpacity 
                        style={styles.backarrow}
                        onPress={() => navigation.goBack()} >
                            <Image source = {require('../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                            <Text style={global_style.back_title}>Invitation By John D</Text>
                    </TouchableOpacity>
                </View>
            ),
            headerStyle: global_style.headerHeight
        };
    };
    constructor (props) {
        super(props)
        this.state = {
            starCount : 4,
            height : 0,
            plan_data : null,
            send_user : null
        }
    }
    
    componentWillMount () {
        this.getPlanData(this.props.noti_data.plan_id)
        this.setState({send_user : this.props.noti_data.send_uid})
        
        if (this.props.noti_data.is_read != 1) {
            var upgrade_data = this.props.noti_data;
            upgrade_data.send_uid = this.props.noti_data.send_uid.uid
            upgrade_data.is_read = 1;
            this._notificationService.updateNotification(upgrade_data.id, upgrade_data).then((result) => {
                console.log(result) //update notification
            }).catch((error) => {
                console.log(error)
            })
        }
    }
    getPlanData(id) {
        this._planService.getDataByf_id(id).then((result)=>{
            if (result.exists) {
                this.setState({plan_data : result.data()})
            }
        }).catch((error)=> {

        })
    }
    render() {
        return (
            <ScrollView style={{width: '100%', height : '100%'}}>
                <View style={styles.profile}>
                    <Avatar
                        rounded
                        overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                        size="xlarge"
                        source = {{uri : this.state.send_user.img_url}}
                        containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                        style={styles.profile_img}
                    />
                </View>
                {
                    this.state.plan_data == null ? null :
                    <View style={styles.body}>
                        <View style={styles.info_body}>
                            <View style={{marginTop: 60 * ratioX}}></View>
                            <Text style={{textAlign : "center", fontSize : 17 * ratioX, fontWeight : '600', marginBottom : 5 * ratioX}}>{this.state.plan_data.address.name}</Text>
                            <Text style={{textAlign : "center", fontSize : 14 * ratioX, marginBottom : 5 * ratioX}}>{this.state.plan_data.address.city_name.city_name} {this.state.plan_data.address.city_name.country_name}</Text>
                            <View style={styles.date}>
                                <Text style={styles.bold_label}>From : </Text>
                                <Text style={{fontSize: 13 * ratioX, alignSelf : 'center'}}> {this.state.plan_data.from_date}</Text>
                            </View>
                            <View style={styles.date}>
                                <Text style={styles.bold_label}>To : </Text>
                                <Text style={{fontSize: 13 * ratioX, alignSelf : 'center'}}> {this.state.plan_data.to_date}</Text>
                            </View>
                            <View style={styles.about_description}>
                                <Text style={styles.bold_label}>About Plan</Text>
                                <Text style={styles.description}>
                                    {this.state.plan_data.description}
                                </Text>
                            </View>
                            <View style={styles.image_body}>
                                <Text style={styles.bold_label}>Images</Text>
                                <View style={styles.image}>
                                    {
                                        this.state.plan_data.address.photo_arr.map((item, index) => {
                                            return (<Image source = {{uri : item}} style={styles.place_img} key={index}/>)        
                                        })
                                    }
                                </View>
                            </View>
                        </View>
                        
                    </View>
                }
                
            </ScrollView>
        )
    }
}
const styles = StyleSheet.create({
    body : {
        alignItems: 'center',
        alignSelf : "center",
        marginTop:90 * ratioX,
        marginBottom :90 * ratioX,
        width : '100%',
        borderRadius: 15,
        backgroundColor : 'white',shadowOffset : {width: 0, height: 4}, 
        shadowRadius: 10, 
        shadowOpacity : 0.5,
        elevation : Platform.OS == 'ios' ? 1 : 10,
    },
    profile: {
        width: '100%',
        position : 'absolute',
        top: 30,
        elevation : Platform.OS == 'android' ?10 : 0.1,
        zIndex : 999
    },
    profile_img : {
        width: 115 * ratioX,
        height : 115 * ratioX,
        alignSelf : "center",
    },
    info_body: {
        //shadowColor:'#d4d3d3',
        width: '100%',
        overflow : 'hidden',
        padding : 10,
        borderRadius: 15,
        flexDirection : 'column',
        backgroundColor : 'white',
    },
    item : {
        margin: 15 * ratioX,
        flexDirection : 'column'
    },
    backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%'
     },
     about_description : {
        flexDirection : 'column',
        marginTop : 10 * ratioX
     },
     description : {
        fontSize : 12 * ratioX,
        marginTop : 10 * ratioX,
        marginLeft: 5 * ratioX
     },
     image_body : {
        marginTop: 15 * ratioX
     },
     image : {
        height : 'auto',
        width: '100%',
        overflow : 'scroll',
        paddingTop : 10,
        flexDirection: 'row',
        flexWrap : 'wrap'
     },
     place_img : {
        borderRadius: 10,
        width: '30%',
        height: 100,
        resizeMode: "stretch",
        margin : 5 * ratioX
     },
     bold_label : {
        fontWeight : '600', fontSize : 15 * ratioX
     },
     date: {
         flexDirection : 'row'
     },
     
     bottom: {
        borderTopWidth : 1,
        borderTopColor: '#f1f1f1',
        flexDirection: 'row',
        alignItems : 'center',
        bottom: 0,
        width: '100%',
        height : 60 * ratioX,
        shadowOffset : { width : 0, height : -10},
        shadowColor : '#d8d8d8',
        shadowRadius : 20,
        shadowOpacity : 0.7,
        position : 'absolute', //made by martin
        flexDirection : 'row',
        flex : 10,
        
     },
     cyan_btn : {
        width: '40%',
        height: 40 * ratioX,
        borderRadius: 40,
        alignSelf : "center",
        backgroundColor: '#4f80ff',
        shadowColor: '#809adc',
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.4,
        shadowRadius: 7, 
        flex : 3 ,
        elevation : 3.5
     },
     white_btn : {
        width: '40%',
        height: 40 * ratioX,
        borderRadius: 40,
        alignSelf : "center",
        backgroundColor: 'white',
        flex : 3,
        elevation : 3.5
     },
     black_label : {
        height: '100%',
        alignItems: 'center',
        alignSelf : "center",
        fontSize: 18,
        color: 'black',
        marginTop: 6 * ratioX,
     },
     label : {
        height: '100%',
        alignItems: 'center',
        alignSelf : "center",
        fontSize: 18 * ratioX,
        color: 'white',
        marginTop: 6,
     },
})
export default PlanInvitation