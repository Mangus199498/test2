import React, { Component } from 'react'
import { View, Text, TouchableOpacity, TextInput, StyleSheet , Image, ScrollView, ToastAndroid ,AsyncStorage , Alert , Platform, NativeModules} from 'react-native' //_getData
import { StackActions, NavigationActions } from 'react-navigation'
import { inject, observer } from "mobx-react";
import { GoogleSignin,statusCodes } from 'react-native-google-signin';
import checkImg from '../../assets/img/icon/ico_checked.png';
import unCheckImg from '../../assets/img/icon/ico_uncheck.png';
import { LoginManager , AccessToken} from 'react-native-fbsdk';
import PropTypes from 'prop-types'
import AuthService from '../../services/auth.service';
import UserService from '../../services/user.service';
import firebase from 'react-native-firebase';
//const { RNTwitterSignIn} = NativeModules
import global_style, {metrics} from  '../../constants/globalStyles'
import { encryptString ,decryptString} from '../../utils/utils';

GoogleSignin.configure({
    scopes: ['https://www.googleapis.com/auth/drive.readonly'], // what API you want to access on behalf of the user, default is email and profile
    webClientId: '990212510702-6qte1v7kl51qv59ic3q0m844ai8ieq0v.apps.googleusercontent.com', // client ID of type WEB for your server (needed to verify user ID and offline access)
    offlineAccess: true, // if you want to access Google API on behalf of the user FROM YOUR SERVER
});

const resetAction = (routeName) => StackActions.reset({
    index: 0,
    actions: [
      NavigationActions.navigate({routeName: routeName}),
    ]
  });

@inject('authService')
@inject('userService')
@observer

class LoginComponent extends Component {
    
    _authService : AuthService = this.props.authService ;
    _userService : UserService = this.props.userService;
    auto_flag = 'false'
    userData  = null;

    constructor(props) {
        super(props)
        this.state = {
            email: '',
            password: '',
            remember_me : false,
            btn_flag : false,
            validate : {
                email : false
            },
            isShowForget : false,
            userInfo : null,
            hiddenPassword : true,
            errorMessage : '',
            errorStatus : false
        }
    }
    getCurrentUser = async () => {
        const currentUser = await GoogleSignin.getCurrentUser();
        return currentUser;
    };
    async componentWillMount () {
        this.setState({hiddenPassword : true})
        this.setState({email : ''})
        this.setState({password : ''})
        this.setState({btn_flag : false}) //this is login button state is init

        await this._retrieveData()
        if (this.auto_flag == 'true') { //auto login
            
            this.getCurrentUser().then((result)=>{
                if (result == null) { //sign out
                    this.normalSignInHistory();
                    return;
                } else {
                    var user = result.user
                    this.props.isLoadingFunc(true)
                    this._userService.getUserDataByEmail(user.email).then((res)=>{
                        const data = res.docs.map(doc => doc.data());
                        global.user_info = data[0];
                        this.props.navigation.dispatch(resetAction('TabsPage'));
                        this.props.isLoadingFunc(false)
                    }).catch((error) => {
                        console.log(error)
                        this.props.isLoadingFunc(false)
                    })
                }
                
            }); //google account
            
        }
    }
    normalSignInHistory () {
        this.props.isLoadingFunc(true)    
        this._userService.getCurrentAuthInfo().then((res) => {
            if (res == null || res == undefined) { //not exist user
                this.props.isLoadingFunc(false)
                return;
            } else {
                this._userService.getUserData(res._user.uid).then((result) => {
                    if (result.exists) {
                        
                        global.user_info = result.data();
                        this.props.navigation.dispatch(resetAction('TabsPage'));
                        this.props.isLoadingFunc(false);
                    }
                }).catch((error) => {
                    this.props.isLoadingFunc(false);
                    console.log(error)
                })
            }
        }).catch((error) => {
            this.setState({errorStatus : true})
            this.setState({errorMessage : error.message})
            this.props.isLoadingFunc(false)
        })
    }

    handleEmail = (text) => {
        this.setState({ email: text })
    }
    handlePassword = (text) => {
        this.setState({ password: text })
    }

    _storeData = async (flag) => {
        var text = ''
        if (flag)
            text = 'true'
        else
            text = 'false'
        try {
            await AsyncStorage.setItem('remember_flag', text);
        } catch (error) {

        }
      };

    _retrieveData = async () => {
        try {
            const value = await AsyncStorage.getItem('remember_flag');
            this.auto_flag = value
            if (value !== null) {
                if (value == 'true')
                    this.setState({remember_me : true})
                else
                    this.setState({remember_me : false})
                this.auto_flag = value
            }
        } catch (error) {

        }
    }
    login = () => {
        this.setState({btn_flag : true})
        if (!this.state.validate.email || this.state.email == '' || this.state.password.length < 6) {
           return;
        }
        this.props.isLoadingFunc(true)
        this._authService.signInWithEmailPassword(this.state.email, this.state.password).then((res) => {
            this._userService.getUserData(res.user.uid).then((result) => {
                if (result.exists) {
                    global.user_info = result.data()
                    this.props.navigation.dispatch(resetAction('TabsPage'))
                    this.props.isLoadingFunc(false)
                }
            }).catch((error) => {
                this.props.isLoadingFunc(false);
                console.log(error)
            })
            
        }).catch((error) => {
            this.props.isLoadingFunc(false);
            this.setState({errorStatus : true})
            this.setState({errorMessage : error.message})
            setTimeout(() => {
                this.setState({errorMessage : ''})
            }, 5000);
        })
    }
    saveUserData(data) {
        this.userData = data;
    }

    //social login
    googleLogin = async () => {
        try {
            await GoogleSignin.hasPlayServices();
            const userInfo = await GoogleSignin.signIn()
            this.props.isLoadingFunc(true)
            const credential = await firebase.auth.GoogleAuthProvider.credential(userInfo.idToken, userInfo.accessToken)
            firebase.auth().signInWithCredential(credential).then(result => {
                this.gotoGoogleInfo(result.additionalUserInfo.profile)
                this.initStorage()
            }).then((error) => {
                Alert.alert(  
                    '',  
                    error.message,  
                    [  
                          {text: 'OK', onPress: () => console.log('Ask me later pressed')},
                    ],  
                    {cancelable: false}  
                )
            })
        } catch (error) {
            this.props.isLoadingFunc(false)
        }
    }


    gotoGoogleInfo = (userInfo) => {
        this._userService.getGoogleUser(userInfo.email).then((result) => {
            var user = userInfo
            const data = result.docs.map(doc => doc.data());
            if (data.length == 0) { // add new user by google account
                var obj = {
                    email : user.email,
                    f_name : user.family_name,
                    l_name : user.given_name,
                    img_url : user.picture,
                    gender : 0,
                    phone_number : '',
                    token: '',
                    uid : '',
                    google : true,
                    created_at : '',
                    membership : 'free',
                    country_code : ''
                }
                this._userService.addSocialUser(obj).then((result) => {
                    this._userService.getGoogleUser(obj.email).then((result)=>{
                        const data = result.docs.map(doc => doc.data());
                        global.user_info = data[0]
                        this.props.navigation.dispatch(resetAction('TabsPage'));   
                        this.props.isLoadingFunc(false)
                    })
                }).catch((error) => {
                    this.props.isLoadingFunc(false)
                    console.log(error)
                })
            } else { // exist user account
                this._userService.getGoogleUser(user.email).then((result)=>{
                    const data = result.docs.map(doc => doc.data());
                    global.user_info = data[0];
                    this.props.navigation.dispatch(resetAction('TabsPage'));
                    this.props.isLoadingFunc(false)
                })
            }
        }).catch((error) => {
            console.log(error)
            this.props.isLoadingFunc(false)
        })
    }

    gotoHomeByFB = (userinfo) => {
        //alert(userinfo.email)
        this.props.isLoadingFunc(true)
        this._userService.getFBUser(userinfo.email).then((res) => {
            const data = res.docs.map(doc => doc.data());
            if (data == '' || data.length == 0) {
                var user = {
                    email : userinfo.email,
                    f_name : userinfo.displayName.split(' ')[1],
                    l_name : userinfo.displayName.split(' ')[0],
                    img_url : userinfo.photoURL,
                    gender : 0, 
                    phone_number : userinfo.phoneNumber,
                    token: '',
                    uid : '',
                    fb : true,
                    created_at : new Date(),
                    membership : 'free',
                    country_code : ''
                }

                this._userService.addSocialUser(user).then((result) => {
                    this._userService.getFBUser(user.email).then((res) => {
                        const data = res.docs.map(doc => doc.data());
                        if (data.length > 0) {
                            global.user_info = data[0];
                            this.props.navigation.dispatch(resetAction('TabsPage'));
                            this.props.isLoadingFunc(false)
                        } else {
                            this.props.isLoadingFunc(false)
                        }
                    }).catch((error) => {
                        this.props.isLoadingFunc(false)
                    })
                }).catch((error) => {
                    this.props.isLoadingFunc(false)
                }) 
            } else {
                this._userService.getFBUser(userinfo.email).then((res) => {
                    const data = res.docs.map(doc => doc.data());
                    if (data.length > 0) {
                        global.user_info = data[0];
                        this.props.navigation.dispatch(resetAction('TabsPage'));
                        
                        this.props.isLoadingFunc(false)
                    } else {
                        this.props.isLoadingFunc(false)
                    }
                }).catch((error) => {
                    this.props.isLoadingFunc(false)
                })
                
            }
        })
        
    }
    fbLogin = () => {
        LoginManager.logInWithPermissions(["public_profile", "email"])
            .then(result => {
                if (result.isCancelled) {
                    console.log("Login was cancelled");
                }
                //alert('cancel')
                return AccessToken.getCurrentAccessToken();
            })
            .then(data => {
                const credential = firebase.auth.FacebookAuthProvider.credential(
                    data.accessToken
            );
            
            firebase.auth().signInWithCredential(credential).then(result => {
                this.initStorage()
                this.gotoHomeByFB(result.user._user.providerData[0])
            })
            .catch(error => {
                Alert.alert(  
                    '',  
                    error.message,  
                    [  
                          {text: 'OK', onPress: () => console.log('Ask me later pressed')},
                    ],  
                    {cancelable: false}  
                )
                });
            })
        .catch(err => {
            // Alert.alert(  
            //     '',  
            //     err.message,  
            //     [  
            //           {text: 'OK', onPress: () => console.log('Ask me later pressed')},
            //     ],  
            //     {cancelable: false}  
            // )
        }); 
    }
    twitterLogin = async() => {
        // try {
        //     RNTwitterSignIn.init(config.twitterConsumerKey, config.twitterSecretKey);
        //     // also includes: name, userID & userName
        //     const { authToken, authTokenSecret } = await RNTwitterSignIn.logIn();
        //     const credential = firebase.auth.TwitterAuthProvider.credential(authToken, authTokenSecret);
        //     await firebase.auth().signInWithCredential(credential).then(result => {
        //         if (firebaseUserCredential) {
        //             this.initStorage()
        //             this.gotoHomebyTwitter(firebaseUserCredential.user.toJSON())
        //         }
        //     }).catch(error => {
        //         Alert.alert(  
        //             '',  
        //             error.message,  
        //             [  
        //                   {text: 'OK', onPress: () => console.log('Ask me later pressed')},
        //             ],  
        //             {cancelable: false}  
        //         )  
        //     })
        // } catch (e) {
        //     console.log(e);
        // }
    }
    //init 
    initStorage = async() => {
        await AsyncStorage.setItem("remember_flag", 'false')
    }

    gotoHomebyTwitter = (loginData) => {
        var userid = loginData.uid //this is id
        var user_info = loginData.providerData[0]
        
        this.props.isLoadingFunc(true)
        this._userService.getTwitterUser(loginData.userid).then((result) => {
            const data = result.docs.map(doc => doc.data());
            if (data == '' || data.length == 0) { // add new user by google account
                var obj = {
                    email : user_info.email,
                    f_name : user_info.displayName,
                    l_name : '',
                    img_url: user_info.photoURL,
                    gender : 0,
                    phone_number : '',
                    token: '',
                    uid :'',
                    twitter : true,
                    created_at : new Date(),
                    membership : 'free',
                    country_code : ''
                }
                
                this._userService.addSocialUser(obj).then((result) => {
                    this._userService.getTwitterUser(obj.email).then((res)=>{
                        const data = res.docs.map(doc => doc.data());
                        global.user_info = data[0]
                        this.props.navigation.dispatch(resetAction('TabsPage'));   
                        this.props.isLoadingFunc(false)
                    })
                }).catch((error) => {
                    this.props.isLoadingFunc(false)
                    console.log(error)
                })
            } else {
                this._userService.getTwitterUser(data[0].email).then((res)=>{
                    const userinfo = res.docs.map(doc => doc.data());
                    global.user_info = userinfo[0]
                    this.props.navigation.dispatch(resetAction('TabsPage'));   
                    this.props.isLoadingFunc(false)
                })
            }
        })
    }
    //
    //
    signup = () => {
        this.props.navigation.navigate('SignUpScreen');
    }
    checkedRemember = () => {
        if (this.state.email == '' && this.state.password == '' && !this.state.remember_me) {
            Alert.alert(
                '',
                'There is no email and password to remember!',
                [
                    {
                        text : 'OK',
                        onPress: ()=> console.log('ok')
                    },
                ]
            )
            return;
        }
        
        if (this.state.remember_me) {
            this._storeData(false)
            this.setState({remember_me : false});
        } else {
            this._storeData(true)
            this.setState({remember_me : true});
        }
        
    }
    gotoForgot = () => {
        this.props.navigation.navigate('ForgotPasswordScreen')
        this.setState({isShowForget : true})
    }
    hideModal = () => {
        this.setState({isShowForget : false})
    }
    validateText = (text) => {
        let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;
        if(reg.test(text) === false)
        {
           this.setState({validate : { email : false} })
           this.setState({email:text})
           return false;
        }
        else {
           this.setState({validate : { email : true} })
           this.setState({email:text})
        }
    }
    showPassword = () => {
        if (this.state.hiddenPassword) {
            this.setState({hiddenPassword : false})
        } else {
            this.setState({hiddenPassword : true})
        }
    }

    render() {
        return (
            <View style={{width: '100%', height : '100%'}}>
                <View style={styles.container}>
                    <View style={styles.item_body}>
                        <View style ={styles.text_body}>
                            <Image source = {require('../../assets/img/icon/ico_email.png')} style={styles.email_icon}/> 
                            <TextInput style = {styles.input}
                                underlineColorAndroid = "transparent"
                                placeholder = "Email or Username"
                                placeholderTextColor = "gray"
                                autoCapitalize = "none"
                                onChangeText={(text) => this.validateText(text)}
                                />
                        </View>
                        <Text style={(this.state.btn_flag && this.state.email == '') ? styles.error : styles.non_error}> Email is required.</Text>
                        <Text style={(this.state.btn_flag && !this.state.validate.email && this.state.email != '') ? styles.error : styles.non_error}> Please enter a valid email.</Text>
                    </View>
                    <View style={styles.item_body}>
                        <View style={styles.text_body}>
                            <Image source = {require('../../assets/img/icon/ico_password.png')} style={styles.lock_icon}/>
                            <TextInput style = {styles.input}
                                underlineColorAndroid = "transparent"
                                placeholder = "Password"
                                placeholderTextColor = "gray"
                                autoCapitalize = "none"
                                secureTextEntry={this.state.hiddenPassword} 
                                selectionColor="transparent"
                                onChangeText = {this.handlePassword}/>
                            <TouchableOpacity onPress={()=>this.showPassword()} style={{ position : 'absolute', right : 5}}>
                                <Image source={require('../../assets/img/icon/ico_eye.png')} style={styles.icon_eye}></Image>
                            </TouchableOpacity>
                        </View>
                        <Text style={(this.state.btn_flag && this.state.password.length < 6) ? styles.error : styles.non_error}>Password must be at least 6 characters long.</Text>
                    </View>
                    
                    <View style={styles.check_body}>
                        <TouchableOpacity style={styles.body} onPress={() => this.checkedRemember()}>
                            {
                                this.renderCheckBtn()
                            }
                            <Text style={styles.remember_text}>Remember me</Text>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={() => this.gotoForgot()}>
                            <Text style={styles.password}>Forgot Password?</Text>
                        </TouchableOpacity>
                    </View>

                    {/* this is error message  */}
                    { 
                        this.state.errorStatus && this.state.btn_flag ? 
                        <View style={{width : '100%', marginBottom : 5, marginTop : 15}}>
                            <Text style={{textAlign : 'center', color : 'red'}}>{this.state.errorMessage}</Text>
                        </View>
                        : null
                    }
                    {/* this is error message  */}
                    
                    <TouchableOpacity onPress={() => this.login()} style={styles.cyan_btn}>
                        <Text style={styles.label}>Login</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => this.signup()} style={styles.white_btn}>
                        <Text style={styles.cyan_label}>Register</Text>
                    </TouchableOpacity>
                    <View style={styles.social_body}>
                        <View style={styles.social_title}>
                            <Text>Or Via Social Networks</Text>
                        </View>
                        <View style={styles.social_button}>
                            <View style={{flex : 20}}></View>
                            <View style={{flex : 25}}>
                                <TouchableOpacity onPress={()=> this.googleLogin()}>
                                    <Image source = {require('../../assets/img/icon/google_icon.png')} style={styles.social_icon}/>    
                                </TouchableOpacity>
                            </View>
                            <View style={{flex : 10}}></View>
                            <View style={{flex : 25}}>
                                <TouchableOpacity onPress={()=> this.fbLogin()}>
                                    <Image source = {require('../../assets/img/icon/facebook_icon.png')} style={styles.social_icon}/>
                                </TouchableOpacity>
                            </View>
                            {/* <View style={{flex : 10}}></View>
                            <View style={{flex : 20}}>
                                <TouchableOpacity onPress={()=> this.twitterLogin()}>
                                    <Image source = {require('../../assets/img/icon/twitter_icon.png')} style={styles.social_icon}/> 
                                </TouchableOpacity>
                            </View> */}
                            <View style={{flex : 20}}></View>
                        </View>
                    </View>
                </View>
            </View>
                
        )
   }
   renderCheckBtn () {
        var imgSource  = this.state.remember_me ? checkImg : unCheckImg;
        return <Image source = { imgSource } style={styles.check_icon}/>;
   }
}

LoginComponent.propType = {
    isLoadingFunc : PropTypes.func,
    navigation : PropTypes.obj
}

export default LoginComponent

const styles = StyleSheet.create({
    container: {
        width: '100%',
        height: '100%',
        paddingTop : 30,
        alignItems: 'center'
    },
    text_body : {
        flexDirection : 'row',  
        alignSelf: 'stretch',
        paddingLeft: 10,
        paddingRight: 10,
        width: '90%',
        alignItems: 'center'
    },
    item_body : {
        flexDirection : 'column',
        width: '100%',
        alignSelf: 'center'
    },
    body : {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'stretch'
    },
    social_body : {
        flexDirection : 'column',
        width: '65%',
        alignItems: 'center',
        marginTop :35
    },
    social_button : {
        flexDirection : 'row',
        flex : 100,
        alignItems: "center",
        alignSelf : 'center',
        marginTop : 15,
        marginBottom : 20
    },
    social_title : {
        alignItems: 'center' ,
        alignSelf : 'center',
        marginBottom: 10
    },
    check_body : {
        flexDirection : 'row',
        alignSelf: 'stretch',
        paddingLeft: 17,
        paddingRight: 25,
        paddingTop: 15
    },
    email_icon : {
        height: 17,
        width: 22,
        alignItems: 'center',
        alignSelf : 'center',
        marginLeft: '5%',
        resizeMode: 'stretch'
    },
   
    lock_icon : {
        height:25,
        width: 23,
        alignItems: 'center',
        alignSelf : 'center',
        marginLeft: '5%',
        resizeMode: 'stretch'
    },
    check_icon: {
        height: 20,
        width: 20,
        marginLeft: '5%',
        resizeMode: 'stretch'
    },
    remember_text : {
        alignItems: 'center',
        marginLeft: 8,
    },
    password: {
        alignItems: 'center',
        fontSize: 13,
        textDecorationLine: 'underline'
    },
    input: {
        margin: 15,
        height: 40,
        borderBottomColor: '#d8d8d8',
        borderBottomWidth : 1,
        width: '90%'
    },
    cyan_btn : {
        width: '60%',
        height: 45,
        borderRadius: 40,
        alignItems: 'center',
        alignSelf : 'center',
        marginTop: 20,
        backgroundColor: '#4f80ff',
        borderColor :'#809adc', 
        borderWidth : 1,
        shadowColor: '#809adc',
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.4,
        shadowRadius: 7,  
        marginBottom : 0,
        elevation : 3.5
    },
    white_btn : {
        width: '60%',
        height: 45,
        borderRadius: 40,
        alignItems: 'center',
        marginTop: 20,
        borderColor :'#809adc', 
        borderWidth : 1,
        shadowColor: '#809adc',
        backgroundColor: '#fff',
        borderColor: '#4f80ff',
        borderWidth : 1,
        shadowOffset: { width: 2, height: 2},
        shadowOpacity: 0.4,
        shadowRadius: 7,  
        marginBottom : 0,
        backgroundColor : "#0000",
    },
    label : {
        height: '100%',
        alignItems: 'center',
        fontSize: 22 * metrics,
        color: 'white',
        marginTop : 8 * metrics
    },
    cyan_label : {
        height: '100%',
        alignItems: 'center',
        fontSize: 22 * metrics,
        color: '#4f80ff',
        marginTop : 8 * metrics
    },
    social_icon : {
        width : 50,
        height : 50,
        alignItems: 'center'
    },
    error : {
        color : 'red',
        fontSize : 13,
        alignSelf: 'stretch',
        paddingLeft: 60,
        paddingRight: 10,
        alignItems: 'center'
     }, 
     non_error : {
        display : 'none',
        alignSelf : 'center'
     },
    icon_eye : {
        width : 25, height : 20,resizeMode :'stretch',
    }
})