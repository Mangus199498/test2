import React, { Component } from 'react'
import { View, Text, TouchableOpacity, TextInput, StyleSheet , Image, ScrollView, ToastAndroid ,AsyncStorage} from 'react-native' //_getData
import { StackActions, NavigationActions } from 'react-navigation'
import { inject, observer } from "mobx-react";
import checkImg from '../../assets/img/icon/ico_checked.png';
import unCheckImg from '../../assets/img/icon/ico_uncheck.png';
import global_style, { metrics } from '../../constants/globalStyles';
import PropTypes from 'prop-types';

import LoadingBar from '../../components/LoadingBar';
import {showAlert} from '../../components/Alert';

import AuthService from '../../services/auth.service';
import UserService from '../../services/user.service';
import {encryptString,decryptString} from '../../utils/utils'

@inject('authService')
@inject('userService')
@observer

class ForgotPasswordScreen extends Component {
    
    _authService : AuthService = this.props.authService ;
    _userService : UserService = this.props.userService;
    userData  = null;
    constructor(props) {
        super(props)
        this.state = {
            btn_flag : false,
            validate : false,
            email : '',
            step : 1,
            rnkey : '',
            first : '',
            second : '',
            third : '',
            forth : '',
            password : '',
            confirm_password : '',
            isLoading : false
        }
    }

    static navigationOptions = ({ navigation }) => {
        const { params = {} } =  navigation.state;
        return {
            headerLeft: (
                <View style={global_style.navigation}>
                    <TouchableOpacity 
                        style={styles.backarrow}
                        onPress={() => navigation.goBack()} >
                            <Image source = {require('../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                            <Text style={[global_style.back_title, {fontSize : 22 * metrics}]}>FORGOT PASSWORD</Text>
                    </TouchableOpacity>
                </View>
            ),
            headerStyle: global_style.headerHeight,
        }
     };
    validateText = (text) => {
        let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;
        if(reg.test(text) === false)
        {
           this.setState({validate : false })
           this.setState({email:text})
           return false;
        }
        else {
           this.setState({validate : true})
           this.setState({email:text})
        }
    }
    componentWillMount () {
        
    }
    resetBtn =() => {
        //console.log(this.state.email)
        this.setState({btn_flag : true})
        if (this.state.email == '')
            return;
        this.setState({isLoading : true})
        this._userService.getUserDataByEmail(this.state.email).then((result) => {
            const data = result.docs.map(doc => doc.data());
            if (data.length == 0) { // user info is not exist
                showAlert('', 'User email is not exist!')
                this.setState({isLoading : false})
            } else {
                this._userService.sendEmail(this.state.email).then((result) => {//this.state.email
                    this.setState({rnkey : result.rnKey.toString()});
                    this.setState({step : 2})
                    this.setState({btn_flag :false})
                    this.setState({isLoading : false})        
                }).catch((error) => {
                    console.log(error)
                    this.setState({isLoading : false})        
                })
            }
        }).catch((error) => {
            this.setState({isLoading : false})
        })
        
    } 
    verifyBtn = () => {
        var user_num = parseFloat(this.state.first + this.state.second + this.state.third + this.state.forth);
        if (user_num == this.state.rnkey) {
            this.setState({step : 3}) //go to change password
        } else {
            showAlert('', 'Verify Code is incorrect!')
        }
    }
    changePassword = () => {
        this.setState({btn_flag : true})
        if (this.state.password != this.state.confirm_password || this.state.password.length < 6 || this.state.confirm_password.length < 6) {
            return;
        }
        this.setState({isLoading : true})
        this._userService.getUserDataByEmail(this.state.email).then((result) => { //this.state.email
            const data = result.docs.map(doc => doc.data())[0];
            var password = decryptString(data.token)
            this._authService.signInWithEmailPassword(this.state.email, password).then((res) => {
                this._userService.changePassword(this.state.password).then((result) => {
                    data.token = encryptString(this.state.password);
                    this._userService.updateUser(data).then((final_res) => {
                        this._authService.signOut();
                        this.setState({isLoading : false})
                        this.props.navigation.navigate('LoginScreen')
                    })
                }).catch((error) => {
                    console.log(error)
                    this.setState({isLoading : false})
                })
            }).catch((error) => {
                console.log(error)
                this.setState({isLoading : false})
            })
        }).catch((error) => {
            console.log(error)
            this.setState({isLoading : false})
        })
    }

    renderbody() {
        if (this.state.step == 1) { // email sender
            return (
                <View style={styles.message_body}>
                    <View style={{flex : 30}}></View>
                    <View style={{flex : 50}}>
                        <Text style={styles.title}>We just need your registered email address to send you password reset.</Text>
                        <View style={styles.item_body}>
                            <View style ={styles.text_body}>
                                <TextInput style = {styles.input}
                                    underlineColorAndroid = "transparent"
                                    placeholder = "Email or Username"
                                    placeholderTextColor = "gray"
                                    autoCapitalize = "none"
                                    value = {this.state.email}
                                    onChangeText={(text) => this.validateText(text)}
                                    />
                            </View>
                            <Text style={(this.state.btn_flag && !this.state.validate) ? styles.error : styles.non_error}> Email is required.</Text>
                        </View>

                        
                    </View>
                    <View style={global_style.register_btn}>
                        <TouchableOpacity onPress={() => this.resetBtn()} style={styles.cyan_btn}>
                            <Text style={styles.label}>Reset</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            )
        } else if (this.state.step == 2) { // verify 
            return (
                <View style={styles.message_body}>
                    <View style={{flex : 30}}></View>
                    <View style={{flex : 50}}>
                        <Text style={styles.title}>We just need your registered email address to send you password reset.</Text>
                        <View style={styles.item_body}>
                            <View style ={styles.verify_body}>
                                <View style={{flex : 25}}>
                                    <TextInput style = {styles.verify_input}
                                        underlineColorAndroid = "transparent"
                                        placeholder = ""
                                        placeholderTextColor = "gray"
                                        autoCapitalize = "none"
                                        value = {this.state.first}
                                        keyboardType={'numeric'}
                                        maxLength = {1}
                                        onChangeText={(text) => this.setState({first: text})}
                                    />
                                </View>
                                <View style={{flex : 25}}>
                                    <TextInput style = {styles.verify_input}
                                        underlineColorAndroid = "transparent"
                                        placeholder = ""
                                        placeholderTextColor = "gray"
                                        autoCapitalize = "none"
                                        value = {this.state.second}
                                        keyboardType={'numeric'}
                                        maxLength = {1}
                                        onChangeText={(text) => this.setState({second: text})}
                                    />
                                </View>
                                <View style={{flex : 25}}>
                                    <TextInput style = {styles.verify_input}
                                        underlineColorAndroid = "transparent"
                                        placeholder = ""
                                        placeholderTextColor = "gray"
                                        autoCapitalize = "none"
                                        value = {this.state.third}
                                        keyboardType={'numeric'}
                                        maxLength = {1}
                                        onChangeText={(text) => this.setState({third: text})}
                                    />
                                </View>
                                <View style={{flex : 25}}>
                                    <TextInput style = {styles.verify_input}
                                        underlineColorAndroid = "transparent"
                                        placeholder = ""
                                        placeholderTextColor = "gray"
                                        autoCapitalize = "none"
                                        value = {this.state.forth}
                                        keyboardType={'numeric'}
                                        maxLength = {1}
                                        onChangeText={(text) => this.setState({forth: text})}
                                    />
                                </View>
                            </View>
                        </View>
                    </View>
                    <View style={{flex : 20}}>
                        <View style={[global_style.register_btn, {marginTop : 30}]}>
                            <TouchableOpacity onPress={() => this.verifyBtn()} style={styles.cyan_btn}>
                                <Text style={styles.label}>Verify</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            )
        } else if (this.state.step == 3) { // change password
            return (
                <View style={{width : '100%', flex: 100, flexDirection : 'column'}}>
                    <View style={{flex : 20}}></View>
                    <View style={{flex : 10}}>
                        <Text style={styles.title}>We just need your registered email address to send you password reset.</Text>
                    </View>
                    <View style={{flex :30}}>
                        <View style={[global_style.wrapper, {width : '90%', alignSelf : 'center'}]}>
                            <Text style={styles.sub_title}>Password</Text>
                                <TextInput 
                                    underlineColorAndroid = "transparent"
                                    placeholder = ""
                                    placeholderTextColor = "gray"
                                    autoCapitalize = "none"
                                    onChangeText={(text) => this.setState({password : text})}
                                    style={global_style.text_input}
                                    secureTextEntry={true} 
                                />
                                <Text style={(this.state.btn_flag && this.state.password.length < 6) ? styles.password_error : styles.non_error}> Password must be at least 6 characters long.</Text>
                            </View>
                        <View style={[global_style.wrapper,{width : '90%', alignSelf : 'center'}]}>
                            <Text style={styles.sub_title}>Confrim Password</Text>
                            <TextInput 
                                underlineColorAndroid = "transparent"
                                placeholder = ""
                                placeholderTextColor = "gray"
                                autoCapitalize = "none"
                                onChangeText={(text) => this.setState({confirm_password : text})}
                                style={global_style.text_input}
                                secureTextEntry={true} 
                            />
                            <Text style={(this.state.btn_flag && this.state.confirm_password.length < 6)  ? styles.password_error : styles.non_error}> Password must be at least 6 characters long.</Text>
                            <Text style={(this.state.btn_flag && (this.state.confirm_password != this.state.password) && (this.state.confirm_password.length > 6 && this.state.password.length > 6))  ? styles.error : styles.non_error}>Mismatch password. Please check it.</Text>
                        </View>
                    </View>
                    <View style={global_style.register_btn}>
                        <TouchableOpacity onPress={() => this.changePassword()} style={styles.cyan_btn}>
                            <Text style={styles.label}>Change Password</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            )
        }
    }
    render() {
        return (
            <View style={styles.body}>
                {
                    this.renderbody()
                }
                <View style={this.state.isLoading ? styles.loading : styles.finish}>
                    <LoadingBar/>
                </View>
            </View>
        )
   }
}
export default ForgotPasswordScreen

const styles = StyleSheet.create({
    body : {
        width: '100%',
        height : '100%',
        alignSelf :'center',
    },
    item_body : {
        flexDirection : 'column',
        width: '100%',
        alignSelf: 'center',
        marginTop : 40,
    },
    verify_body : {
        flexDirection : 'row',
        flex : 100,
        //backgroundColor : 'green',
        alignSelf : 'center'
    },
    message_body : {
        backgroundColor : 'white', 
        width : '90%', 
        alignSelf : 'center', 
        flex : 100,
        flexDirection : 'column'
    },
    title : {
        fontSize : 20, 
        textAlign : 'center', 
        alignSelf : 'center'
    },
    verify_input : {
        textAlign : 'center',
        alignSelf : 'center',
        padding : 10,
        height: 50,
        borderColor: '#d8d8d8',
        borderWidth : 1,
        width: 50,
        fontSize : 20,
    },
    input: {
        marginRight: 15,
        marginLeft : 15,
        height: 40,
        borderBottomColor: '#d8d8d8',
        borderBottomWidth : 1,
        width: '90%'
    },
    header : {
        width : '100%',
        height: 60,
        backgroundColor: 'green',
        justifyContent: 'center',
        flexDirection : 'row', 
    },
    backarrow : {
        flex: 1,
        flexDirection : 'row',
        width: '100%' ,
        
    },
    error : {
        color : 'red',
        fontSize : 13,
        alignSelf: 'stretch',
        paddingRight: 10,
        paddingTop : 15,
        paddingLeft: 15
    }, 
    password_error : {
        color : 'red',
        fontSize : 13,
        alignSelf: 'stretch',
        paddingRight: 10,
        paddingTop : 15,
        paddingLeft: 8
    },
    non_error : {
        display : 'none',
        alignSelf : 'center'
    },
    cyan_btn : {
        width: '60%',
        height: 45,
        borderRadius: 40,
        alignItems: 'center',
        alignSelf : 'center',
        backgroundColor: '#4f80ff',
        shadowColor: '#809adc',
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.4,
        shadowRadius: 7,  
        elevation : 3.5
    },
    label : {
        height: '100%',
        alignItems: 'center',
        fontSize: 18,
        color: 'white',
        marginTop: 10,
    },
    loading : {
        position : 'absolute',
        width : '100%',
        height : '130%',
        backgroundColor : 'black',
        opacity : 0.4
     },
     finish : {
        width : 0,
        height : 0,
        opacity : 0,
        position : 'absolute'
     },
})