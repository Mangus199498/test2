import React, { Component } from 'react';
import { AppRegistry, View , Text, Image,StyleSheet,ScrollView,TouchableOpacity, Platform} from 'react-native';
//import LoginComponent from '../components/auth/LoginComponent';
import LoginComponent from './LoginComponent';
import LoadingBar from '../../components/LoadingBar';
import { metrics } from '../../constants/globalStyles';

class LoginScreen extends Component {
   constructor (props) {
      super(props)
      this.state = {
         isLoading : false
      }
   }
   
   static navigationOptions = ({ navigation }) => {
      const {state} = navigation;
      return {
        header:null,
      }
   };
   componentWillMount()  {
      this.setState({isLoading : false})
   }
   isLoadingFunc = (value) => {
      this.setState({isLoading : value})
   }
   showAlert = () => {
      
   }
   render() {
      return (
         <View style={{width : '100%' , height : '100%'}}>
            {
               Platform.OS == 'android' && 
               <ScrollView style={{width : '100%'}}>
                  <View style={styles.logo_body}>
                     <Image style={styles.logo} source = {require('../../assets/img/icon/logo.png')}/>
                     <LoginComponent isLoadingFunc = {this.isLoadingFunc} navigation={this.props.navigation}/>
                  </View>
               </ScrollView>
            }
            {
               Platform.OS == 'ios' &&
               <View style={{flex : 100,flexDirection : 'column'}}>
                  <View style={{flex : 5}}></View>
                  <View style={{flex : 65, zIndex : 999}} >
                     <ScrollView style={styles.logo_body} bounces={false}>
                        <View style={{flex : 10, flexDirection : 'row'}}>
                           <View style={{flex : 2}}></View>
                           <View style={{flex : 6}}>
                              <Image style={styles.logo} source = {require('../../assets/img/icon/logo.png')}/>
                           </View>
                           <View style={{flex : 2}}></View>
                        </View>
                        <LoginComponent isLoadingFunc = {this.isLoadingFunc} navigation={this.props.navigation}/>
                     </ScrollView>
                  </View>
               
               </View>
            }
            <View style={this.state.isLoading ? styles.loading : styles.finish}>
               <LoadingBar/>
            </View>
         </View>
         
         
      )
   }
}
const styles = StyleSheet.create({
   logo_body : {
      width: '100%',
      height : '100%',
      flexDirection : 'column',
   },
   logo: {
      height: 120* metrics,
      width: 100* metrics,
      marginTop : 45 * metrics,
      alignSelf : 'center'
   },
   loading : {
      position : 'absolute',
      width : '100%',
      height : '130%',
      backgroundColor : 'black',
      opacity : 0.4
   },
   finish : {
      width : 0,
      height : 0,
      opacity : 0,
      position : 'absolute'
   },
})
export default LoginScreen