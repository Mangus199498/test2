import React, { Component } from "react";
import { Text, View, StyleSheet , Image, TouchableHighlight,TouchableOpacity, Dimensions,Platform} from "react-native";
import PropTypes from 'prop-types'
import UserService from "../../services/user.service";
import { inject, observer } from "mobx-react";
import { Input , Avatar} from 'react-native-elements';
import { metrics } from '../../constants/globalStyles'

@inject ('userService')
@observer

class MyInfoComponent extends Component {
    _userService : UserService = this.props.userService
    state = {
        isSelected : 1,
        profile_img : '',
        user_name : ''
    }
    componentWillMount() {
        
        this.setState({user_name : global.user_info.f_name + ' ' + global.user_info.l_name})
        this.setState({profile_img : global.user_info.img_url})
    }
    onClickedTab = (value) => {
        this.props.onChangeState(value);
        this.setState({isSelected : value});
    }
    render() {
        return (
            <View style={styles.container}>
                <View style = {{flex : 100 ,flexDirection : 'column'}}>
                    <View style={{flex : 60, justifyContent: 'center'}}>
                        <Avatar
                            rounded
                            overlayContainerStyle={{backgroundColor: '#dfdfdf'}}
                            size="xlarge"
                            source={{uri : this.state.profile_img}}
                            resizeMode={'stretch'}
                            containerStyle ={{ borderColor : 1, borderColor : 'gray'}}
                            style = {styles.profile_img}
                        />
                    </View>
                    <View style={{flex : 20, justifyContent: 'center'}}>
                        <Text style={styles.name}>{this.state.user_name}</Text>
                    </View>
                    <View style={{flex : 20}}>
                        <View style={styles.tabbar}>
                            <TouchableOpacity onPress={ ()=> this.onClickedTab(1)} style={this.state.isSelected == 1? styles.active : styles.non_active} >
                                <View style={{paddingTop: 15 * metrics, flexDirection : 'column', flex : 10}}>
                                    <View style={{flex : 3}}></View>
                                    <Text style={this.state.isSelected == 1 ? styles.active_text : styles.normal_text}>Feed</Text>
                                    <View style={{flex : 3}}></View>
                                </View>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={ ()=> this.onClickedTab(2)}  style={this.state.isSelected == 2? styles.active : styles.non_active} >
                                <View style={{paddingTop: 15 * metrics, flexDirection : 'column', flex : 10}}>
                                    <View style={{flex : 3}}></View>
                                    <Text style={this.state.isSelected == 2 ? styles.active_text : styles.normal_text}>My Groups</Text>
                                    <View style={{flex : 3}}></View>
                                </View>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={ ()=> this.onClickedTab(3)} style={this.state.isSelected == 3? styles.active : styles.non_active} >
                                <View style={{paddingTop: 15 * metrics, flexDirection : 'column', flex : 10}}>
                                    <View style={{flex : 3}}></View>
                                    <Text style={this.state.isSelected == 3 ? styles.active_text : styles.normal_text}>My Favorite</Text>
                                    <View style={{flex : 3}}></View>
                                </View>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </View>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        width: '100%',
        flex : 40,
        backgroundColor: 'white',
        borderBottomWidth: 1,
        borderBottomColor : '#bfbcbc',
        shadowColor : '#bfbcbc',
        shadowOpacity : 0.8,
        shadowOffset: {width : 0, height : -5},
        shadowRadius : 30,
        elevation : Platform.OS == 'ios' ? 3.5 : 10
    },
    
    profile_img: {
        width: 110 * metrics,
        height : 110 * metrics,
        resizeMode : "stretch",
        alignSelf : 'center',
        marginTop: 20 * metrics,
        
    },
    name : {
        fontSize: 25 * metrics, 
        textAlign : "center",
        marginTop : 10
    },
    tabbar : {
        height : '100%',
        flexDirection : 'row',
        
    },
    non_active : {
        width : '33.33%',
        borderBottomWidth: 2,
        marginBottom : 0,
        borderBottomColor: 'white'
    }, 
    active : {
        width : '33.33%',
        borderBottomWidth: 2,
        marginBottom : 0,
        borderBottomColor : '#4f80ff'
    },
    active_text: {
        color :'#4f80ff',
        width: '100%',
        fontSize : 14 * metrics,
        alignItems: 'center',
        textAlign: 'center',
    },
    normal_text : {
        color :'gray',
        width: '100%',
        fontSize : 14 * metrics, 
        alignItems: 'center',
        textAlign: 'center',
    }
});

MyInfoComponent.propType = {
    isSelected : PropTypes.number,
    onChangeState : PropTypes.func
}
export default MyInfoComponent
