import React, { Component } from "react";
import { Text, View, StyleSheet , Image,ScrollView,TouchableOpacity,Dimensions} from "react-native";
import PostService from '../../services/post.service';
import PlanService from '../../services/plan.service';
import UserService from "../../services/user.service";

import { inject, observer } from "mobx-react";
import { replaceTitle } from '../../utils/utils';
import { sortDataByTime } from '../../utils/global';
import { get_before_day } from '../../utils/moment';
import global_style , {metrics} from '../../constants/globalStyles';


@inject ('postService')
@inject ('planService')
@inject ('userService')
@observer

class FeedComponent extends Component {

    _userService : UserService = this.props.userService
    _planService : PlanService = this.props.planService
    _postService : PostService = this.props.postService
    constructor (props) {
      super(props)
      this.state = {
        plan_arr : [],
        post_arr : []
      }
    }
    componentWillMount() {
      
    }
    componentWillUnmount () {
      this.unsubscribePost()
      this.unsubscribePlan()
    }
    componentDidMount() {
      this.getPostData()
      this.getPlanData()
    }
    async getPostData() { //init post data
      var temp_data = [];
        var _this = this;
        this.unsubscribePost =  await this._postService.getAllDataByUID(global.user_info.uid).onSnapshot(function(result){
          const data = result.docs.map(doc => doc.data());
          temp_data = data;
          temp_data.forEach((item) => {
            _this._userService.getUserData(item.uid).then((result) =>{
              if (result.exists) {
                item.uid = result.data();
              }
            })
          })
          var res = sortDataByTime(temp_data)
          _this.setState({post_arr : res})
        })
    }
    async getPlanData() { //init plan data 
        var temp_data = [];
        var _this = this;
        this.unsubscribePlan =  await this._planService.getAllDataByUID(global.user_info.uid).onSnapshot(function(result){
          const data = result.docs.map(doc => doc.data());
          temp_data = data;
          temp_data.forEach((item) => {
            _this._userService.getUserData(item.uid).then((result) =>{
              if (result.exists) {
                item.uid = result.data();
              }
            })
          })
          var res = sortDataByTime(temp_data)
          _this.setState({plan_arr : res})
        })
    }
    addpost = () => {
      this.props.navigation.navigate('AddPostScreen');
    }
    componentDidUpdate() {
     
    }
    viewDetail = (item, type) => {
      if (type == 1) {
        this.props.navigation.navigate('PlaceReviewScreen', {place_id : item.id});
      }
      else {
        this.props.navigation.navigate('PostDetailScreen', {post_id : item.id});
      }
    }
    render() {
       return (
         <View style={{width : '100%', flex : 60 , backgroundColor : '#f1f6f9'}} >
           <ScrollView style={{width : '100%',padding : 5}}>
             <View style={{marginBottom : 75 * metrics}}>
              {
                this.state.plan_arr.map((item ,index) => {
                  return (
                    <TouchableOpacity style={global_style.componentCard} onPress={ () => this.viewDetail(item, 1)} key={index}>
                      <View style={{alignSelf : 'center'}}>
                        {
                          item.address.photo_arr.length > 0 ? 
                          <Image source = {{uri : item.address.photo_arr[0]}} style={styles.image}/>   : null
                        }
                        <Image source = {require('../../assets/img/icon/trip_icon.png')} style={styles.trip_icon}/>
                      </View>
                      
                      <View style={styles.body}>
                        <Text style={styles.title} numberOfLines={1}>{replaceTitle(item.address.name)}</Text>
                        <View style={styles.time}>
                          <Image source = {require('../../assets/img/icon/clock.png')} style={styles.icon}/>
                          {
                            get_before_day(item.time) == 0 ? 
                            <Text style={{marginLeft : 2}}> Just ago </Text>
                            : <Text style={{marginLeft : 2}}> { get_before_day(item.time)} days ago</Text>
                          }
                        </View>
                        <View style={styles.icon_body}>
                            <Image source = {require('../../assets/img/icon/ico_like.png')} style={styles.icon_like}></Image>
                            <Text style={{alignSelf : 'center',marginLeft : 2, marginTop : 5 * metrics}}> 0</Text>
                            {/* {item.favorite.length} */}
                            <Text style= {{marginLeft : 20* metrics}}>   </Text>
                            <Image source = {require('../../assets/img/icon/ico-inbox.png')} style={styles.icon_inbox}></Image>
                            <Text style={{marginLeft : 2 ,marginTop : 5 * metrics}}> {item.comment.length}</Text>
                        </View>
                      </View>
                    </TouchableOpacity>
                  )
                })
              }
              {
                this.state.post_arr.map((item ,index) => {
                  return (
                    <TouchableOpacity style={global_style.componentCard} onPress={ () => this.viewDetail(item, 0)} key={index}>
                      {
                        item.data_arr.length > 0 ? <Image source = {{uri : item.data_arr[0]}} style={styles.image}/> : null
                      }
                      <View style={styles.body}>
                        <Text style={styles.title}>{replaceTitle(item.title)}</Text>
                        <View style={styles.time}>
                          <Image source = {require('../../assets/img/icon/clock.png')} style={styles.icon}/>
                          {
                            get_before_day(item.time) == 0 ? 
                            <Text style = {global_style.info_text}> Just ago </Text>
                            : <Text style = {global_style.info_text}> { get_before_day(item.time)} days ago</Text>
                          }
                          
                        </View>
                        <View style={styles.icon_body}>
                            <Image source = {require('../../assets/img/icon/ico_like.png')} style={styles.icon_like}></Image>
                            <Text style = {global_style.info_text}> {item.favorite.length}</Text>
                            <Text style= {{marginLeft : 20 * metrics}}>   </Text>
                            <Image source = {require('../../assets/img/icon/ico-inbox.png')} style={styles.icon_inbox}></Image>
                            <Text style = {global_style.info_text}> {item.comment.length}</Text>
                        </View>
                      </View>
                    </TouchableOpacity>
                    
                  )
                })
              }
            </View>
            
          </ScrollView>
          <View style={[global_style.bottom, {alignSelf : 'center', flex : 10 , backgroundColor : '#f1f6f9',borderTopWidth : 0}]}>
            <View style={{flex :2.5}}></View>
            <TouchableOpacity onPress={() => this.addpost()} style={global_style.cyan_btn}>
              <Text style={global_style.label}>New Post</Text>
            </TouchableOpacity>
            <View style={{flex :2.5}}></View>
          </View>
          
         </View>
       )
    }
  }
 const styles = StyleSheet.create({
  container: {
    width : '100%',
    padding : 10 * metrics,
    overflow: 'scroll'
  },
  feedHeight: {
    height: "calc(100vh - 278px)"
  },
  image : {
    width : 105* metrics,
    height : 98* metrics,
    alignItems: 'center',
    alignSelf : 'center',
    marginLeft : 5 * metrics,
    borderRadius : 5,
    marginRight : 0
  },
  body : {
    flexDirection: 'column',
    padding: 10* metrics
  },
  time : {
    flexDirection: 'row',
    marginTop : 8 * metrics
  },
  icon : {
    width : 15 * metrics,
    height : 15 * metrics,
    resizeMode : "stretch",
    alignSelf : 'center'
  },
  title : {
    fontSize : 18 * metrics,
    fontWeight : '400',
    overflow: "hidden",
    width : 200 * metrics,
  },
  icon_inbox : {
    width: 15 * metrics,
    height: 15 * metrics,
    marginTop: 3 * metrics,
    alignSelf : 'center',
    resizeMode : "stretch"
  },
  icon_body : {
      marginTop: 8 * metrics,
      width: '100%',
      flexDirection: 'row',
      alignItems : 'center',

  },
  icon_like : {
    width: 15 * metrics,
    height: 15 * metrics,
    marginTop: 3,
    alignSelf : 'center',
    resizeMode : "stretch"
  },
  trip_icon : {
    position: 'absolute', width : 70 * metrics, height : 20 * metrics, alignSelf : 'center', bottom : 10, resizeMode : 'stretch'
  }
});

export default FeedComponent
