import React, { Component } from "react";
import { Text, View, StyleSheet ,TouchableOpacity, Image , Dimensions} from "react-native";
import global_style from  '../../constants/globalStyles'

import MyInfoComponent from './MyProfileComponent';
import FeedComponent from './FeedComponent';
import GroupComponent from './GroupComponent';
import FavoriteComponent from './FavoriteComponent';

const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const ratioX = screenWidth / 360;
const ratioY = screenHeight / 896;

import LoadingBar from '../../components/LoadingBar';

const info = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#bbbbbb",
    justifyContent: "center",
    alignItems: "center"
  },
  backarrow : {
    flex: 1,
    flexDirection : 'row',
    width: '100%'           
  },
});
let _this=null;

class MyInfoScreen extends Component {
    constructor (props) {
        super(props)
        this.state = {
            isSelected : 1,
            isLoading : false
        }
    }
    
    onChangeState = (value) => {
        this.setState({isSelected : value});
    }
    
    componentWillMount() {
        _this = this;
    }
    isLoadingFunction = (value) => {
        this.setState({isLoading : value})
    }
    onClickedProfile = () => {
        this.props.navigation.navigate('EditProfileScreen');
    }
    static navigationOptions = ({ navigation }) => {
        return {
            headerLeft: (
                <View style={global_style.navigation}>
                    <TouchableOpacity 
                        style={info.backarrow}
                        onPress={() => navigation.goBack()} >
                            <Image source = {require('../../assets/img/icon/left_arrow.png')} style={global_style.arrow_icon}/> 
                            <Text style={global_style.back_title}>MY PROFILE</Text>
                    </TouchableOpacity>
                </View>
            ),
            headerRight: (
                <TouchableOpacity 
                style ={info.backarrow}
                onPress = {() => _this.onClickedProfile()} >
                    <Image source = {require('../../assets/img/icon/ico_edit.png')} style = {{marginRight:10 *ratioX, width : 22 *ratioX , height : 22*ratioX,resizeMode :'stretch', marginTop: 15*ratioX}}/> 
                </TouchableOpacity>
            ),
            headerStyle: global_style.headerHeight,
        };
    };
    render() {
       return (
            <View style={{width: '100%', height: '100%'}}>
                {
                    this.state.isLoading ? null :
                    <View style={{flex : 100 , flexDirection : 'column' }}>
                        <MyInfoComponent isSelected = {this.state.isSelected} onChangeState={this.onChangeState}/>
                        {this.renderComponent()}
                    </View>
                }
                <View style={this.state.isLoading ? global_style.loading : global_style.none}>
                    <LoadingBar/>
                </View>
                
            </View>
       )
    }
    renderComponent() {
        if (this.state.isSelected == 1) {
            return <FeedComponent style={{paddingBottom : 30}} navigation={this.props.navigation}/>
        } else if (this.state.isSelected == 2) {
            return <GroupComponent style={{paddingBottom : 30}} navigation={this.props.navigation} />
        } else if (this.state.isSelected == 3) {
            return <FavoriteComponent style={{paddingBottom : 30}} navigation={this.props.navigation}/>
        }
    }
 }

export default MyInfoScreen
