import React, { Component } from "react";
import { Text, View, StyleSheet ,TouchableOpacity,Image, ScrollView, Dimensions} from "react-native";

import UserService from '../../services/user.service';
import GroupService from '../../services/group.service';
import { replaceTitle } from '../../utils/utils';
import { inject, observer } from "mobx-react";
import global_style , {metrics} from '../../constants/globalStyles';

@inject ('userService')
@inject ('groupService')
@observer

class GroupComponent extends Component {

  _userService : UserService = this.props.userService
  _groupService : GroupService = this.props.groupService

  state = {
    my_group_arr : [],
    group_arr : []
  }

  addGroup = () => {
    this.props.navigation.navigate('AddGroupScreen');
  }
  viewDetail = (item) => {
    var group_id = item.id
    this.props.navigation.navigate('GroupDetailScreen', {group_id : group_id});
  }
  componentWillUnmount () {
    this.unsubscribeGroup()
    this.unsubscribeMyGroup()
  }
  componentWillMount() {
    var _this = this;
    this.unsubscribeGroup = this._groupService.getGroupDataUID(global.user_info.uid).onSnapshot(function(result) {
      const data = result.docs.map(doc => doc.data());
      _this.setState({group_arr : data})
    })
    this.unsubscribeMyGroup = this._groupService.getMyGroupDataByUID (global.user_info.uid).onSnapshot(function(result){
      const data = result.docs.map(doc => doc.data());
      _this.setState({my_group_arr : data})
    })
  }
  render() {
     return (
        <View style={{width : '100%', flex : 60 , backgroundColor : '#f1f6f9'}}>
          <ScrollView style={{width : '100%',padding : 5}}>
            <View style={{marginBottom : 75}}>
              {
                this.state.my_group_arr.map((item, index) => {
                  return (
                    <TouchableOpacity style={global_style.componentCard}  onPress={ () => this.viewDetail(item)} key={index}>
                      <Image source = {{uri : item.group_img}} style={styles.image}/>
                      <View style={styles.body}>
                        <Text style={styles.title} numberOfLines={1}>{replaceTitle(item.title)}</Text>
                        <Text style={styles.gray_title}>Last message here</Text>
                        <View style={styles.icon_body}>
                            <Image source = {require('../../assets/img/icon/ico_friend.png')} style={styles.icon_like}></Image>
                            <Text style = {global_style.info_text}> {item.friends_arr.length + 1}</Text>
                        </View>
                      </View>
                    </TouchableOpacity>
                  )
                })
              }
              {
                this.state.group_arr.map((item, index) => {
                  return (
                    <TouchableOpacity style={global_style.componentCard}  onPress={ () => this.viewDetail(item)} key={index}>
                      <Image source = {{uri : item.group_img}} style={styles.image}/>
                      <View style={styles.body}>
                        <Text style={styles.title} numberOfLines={1}>{replaceTitle(item.title)}</Text>
                        <Text style={styles.gray_title}>Last message here</Text>
                        <View style={styles.icon_body}>
                            <Image source = {require('../../assets/img/icon/ico_friend.png')} style={styles.icon_like}></Image>
                            <Text style = {global_style.info_text}> {item.friends_arr.length + 1}</Text>
                        </View>
                      </View>
                    </TouchableOpacity>
                  )
                })
              }
            </View>
          </ScrollView>
         
        <View style={[global_style.bottom, {backgroundColor : '#f1f6f9'}]}>
          <View style={{flex : 2.5}}></View>
          <TouchableOpacity onPress={() => this.addGroup()} style={global_style.cyan_btn}>
              <Text style={global_style.label}>Create Groups</Text>
          </TouchableOpacity>
          <View style={{flex : 2.5}}></View>
        </View>

       </View>
     )
  }
}

const styles = StyleSheet.create({
  container: {
    width : '100%',
    padding : 8,
    overflow: 'scroll',
  },
  image : {
    width : 110  * metrics,
    height : 98  * metrics,
    alignItems: 'center',
    alignSelf : 'center',
    marginLeft : 5,
    borderRadius : 5,
    marginRight : 0,
  },
  body : {
    flexDirection: 'column',
    padding: 10 * metrics
  },
  time : {
    flexDirection: 'row',
    marginTop : 8 * metrics
  },
  icon : {
    width : 15 * metrics,
    height : 15 * metrics,
    resizeMode : "stretch",
    margin : 'auto',
    marginLeft : 0,
    marginRight : 5 * metrics
  },
  title : {
    fontSize : 18 * metrics,
    fontWeight : '400',
    overflow: "hidden",
    flexWrap: 'nowrap',
    width : 180 * metrics,
  },
  gray_title : {
    marginTop : 8 * metrics
  },
  icon_body : {
      marginTop: 8 * metrics,
      width: '100%',
      flexDirection: 'row',
  },
  icon_like : {
    width: 15 * metrics,
    height: 15 * metrics,
    marginTop: 3,
    resizeMode : "stretch"
  },
  cyan_btn : {
    flex : 6,
    height: 45 * metrics,
    borderRadius: 40,
    alignItems: 'center',
    alignSelf : 'center',
    backgroundColor: '#4f80ff',
    shadowColor: '#809adc',
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 7,  
    marginBottom : 0,
    elevation : 3.5
  },
  label : {
    height: '100%',
    alignItems: 'center',
    fontSize: 18 * metrics,
    color: 'white',
    marginTop: 10 * metrics,
  },
});

export default GroupComponent