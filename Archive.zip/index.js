/**
 * @format
 */

import {AppRegistry} from 'react-native';
import App from './App';
import { YellowBox } from 'react-native';

//YellowBox.ignoreWarnings = ['Warning'];
YellowBox.ignoreWarnings([
  'Warning: componentWillMount is deprecated',
  'Warning: componentWillReceiveProps is deprecated',
  'Module RCTImageLoader requires',
  'MobX Provider: Provided store'
]);

AppRegistry.registerComponent('yTravel', () => App);

