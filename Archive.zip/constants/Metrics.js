// @flow

import { Dimensions } from 'react-native';

const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;

// metrics based on iPhone Xs Max
// see: https://www.paintcodeapp.com/news/ultimate-guide-to-iphone-resolutions
const ratioX = screenWidth / 360;
const ratioY = screenHeight / 896;

export default {
  fontSizeGiant: 45 * ratioX,
  fontSizeHuge: 26 * ratioX,
  fontSizeBig: 18 * ratioX,
  fontSizeMedium: 13 * ratioX,
  fontSizelarge: 15 * ratioX,
  fontSizeNormal: 15 * ratioX,
  fontSizeLight: 12 * ratioX,
  fontSizeSmall: 10 * ratioX,
  spacingGiant: 45 * ratioX,
  spacingHuge: 36 * ratioX,
  spacingBig: 24 * ratioX,
  spacingNormal: 16 * ratioX,
  spacingSmall: 10 * ratioX,
  spacingTiny: 6 * ratioX,
  navBarHeight: 80 * ratioX,
  footerHeight: 80 * ratioX,
  rowHeightSmall: 35 * ratioX,
  rowHeight: 44 * ratioX,
  rowHeightMedium: 55 * ratioX,
  rowHeightBig: 66 * ratioX,
  marginHuge: 36,
  marginBig: 24,
  marginNormal: 16,
  marginSmall: 10,
  marginTiny: 6,
  screenHeaderHeight: 60,
  inputHeight: 44,
  // according to IG 59 pts from top, safeareaview pads 44pts
  safeHeaderMargin: 13,
  statusbarHeight: 20,
  spaceNormal: 24 * ratioX,
  trackTab: 63 * ratioX,
  trackHeight: 102 * ratioY,
  trackVerticalMargin: 5,
  studioBtns: 36,
  screenWidth,
  screenHeight,
  ratioX,
  ratioY,
};
