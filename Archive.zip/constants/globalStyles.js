'use strict';

// var React = require('react-native');
// var {
//     StyleSheet,
//     Dimensions
// } = React;


import { Dimensions, Platform } from 'react-native';

const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;

// metrics based on iPhone Xs Max
// see: https://www.paintcodeapp.com/news/ultimate-guide-to-iphone-resolutions
const ratioX = screenWidth / 380;
const ratioY = screenHeight / 896;

export var metrics = ratioX

export default {

    logo_body : {
        paddingTop: 35,
        width: '100%',
        height : '100%',
        overflow: 'scroll',
    },
    text_body : {
        flexDirection : 'row',  
        alignSelf: 'stretch',
        paddingLeft: 10,
        paddingRight: 10
    },
    container: {
        width: '100%',
        height: '100%'
    },
    message_right:{
        flexDirection : 'row',
        alignSelf: 'center',
        flex :6,
    },
    check_body : {
        flexDirection : 'row',
        alignSelf: 'stretch',
        paddingLeft: 17,
        paddingRight: 25,
        paddingTop: 15
    },
    social_body : {
        flexDirection : 'column',
        width: '65%',
        alignItems: 'center',
        marginTop :35,
    },
    social_button : {
        flexDirection : 'row',
        width: '100%',
        alignItems: 'center',
        marginTop : 15,
        
    },
    social_title : {
        alignItems: 'center' ,
        marginBottom: 10
    },
    input : {
        margin: 15,
        height: 40,
        borderBottomColor: '#d8d8d8',
        borderBottomWidth: 1,
        width: '100%',
    },
    body : {
        height: '100%',
        paddingTop : 20,
        paddingBottom: 25,
        marginBottom : 10 * metrics
    },
    photo : {
        width: 130,
        height: 130,
    },
    navigation:{
        flexDirection : 'row',
        height : 60 * ratioX,
    },
    other_navigation : {
        flexDirection : 'row',
        height: 85,
        paddingTop : 25,
        borderBottomColor : '#f3f3f3',
        borderBottomWidth : 1
    },
    left:{
        alignItems: 'center',
        marginLeft : 15,
        marginRight : 0,
        marginTop : 5
    },
    right:{
        alignItems: 'center',
        marginRight : 10,
        flexDirection : 'row',
        marginRight: 10,
    },
    name : {
        flexDirection : 'row',
        marginBottom : 5,
        width : '100%'
    },
    first_name : {
        flexDirection : 'column',
        flex : 5
    },
    last_name : {
        flexDirection : 'column',
        flex : 5,
        alignItems : 'flex-end'
    },
    form_body : {
        marginLeft: 20,
        marginRight: 20,
        marginTop: 20
    },
    name_input : {
        height: 40,
        borderBottomColor : '#d8d8d8',
        borderBottomWidth : 1,
        alignSelf : 'flex-start',
        width: '95%',
        paddingRight: 10
    },
    wrapper : {
        flexDirection :'column',
        marginTop: 10
    },
    check : {
        marginTop : 30,
        alignItems : "center"
    },
    register_btn : {
        flex : 20,
        alignItems : "center"
    },
    text_input : {
        width: '100%',
        height: 40,
        borderBottomColor : '#d8d8d8',
        borderBottomWidth : 1
    },
    text_area :{
        width: '100%',
        height: '40%',
        borderColor:'#d8d8d8',
        borderWidth : 1
    },
    review_area :{
        width: '100%',
        borderRadius : 8,
        marginTop : 15,
        backgroundColor : 'whitesmoke',
        padding: 5,
        height : 50,
        borderWidth : 1,
        borderColor : '#d8d8d8'
    },
    body_container:{
        height: '100%',
        width: '100%',
        paddingBottom : 60 * ratioX
    },
    header: {
        width : '100%',
        height: Platform.OS == 'ios' ?  135 * ratioX : 120 * ratioX,
        paddingTop: Platform.OS == 'ios' ? 30 * ratioX : 15 * ratioX,
        shadowOffset: {width: 0,height: 4,},
        elevation : Platform.OS == 'ios' ? 0.8 : 10,
        shadowOpacity : 0.3,
        elevation: 5,
        flexDirection : 'column',
        backgroundColor : 'white'
    },
    explore_header : {
        width : '100%',
        height: Platform.OS == 'ios' ? 180 * ratioX : 160 * ratioX,
        paddingTop: Platform.OS == 'ios' ? 30 * ratioX : 15 * ratioX,
        shadowOffset: {width: 0,height: Platform.OS == 'ios' ? 1:4,},
        elevation : Platform.OS == 'ios' ? 0.2 : 10,
        shadowOpacity : Platform.OS == 'ios' ? 0.3 : 1,
        flexDirection : 'column',
        backgroundColor : 'white'
    },
    other_header : {
        width : '100%',
        height: Platform.OS == 'ios' ? 85 * ratioX : 70 * ratioX,
        paddingTop: Platform.OS == 'ios' ? 30 * ratioX : 15 * ratioX,
        shadowOffset: {width: 0,height: 4,},
        elevation : Platform.OS == 'ios' ?  0.4 : 10,
        shadowOpacity : Platform.OS == 'ios'? 0.3 : 1,
        flexDirection : 'column',
        backgroundColor : 'white'
    },
    navBar : {
        flexDirection : 'row',
        marginTop : 8 * metrics
    },
    header_title : {
        paddingTop : 5,
        paddingLeft: 10,
        fontSize : 25 * ratioX,
        fontWeight : '400',
        flex : 7
    },
    message_title : {
        paddingTop : 5 * ratioX,
        paddingLeft: 10 * ratioX,
        fontSize : 24 * ratioX,
        fontWeight : '600',
        flex : 4
    },
    message_body : {
        width: '100%',
        borderBottomWidth : 1,
        borderBottomColor : '#e8e8e8',
        height :70 * ratioX,
        backgroundColor: 'whitesmoke'
    },
    right_icon: {
        alignItems : 'flex-start',
        flex : 1,
        alignSelf : 'center',
        flexDirection : 'row',
        position : 'absolute',
        right: 10,
    },
    search:{
        height: 45 * ratioY,
        marginTop: 15 * ratioX,
        marginLeft : 10 * ratioX,
        marginRight : 10 * ratioX,
        flexDirection : 'row',
        width : '100%'
    },
    search_icon:{
        width: 40 * ratioX,
        height: 40 * ratioX,
        position : 'absolute',
        right : 20,
        alignItems: 'center',
    },
    icon_bell : {
        marginTop: 10 * ratioY,
        fontSize: 25 * ratioX,
        color: '#bbbbbb',
        marginRight: 10,
    },
    icon_microphone : {
        alignItems: 'center'
    },
    add_tabbar: {
        flexDirection : 'row',
        width: '80%',
        marginTop : 5 ,
        alignSelf : 'center',
        flex : 10,
        //height: 50 * ratioX,
    },
    chat_body :{
        height: '100%',
        marginBottom: 50 * metrics
    },
    owner :{
        marginTop: 10 * metrics,
    },
    other : {
        marginTop: 10 * metrics
    },
    bottom_fixed :{
        width : '100%',
        flexDirection : 'row',
        height: 55 * ratioX,
        backgroundColor : 'white',
        position: 'absolute',
        bottom: 0,
        shadowOffset : {width: 0, height: -5},
        shadowOpacity : 0.2,
        elevation : 2.5,
    },
    comment_style : {
        margin: 8 * ratioX,
        height : 40 * ratioX ,
        flex : 85,
        borderColor : '#eae5e5',
        borderWidth : 1,
        borderRadius: 4,
        padding: 10 * ratioX,
        marginLeft: 10 * ratioX,
        //backgroundColor : 'red',
        backgroundColor : 'whitesmoke'
    },
    my_txt : {
        position: 'relative',
        backgroundColor: '#4f80ff',
        borderRadius: 10,
        width: 250  * ratioX,
        minHeight: 55 * ratioX,
        alignSelf : 'flex-end',
        flexDirection : 'column',
        marginRight: 20 * ratioX,
        marginTop: 5 * ratioX,
        marginBottom: 5 * ratioX,
        padding: 15 * ratioX,
        paddingLeft : 15 * ratioX,
        fontSize: 13 * ratioX,
        shadowOpacity : 0.3,
        shadowOffset : {width : 0, height : 3},
        color : 'white',
    },
    other_txt : {
        position: 'relative',
        backgroundColor : 'white',
        borderRadius: 10,
        width: 250  * ratioX,
        minHeight: 55 * ratioX,
        marginLeft: 20 * ratioX,
        marginTop: 5 * ratioX,
        marginBottom: 5 * ratioX,
        elevation : 1.5,
        shadowOpacity : 0.3,
        shadowOffset : {width : 0, height : 3},
        padding: 10 * ratioX,
        paddingLeft : 15,
        fontSize: 13 * ratioX,
        color : 'dimgrey'
    },
    setting_tile : {
        width: '95%',
        height : 60 * ratioX,
        alignItems: 'center',
        alignSelf : 'center',
        marginTop: 5 * ratioX,
        marginBottom: 10 * ratioX,
        borderRadius: 9,
        elevation : Platform.OS == 'ios' ?  0.4 : 3,
        shadowColor : '#8a8888',
        backgroundColor : 'white',
        shadowOpacity: Platform.OS == 'ios' ? 0.7 : 1,
        shadowOffset: { width: 0, height: 0 } ,
    },
    arrow_icon : {
        width : 13 * ratioX,
        height : 20 * ratioX,
        resizeMode : 'stretch',
        marginLeft: 10 * ratioX,
        marginTop : 28 * ratioX
    },
    headerHeight : {
        height : 60 * ratioX,
        elevation : Platform.OS == 'ios'? 1.0 :  10,
        shadowOpacity : Platform.OS == 'ios' ? 0.3 :  1,
        backgroundColor :'white',
        shadowOffset : {width : 0, height : Platform.OS == 'ios' ? 1 :  5}
    },
    right_arrow : {
        width : 13,
        height : 20,
        resizeMode : 'stretch',
        position : "absolute",
        right : 5,
        alignSelf : 'center'
    },
    right_arrow_icon : {
        width : 13,
        height : 20,
        resizeMode : 'stretch',
        alignItems: 'center',
        marginRight: 10,
    },
    back_title : {
        fontSize : 18 * ratioX, 
        marginLeft: 15 * ratioX,
        marginTop : 18 * ratioX,
        alignSelf : 'center'
        
    },
    tabbar:{
        flexDirection : 'row',
        flex : 10,
        elevation : 3.5
    },
    active:{
        width: '50%',
        borderBottomColor: '#4f80ff',
        borderBottomWidth : 4,
        alignSelf : 'center'
    },
    non_active:{
        width : '50%',
        alignSelf : 'center',
         borderBottomWidth : 4,
        borderBottomColor: 'transparent',
    },
    
    active_tab:{
        flex : 5,
        alignItems : 'center',
        borderBottomColor: '#4f80ff',
        borderBottomWidth : 4,
        zIndex : 999,
    },
    non_active_tab:{
        flex : 5,
        alignItems : 'center',
        zIndex : 999,
        borderBottomColor: '#fff',
        borderBottomWidth : 4,
    },
    starStyle : {
        width: 100 * ratioX,
        height: 20 * ratioX
    },
    friends_tile : {
        width: '95%',
        height : 70 * ratioX,
        alignItems: 'center',
        alignSelf : 'center',
        marginTop: 5 * metrics,
        marginBottom: 5 * metrics,
        borderRadius: 9,
        shadowColor : '#8a8888',
        backgroundColor : 'white',
        elevation : Platform.OS == 'ios' ?  2.5 : 5.5,
        shadowOpacity: 1,
        shadowOffset: { width: 0, height: 2 } ,
    },
    google_location :{
        zIndex : 999,
        position: 'absolute',
        flexDirection : 'row',
        width: '100%',
        alignSelf : "stretch",
        top: 15,
        display: 'flex'
    },
    google_map :{
        width: '100%',
        height : '100%',
        backgroundColor : '#ffffff'//'#ffffff'
    },
    place_img :{
        overflow: 'scroll',
        flexDirection: 'row',
        marginLeft: 5,
        marginRight: 5,
        marginBottom : 10,
        height : 130 * ratioX,

    },
    image :{ 
        borderRadius: 10,
        height: 120 * ratioX,
        marginTop: 10,
        marginRight: 5,
        marginBottom: 10,
        marginLeft: 5,
        width: 130 * ratioX,
    },
    place_body :{
        bottom: 5,
        width: '100%',
        position: 'absolute',
        flexDirection: 'column',
    },
    place_label :{
        flexDirection: 'row',
    },
    title :{
        width: 100 * ratioX,
        position: 'relative',
        top: -60 * ratioX,
        left: 20,
        color: 'white',
        fontSize: 13 * ratioX,
    },
    bottom: {
        position : 'absolute', //made by martin
        bottom: 0,
        width: '100%',
        flex : 20,
        height : 60 * metrics,
        shadowOffset : { width : 0, height : Platform.OS == 'ios' ? 0 : -20},
        elevation : Platform.OS =='ios' ? 0.4 : 10,
        shadowOpacity : 0.4,
        backgroundColor : 'white',
        flex: 10
    },
    loading : {
        position : 'absolute',
        top : 0,
        width : '100%',
        height : '130%',
        alignSelf : 'center',
        height : '500000000%'
    },
    none : {
        width : 0,
        height : 0,
    },
    textarea: {
        textAlignVertical: 'top',  // hack android
        height: 170 * ratioX,
        fontSize: 14 * ratioX,
        color: '#333',
        borderWidth : 1,
        borderColor : '#eae5e5',
        borderRadius: 4,
        padding : 10,
        marginTop : 10,
        backgroundColor : '#f1f6f9'
    },
    faq_textarea : {
        textAlignVertical: 'top',  // hack android
        height: 60 * ratioX,
        fontSize: 14 * ratioX,
        color: 'gray',
        borderWidth : 1,
        borderColor : '#eae5e5',
        borderRadius: 4,
        padding : 10,
        marginTop : 10,
        backgroundColor : '#ececec'
    },
    gray_title : {
        color : 'gray'
    },
    badge_body : {
        width : 30 * ratioX, 
        height : 30 * ratioX, 
        marginRight: 10 * ratioX
    },
    info_text : {
        alignSelf : 'center', marginLeft: 2, color : '#464646' , marginTop : 3 * metrics
    },
    cyan_btn : {
        width: '55%',
        height : 45 * ratioX,
        borderRadius: 40 * ratioX,
        alignItems: 'center',
        alignSelf : 'center',
        backgroundColor: '#4f80ff',
        elevation : 3.5
     },
    label : {
        height: '100%',
        alignItems: 'center',
        fontSize: 18 * ratioX,
        color: 'white',
        marginTop: 10 * ratioX,
    },
    componentCard: {
        width : '100%',
        height: 110 * metrics,
        shadowOffset : { width : 0, height : 4},
        shadowColor : '#cccbcb',
        shadowOpacity: 1,
        borderRadius : 10,
        marginTop: 5,
        marginBottom: 5,
        elevation : Platform.OS == 'ios' ? 0 : 3.5,
        backgroundColor : 'white',
        flexDirection : 'row'
      },
}

// module.exports = StyleSheet.create({

    
// });