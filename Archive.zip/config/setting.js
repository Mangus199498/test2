export var config = {
    twitterConsumerKey : "xRXNVfhtwnlSnfiBbkfC8haex",
    twitterSecretKey : "QhpygzwJJn4Dz4D09IKE8ecKXALJJkcEcIC89fPul5z17Od2KZ",
    webClientID : "990212510702-6qte1v7kl51qv59ic3q0m844ai8ieq0v.apps.googleusercontent.com"
}